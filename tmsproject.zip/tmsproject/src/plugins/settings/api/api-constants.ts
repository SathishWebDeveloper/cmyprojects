import { API_METHODS } from "@/types/common";

export const PLUGINS_API_END_POINTS = {
    getAllAttribute: { endPoint: 'api/settings/attributes', method: API_METHODS.GET },
    attributesforms: { endPoint: 'api/settings/attributes/forms', method: API_METHODS.GET },
    singleAttributeEditResponse: { endPoint: 'api/settings/attributes', method: API_METHODS.GET },
    singleAttributeDeleteResponse: { endPoint: 'api/settings/attributes', method: API_METHODS.DELETE },
    createAttribute: { endPoint: 'api/settings/attributes', method: API_METHODS.POST },
    attributetypes: { endPoint: 'api/settings/attributes/types', method: API_METHODS.GET },
    updateAttributetypes: { endPoint: 'api/settings/attributes', method: API_METHODS.PUT },
    getValidationtypes: { endPoint: 'api/settings/attributes/form/validation-types', method: API_METHODS.GET },

}