import { apiBaseUrl, request } from "@/core/utils";
import { PLUGINS_API_END_POINTS } from "@/plugins/settings/api/api-constants";

// get all attributes
export const getAllAttributes = async (data?: any) => {

    const getAllAttributes = await request({
        url: `${apiBaseUrl + PLUGINS_API_END_POINTS.getAllAttribute.endPoint}`,
        method: PLUGINS_API_END_POINTS.getAllAttribute.method,
        params: { ...data }
    });
    return getAllAttributes;
}


// get all attributesForms
export const getAttributesForms = async () => {
    const getAttributesForms = await request({
        url: apiBaseUrl + PLUGINS_API_END_POINTS.attributesforms.endPoint,
        method: PLUGINS_API_END_POINTS.attributesforms.method,
    });
    return getAttributesForms;
}


// get edit attributes
export const getAttributeById = async (data: any) => {
    const singleAttributeEditResponse = await request({
        url: `${apiBaseUrl + PLUGINS_API_END_POINTS.singleAttributeEditResponse.endPoint}/${data}`,
        method: PLUGINS_API_END_POINTS.singleAttributeEditResponse.method,
    });
    return singleAttributeEditResponse;
}

//delete attributes
export const deleteAttributeById = async (data: any) => {
    const singleAttributeDeleteResponse = await request({
        url: `${apiBaseUrl + PLUGINS_API_END_POINTS.singleAttributeDeleteResponse.endPoint}/${data}`,
        method: PLUGINS_API_END_POINTS.singleAttributeDeleteResponse.method,
    })
    return singleAttributeDeleteResponse;
}

//create attributes
export const createAttribute = async (data: any) => {


    const createAttributeResponse = await request({
        url: `${apiBaseUrl + PLUGINS_API_END_POINTS.createAttribute.endPoint}`,
        method: PLUGINS_API_END_POINTS.createAttribute.method,
        body: { ...data },
    })
    return createAttributeResponse;
}


//create attributes
export const updateAttribute = async (data: any, id: number | string) => {
    const createAttributeResponse = await request({
        url: `${apiBaseUrl + PLUGINS_API_END_POINTS.updateAttributetypes.endPoint}/${id}`,
        method: PLUGINS_API_END_POINTS.updateAttributetypes.method,
        body: { ...data },
    })
    return createAttributeResponse;
}

//getAttributeTypes
export const getAttributeTypes = async () => {
    const getAttributeTypes = await request({
        url: `${apiBaseUrl + PLUGINS_API_END_POINTS.attributetypes.endPoint}`,
        method: PLUGINS_API_END_POINTS.attributetypes.method,
    })
    return getAttributeTypes;
}


//getValidationTypes
export const getValidationTypes = async () => {
    const getValidationTypes = await request({
        url: `${apiBaseUrl + PLUGINS_API_END_POINTS.getValidationtypes.endPoint}`,
        method: PLUGINS_API_END_POINTS.getValidationtypes.method,
    })
    return getValidationTypes;
}
