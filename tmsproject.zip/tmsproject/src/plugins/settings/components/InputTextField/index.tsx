import styled from "@emotion/styled";
import { Stack, TextField } from "@mui/material";
import PropTypes from 'prop-types';

const StyledLabel = styled('label')((data:any) => ({
    display: 'block',
    color: '#252525',
    fontSize: 13,
    fontWeight: 500,
    ...data.style?.label
}));

const StyledInput = styled(TextField)((data:any) => ({
    'input': {
        padding: '8px 10px',
        fontWeight: 500,
        fontSize: 14,
        '::placeholder': {
            fontSize: 13
        }
    },
    'fieldset': {
        borderRadius: '4px',
    },
    ...data.style?.input
}));

function InputTextField(data:{label:string,style:any,placeholder:string}) {
    return (
        <Stack sx={{ gap: '5px', ...data.style.stack }}>
            {data.label ? <StyledLabel>{data.label}</StyledLabel> : null}
            <StyledInput
                style={data.style}
                placeholder={data.placeholder ? data.placeholder : null}
            />
        </Stack>
    )
}

InputTextField.propTypes = {
    style: PropTypes.object,
    placeholder: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
    label: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
};

export default InputTextField;