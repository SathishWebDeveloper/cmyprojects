import styled from "@emotion/styled";
import { FormControl, MenuItem, Select, Typography } from "@mui/material";
import PropTypes from 'prop-types';

const StyledFormControl = styled(FormControl)((data:any) => ({
    // width
    'fieldset': {
        borderRadius: '16px',  // borderRadius
        border: 'none',
        ...data.style?.fieldset
    },
    '.MuiSelect-select': {
        padding: '5px 10px',
        fontSize: 12,
        color: '#252628',
        fontWeight: 500,
        borderRadius: '16px',  // borderRadius
        backgroundColor: '#F5F5F5',
        ...data.style?.select
    },
    ...data.style?.root
}));

const StyledLabel = styled(Typography)((data:any) => ({
    fontSize: 13,
    color: '#252525',
    fontWeight: 500,
    ...data.style?.label
}));

function ButtonDropdown(data:any) {
  
    
    const handleChange = (event : any) => {
        data.onChange(event.target.value)
    };

    
    return (
        <StyledFormControl style={data.style} >
            {data.label ? <StyledLabel style={data.style}>label</StyledLabel> : null}
            <Select
                defaultValue={'select'}
                value={data.value ? data.value : 'select'}
                onChange={handleChange}
            >
                <MenuItem value={'select'} disabled>Select</MenuItem>
                {data.data.map((item:{name:string,value:string} , index:number) => (
                    <MenuItem key={index} value={item.value}>{item.name}</MenuItem>
                ))}
            </Select>
        </StyledFormControl>
    )
}

ButtonDropdown.propTypes = {
    onChange: PropTypes.func.isRequired,
    data: PropTypes.arrayOf(
        PropTypes.shape({
            value: PropTypes.oneOfType([PropTypes.string, PropTypes.number]).isRequired,
            name: PropTypes.oneOfType([PropTypes.string, PropTypes.number]).isRequired,
        })
    ).isRequired,
    style: PropTypes.object,
    value: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
    label: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
};

export default ButtonDropdown;