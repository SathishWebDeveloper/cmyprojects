import {
  ErrorStyled,
  FormContainer,
  InputError
} from "@/core/pages/Login/components/LoginStyled";
import {
  createAttribute,
  getAttributeById,
  getAttributeTypes,
  getValidationTypes,
  updateAttribute
} from "@/plugins/settings/api/api-handlers";
import {
  LoadingButtonStyled,
  OutlinedButtonStyled,
  OutlinedInputStyled,
  OutlinedSelectStyled,
  RequiredFieldStyle,
  OutlinedCheckboxStyled
} from "@/plugins/settings/components/CreateAttribute/createAttributesStyled";
import Box from "@mui/material/Box";
import { ErrorMessage, Field, Form, Formik } from "formik";
import { useSnackbar } from "notistack";
import React, { useState } from "react";
import { useIntl } from "react-intl";
import * as Yup from "yup";
import Downarrow from '@/assets/images/down-arrow-selecttag.svg';
import DeleteIcon from "@mui/icons-material/Delete";
import { Button, IconButton, Paper } from "@mui/material";
import CircularProgress from '@mui/material/CircularProgress';
import Switch from '@mui/material/Switch';

interface ToggleCreateAttribute {
  ToggleCreateAttribute: () => void;
  editId: string | number;
  setEditId: (data: string) => void;
  selectedData: any,
  setsortingData: any
}

const CreateAttribute = ({
  ToggleCreateAttribute,
  editId,
  setEditId,
  selectedData,
  setsortingData
}: ToggleCreateAttribute) => {

  const [editAttributesData, seteditAttributesData] = useState<any>({});
  const [attrtypes, setattrtypes] = useState([]);
  const [validationtypes, setvalidationtypes] = useState([]);
  const [isSubmit, setisSubmit] = useState(false);
  const [selectedValue, setSelectedValue] = useState<any>(attrtypes);
  const [inputValues, setInputValues] = useState([
    { options: "", optionsValue: null }
  ]);
  const [isDisabled, setIsDisabled] = useState(false);
  const [responseErr, setresponseErr] = useState<any>(null);
  const [toggleValues, setToggleValues] = useState({
    isRequired: false,
    isUnique: false,
    status: false,
  });



  const { formatMessage } = useIntl();

  const getSingleAttribute = async (id: any) => {
    const response = await getAttributeById(id);
    seteditAttributesData(response.data);
    setToggleValues({
      isRequired: response.data.is_required,
      isUnique: response.data.is_unique,
      status: response.data.status,
    })

    setSelectedValue(response.data.type)
    if (response?.data?.options) {

      let valueOnly = Object.values(response.data.options);
      let modifiedOptions: Array<any> = [];

      valueOnly.forEach((e: any, i: number) => {
        modifiedOptions.push({ options: e.name, optionsValue: i + 1 })
      })

      setInputValues(modifiedOptions)
    }

  };


  const handleInputChange = (e: any, setFieldValue: any, textValue: string) => {
    const inputValue = e.target.value.toLowerCase();

    if (textValue === "name") {
      setFieldValue("name", inputValue);
    }
    else if (textValue === "code") {
      setresponseErr(null);
      setFieldValue("code", inputValue);
    }
    else if (textValue === "is_required") {
      setFieldValue("is_required", e.target.checked ? true : false);
      setToggleValues(({ ...toggleValues, isRequired: e.target.checked ? true : false }))
    }
    else if (textValue === "type") {
      setresponseErr(null);
      setFieldValue("type", inputValue);
      handleSelect(inputValue);
    }
    else if (textValue === "is_unique") {
      setFieldValue("is_unique", e.target.checked ? true : false);
      setToggleValues(({ ...toggleValues, isUnique: e.target.checked ? true : false }))
    }
    else if (textValue === "status") {
      setFieldValue("status", e.target.checked ? true : false);
      setToggleValues(({ ...toggleValues, status: e.target.checked ? true : false }))
    }
    else {
      setFieldValue("form_group", inputValue);
    }
  };

  const MySpecialField = (setFieldValue: any) => {
    return (
      <Switch {...setFieldValue} color="warning" />

    );
  };
  const handleSelect = (event: any) => {
    if (event !== "select" || event !== "multiselect") {
      setInputValues([
        { options: "", optionsValue: null }
      ]);

      setSelectedValue(event)
    } else {
      setSelectedValue(event);
    }
  };

  const handleSelectAdd = () => {
    setInputValues([...inputValues, { options: "", optionsValue: null }]);
  };

  const handleOnChange = (e: any, index: any) => {
    const { value } = e.target;
    const optionValue = [...inputValues];
    optionValue[index].options = value;
    optionValue[index].optionsValue = index + 1;
    setInputValues(optionValue);
  };

  const handleSelectDelete = (index: any) => {
    const optionValue = [...inputValues];
    optionValue.splice(index, 1);
    setInputValues(optionValue);
  };

  const handleSelectChange = () => {
    if (inputValues.length > 0) {
      inputValues[inputValues.length - 1].options === ""
        ? setIsDisabled(true)
        : setIsDisabled(false);
    }
  };

  React.useEffect(() => {
    handleSelectChange();
  }, [inputValues]);


  const { enqueueSnackbar } = useSnackbar();


  React.useEffect(() => {
    getAttributesTypes();
    getValidationsTypes();

    if (editId !== "") {
      getSingleAttribute(editId);

    }

    return () => {
      setEditId("");
    };
  }, [editId]);





  const getAttributesTypes = async () => {
    const response = await getAttributeTypes();
    if (response.code === 200) {
      setattrtypes(response.data);
    }
  };

  // get validation types
  const getValidationsTypes = async () => {
    const response = await getValidationTypes();

    if (response.code === 200) {
      setvalidationtypes(response.data);
    }
  };

  interface ICreateAttrInitialValues {
    code: string | any;
    entity_type: string;
    is_required: boolean;
    validation: string;
    name: string | any;
    type: string;
    is_unique: boolean;
    form_group: "";
    status: boolean;
  }

  const initialValues: ICreateAttrInitialValues = {
    code: editAttributesData?.code ?? "",
    entity_type: editAttributesData?.entity_type ?? selectedData.value,
    is_required: editAttributesData?.is_required === true ? true : false,
    validation: editAttributesData?.validation ?? "",
    name: editAttributesData?.name ?? "",
    type: editAttributesData?.type ?? "",
    is_unique: editAttributesData?.is_unique ?? false,
    form_group: editAttributesData?.form_group ?? "",
    status: editAttributesData?.status === "active" ? true : false ?? false
  };

  const handleSubmit = async (value: ICreateAttrInitialValues) => {
    setisSubmit(true);
    setresponseErr(null);
    if (editId !== "") {

      let payload = {};
      let optionsObject: any = {};

      if (value.type === "multiselect" || value.type === "select") {
        inputValues.forEach((e: any, i: number) => {
          if (e.optionsValue !== null) {
            optionsObject[`option_${i + 1}`] = {
              "name": e.options
            }
          }
        })
      }

      payload = {
        ...value,
        status: value.status ? "active" : "Inactive",
        lookup_type: "null",
        quick_add: "1",
        is_user_defined: true,
        options: (value.type === "multiselect" || value.type === "select") ? optionsObject : null,
      }

      const response = await updateAttribute(
        payload,
        editId
      );
      setisSubmit(false)


      if (response?.code === 200) {
        enqueueSnackbar(response.message, { variant: "success" });
        setsortingData([])
        ToggleCreateAttribute()
      } else if (response?.code === 500) {
        enqueueSnackbar(response.error, { variant: "error", autoHideDuration: 4000 });
      } else if ((response?.code === 422) || response?.errors) {

        setresponseErr(
          {
            options: response.errors.options ? response.errors.options[0] : undefined,
            code: response.errors.code ? response.errors.code[0] : undefined,
            name: response.errors.name ? response.errors.name[0] : undefined,
            type: response.errors.type ? response.errors.type[0] : undefined
          })

      }
      else {
        enqueueSnackbar(response.message, { variant: "error", autoHideDuration: 4000 });
      }

    } else {

      let payload = {};
      let optionsObject: any = {};

      if (value.type === "multiselect" || value.type === "select") {
        inputValues.forEach((e: any, i: number) => {
          if (e.optionsValue !== null) {
            optionsObject[`option_${i + 1}`] = {
              "name": e.options
            }
          }
        })

      }
      payload = {
        ...value,
        status: value.status ? "active" : "Inactive",
        lookup_type: "null",
        quick_add: "1",
        is_user_defined: true,
        options: (value.type === "multiselect" || value.type === "select") ? optionsObject : null,
      }

      const response = await createAttribute(payload);

      setisSubmit(false);

      if (response?.code === 200) {
        enqueueSnackbar(response.message, { variant: "success" });
        setsortingData([])
        ToggleCreateAttribute()
      } else if (response?.code === 500) {
        enqueueSnackbar(response.error, { variant: "error", autoHideDuration: 4000 });
      } else if ((response?.code === 422) || response?.errors) {
        setresponseErr(
          {
            options: response.errors.options ? response.errors.options[0] : undefined,
            code: response.errors.code ? response.errors.code[0] : undefined,
            name: response.errors.name ? response.errors.name[0] : undefined,
            type: response.errors.type ? response.errors.type[0] : undefined
          })

      }
      else {
        enqueueSnackbar(response.message, { variant: "error", autoHideDuration: 4000 });

      }
    }
  };


  const validationSchema = Yup.object().shape({
    code: Yup.string()
      .required(formatMessage({ id: "settings.Auth.dynamicfield.codeerror" }))
      .matches!(/^[a-zA-Z_]+$/, formatMessage({ id: "settings.Auth.dynamicfield.specialcharaceter" }))
    ,
    name: Yup.string()
      .required(
        formatMessage({
          id: "settings.Auth.dynamicfield.nameerror",
        })
      ).matches!(/^[a-zA-Z0-9_^\s]*$/, formatMessage({ id: "settings.dynamicfield.specialcharaceter" })),

    entity_type: Yup.string()
      .trim()
      .required(formatMessage({ id: "settings.Auth.dynamicfield.entitytypeerror" })),
    type: Yup.string()
      .trim()
      .required(formatMessage({ id: "settings.Auth.dynamicfield.fieldtypeerror" })),
    form_group: Yup.string().matches!(/^[a-zA-Z0-9_]*$/, formatMessage({ id: "settings.Auth.dynamicfield.specialcharaceter" }))

  });




  return (
    <>
      <Box
        sx={{
          backgroundColor: "#F7F9FF",
          height: 50,
          display: "flex",
          alignItems: "center",
          paddingLeft: 1,
          fontSize: "15px",
          fontWeight: 700,
        }}
      >
        {editId === "" ? "Create Attribute" : "Edit Attribute"}
      </Box>
      {editId !== "" && initialValues.code === "" ?
        <Box sx={{ width: "100%", height: 150, display: "flex", alignItems: "center", justifyContent: "center" }}>
          <CircularProgress />
        </Box>
        : <Box sx={{ position: "relative" }}>
          <Formik

            initialValues={initialValues}
            validationSchema={validationSchema}
            onSubmit={handleSubmit}
            enableReinitialize
          >
            {({ setFieldValue }) => (
              <Form style={{ height: "auto" }}>
                <FormContainer
                  sx={{ display: "flex", height: 450, justifyContent: "center", flexDirection: "column" }}
                >
                  <Box sx={{ display: "flex", height: 450, justifyContent: "center" }}>
                    {/* Left form inputs */}
                    <Box component="div" sx={{ width: "340px" }}>
                      {/* code */}
                      <OutlinedSelectStyled>
                        <label htmlFor="email">
                          {formatMessage({ id: "settings.Table.Code" })}
                          <RequiredFieldStyle><span>*</span></RequiredFieldStyle>
                        </label>
                        <Field
                          type="text"
                          id="code"
                          name="code"
                          as={OutlinedInputStyled}
                          placeholder="Code"
                          onChange={(event: string) => handleInputChange(event, setFieldValue, "code")}
                        />
                      </OutlinedSelectStyled>
                      <ErrorMessage name="code">
                        {(msg) => <ErrorStyled>{msg}</ErrorStyled>}
                      </ErrorMessage>
                      <InputError>{responseErr?.code ?? ""}</InputError>


                      {/* entity type */}
                      <OutlinedSelectStyled>
                        <label htmlFor="email">
                          {formatMessage({ id: "settings.Table.Entitytype" })}<RequiredFieldStyle><span>*</span></RequiredFieldStyle>
                        </label>
                        <OutlinedInputStyled
                          placeholder={`${selectedData.label}`}
                          value={`${selectedData.value}`}
                          name="entity_type"
                          disabled
                          sx={{
                            '& .MuiInputBase-input': {
                              cursor: 'not-allowed'
                            }
                          }}
                        />
                        <ErrorMessage name="entity_type">
                          {(msg) => <ErrorStyled>{msg}</ErrorStyled>}
                        </ErrorMessage>

                      </OutlinedSelectStyled>
                      <Box sx={{ visibility: "hidden" }}>
                        {(selectedValue === "select" ||
                          selectedValue === "multiselect") && (
                            <Paper
                              elevation={5}
                              style={{ width: "95%", borderRadius: 5 }}
                            >
                              <Box
                                sx={{
                                  width: "95%",
                                  position: "relative",
                                  // backgroundColor: "#f6f6f6",
                                  marginTop: "10px",
                                  borderRadius: 2,
                                  marginLeft: "10px",
                                }}
                              >
                                <OutlinedSelectStyled>
                                  <Field
                                    as="select"
                                    style={{ padding: 10, borderRadius: 5 }}
                                    name="type"
                                    placeholder="Options"
                                  >
                                    <option value={""} placeholder="Options">
                                      {formatMessage({
                                        id: "settings.Createattribute.Option",
                                      })}
                                    </option>
                                  </Field>
                                  <img
                                    src={Downarrow}
                                    style={{ height: "24", width: "22" }}
                                    alt=""
                                  />
                                </OutlinedSelectStyled>
                                <Box>
                                  {inputValues.length > 0 ? (
                                    inputValues.map((data, index) => {
                                      return (
                                        <Box key={index} sx={{ display: "flex" }}>
                                          <Field
                                            onChange={(event: any) =>
                                              handleOnChange(event, index)
                                            }
                                            name="options"
                                            type="text"
                                            value={data.options}
                                            style={{
                                              marginTop: "2%",
                                              width: "100%",
                                            }}
                                          />
                                          <IconButton
                                            onClick={() =>
                                              handleSelectDelete(index)
                                            }
                                          >
                                            <DeleteIcon />
                                          </IconButton>
                                        </Box>
                                      );
                                    })
                                  ) : (
                                    <></>
                                  )}

                                  <Button
                                    onClick={handleSelectAdd}
                                    sx={{
                                      marginTop: "5%",
                                      marginBottom: "5%",
                                      backgroundColor: "#ef770b !important",
                                      color: "#ffffff",
                                    }}
                                    disabled={isDisabled}
                                  >
                                    {formatMessage({
                                      id: "settings.Createattribute.Addoption",
                                    })}
                                  </Button>
                                </Box>
                              </Box>
                            </Paper>
                          )}
                      </Box>

                      {/* is_Required */}
                      <OutlinedSelectStyled>
                        <label htmlFor="email">
                          {formatMessage({ id: "settings.Auth.dynamicfield.isrequired" })}
                        </label>
                        <Field
                          type="Checkbox"
                          name="is_required"
                          value="false"
                          checked={toggleValues.isRequired}
                          onChange={(event: any) => handleInputChange(event, setFieldValue, "is_required")}
                          component={MySpecialField}
                        />
                      </OutlinedSelectStyled>


                      {/* Input validation */}
                      <OutlinedSelectStyled>
                        <label htmlFor="email">
                          {formatMessage({ id: "settings.Auth.dynamicfield.inputvalidation" })}
                        </label>
                        <Field
                          as="select"
                          style={{ padding: 10, borderRadius: 5 }}
                          name="validation"
                        >
                          <option value="" label=" - " />
                          {validationtypes.map((ele: any, index: number) => {
                            return (<option key={index} value={ele.value} label={ele.label} />)
                          })}

                        </Field>
                        <img src={Downarrow} style={{ height: '24', width: "22" }} alt="" />

                      </OutlinedSelectStyled>

                      {/* Status */}
                      <OutlinedCheckboxStyled>
                        <label htmlFor="email">
                          {formatMessage({ id: "settings.Auth.dynamicfield.status" })}
                        </label>
                        <Field
                          type="Checkbox"
                          name="status"
                          checked={toggleValues.status}
                          onChange={(event: any) => handleInputChange(event, setFieldValue, "status")}
                          component={MySpecialField}
                        />
                      </OutlinedCheckboxStyled>


                    </Box>

                    {/* Right form inputs */}
                    <Box
                      component="div"
                      sx={{ width: "340px" }}
                    >
                      {/* name */}
                      <OutlinedSelectStyled>
                        <label htmlFor="email">
                          {formatMessage({ id: "settings.Table.Name" })}<RequiredFieldStyle><span>*</span></RequiredFieldStyle>
                        </label>

                        <Field
                          type="text"
                          id="email"
                          name="name"
                          as={OutlinedInputStyled}
                          placeholder="Name"
                          onChange={(event: string) => handleInputChange(event, setFieldValue, "name")}
                        />
                        <ErrorMessage name="name">
                          {(msg) => <ErrorStyled>{msg}</ErrorStyled>}
                        </ErrorMessage>
                        <InputError>{responseErr?.name ?? ""}</InputError>
                      </OutlinedSelectStyled>

                      {/* field type */}
                      <OutlinedSelectStyled>
                        <label htmlFor="email">
                          {formatMessage({ id: "settings.Table.Fieldtype" })}<RequiredFieldStyle><span>*</span></RequiredFieldStyle>
                        </label>

                        <Field
                          as="select"
                          style={{ padding: 10, borderRadius: 5 }}
                          name="type"
                          onChange={(event: string) =>
                            handleInputChange(event, setFieldValue, "type")
                          }
                        >
                          <option value={""}>
                            -
                          </option>
                          {attrtypes.map((data: any, index: number) => {
                            return (
                              <option key={index} value={data.value}>
                                {data.label}
                              </option>
                            );
                          })}
                        </Field>
                        <img src={Downarrow} style={{ height: '24', width: "22" }} alt="" />

                      </OutlinedSelectStyled>
                      <ErrorMessage name="type">
                        {(msg) => <ErrorStyled>{msg}</ErrorStyled>}
                      </ErrorMessage>
                      <InputError>{responseErr?.options ?? ""}</InputError>
                      <InputError>{responseErr?.type ?? ""}</InputError>

                      {(selectedValue === "select" ||
                        selectedValue === "multiselect")
                        && (
                          <Paper
                            elevation={5}
                            style={{ width: "95%", borderRadius: 5 }}
                          >
                            <Box
                              sx={{
                                width: "95%",
                                position: "relative",
                                marginTop: "10px",
                                borderRadius: 2,
                                marginLeft: "10px",
                              }}
                            >
                              <OutlinedSelectStyled>
                                <Box>
                                  <label>
                                    {formatMessage({
                                      id: "settings.Createattribute.Option",
                                    })}
                                  </label>
                                </Box>


                              </OutlinedSelectStyled>
                              <Box>
                                {inputValues.length > 0 ? (
                                  inputValues.map((data, index) => {
                                    return (
                                      <Box key={index} sx={{ display: "flex" }}>
                                        <Field
                                          onChange={(event: any) =>
                                            handleOnChange(event, index)
                                          }
                                          name="options"
                                          value={data.options}
                                          type="text"
                                          style={{
                                            marginTop: "2%",
                                            width: "100%",
                                          }}
                                        />
                                        <IconButton
                                          onClick={() => inputValues[0]?.optionsValue === null ? null : handleSelectDelete(index)
                                          }
                                        >
                                          <DeleteIcon />
                                        </IconButton>
                                      </Box>
                                    );
                                  })
                                ) : (
                                  <></>
                                )}

                                <Button
                                  onClick={() => isDisabled ? null : handleSelectAdd()}
                                  sx={{
                                    marginTop: "5%",
                                    marginBottom: "5%",
                                    backgroundColor: "#ef770b !important",
                                    color: "#ffffff",
                                    cursor: isDisabled ? "not-allowed" : "pointer"
                                  }}
                                >
                                  {formatMessage({
                                    id: "settings.Createattribute.Addoption",
                                  })}
                                </Button>
                              </Box>
                            </Box>
                          </Paper>
                        )}

                      {/* is_Unique */}
                      <OutlinedSelectStyled>
                        <label htmlFor="email">
                          {formatMessage({ id: "settings.Auth.dynamicfield.isunique" })}
                        </label>
                        <Field
                          type="Checkbox"
                          name="is_unique"
                          value="false"
                          checked={toggleValues.isUnique}
                          onChange={(event: string) => handleInputChange(event, setFieldValue, "is_unique")}
                          component={MySpecialField}
                        />
                      </OutlinedSelectStyled>

                      {/* group code */}
                      <OutlinedSelectStyled>
                        <label htmlFor="email">
                          {formatMessage({ id: "settings.dynamicfield.formgroup" })}
                        </label>

                        <Field
                          type="text"
                          name="form_group"
                          as={OutlinedInputStyled}
                          placeholder="Form_group"
                          onChange={(event: string) => handleInputChange(event, setFieldValue, "form_group")}
                        />
                      </OutlinedSelectStyled>
                      <ErrorMessage name="form_group">
                        {(msg) => <ErrorStyled>{msg}</ErrorStyled>}
                      </ErrorMessage>
                      {/* Buttons */}
                      <Box
                        sx={{
                          display: "flex",
                          position: "reltaive",
                          justifyContent: "end",
                          width: "95%",
                          height: "20%",
                          alignItems: "center",
                          right: "2%"

                        }}
                      >
                        <OutlinedButtonStyled onClick={ToggleCreateAttribute}>
                          {formatMessage({ id: "settings.Createattribute.Cancel" })}
                        </OutlinedButtonStyled>
                        <Box component="div">
                          &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        </Box>
                        <LoadingButtonStyled
                          type="submit"
                          variant="contained"
                          loading={isSubmit}
                        >
                          {editId === "" ? "Save As Attribute" : "Update Attribute"}
                        </LoadingButtonStyled>
                      </Box>

                    </Box>
                  </Box>
                </FormContainer>
              </Form>

            )}
          </Formik>
        </Box>}

    </>
  );
};

export default CreateAttribute;