import ConfirmationPopup from '@/core/components/ConfirmationPopup';
import ArrowDropDownIcon from '@mui/icons-material/ArrowDropDown';
import ArrowDropUpIcon from '@mui/icons-material/ArrowDropUp';
import DragIndicatorIcon from '@mui/icons-material/DragIndicator';
import EditNoteIcon from "@mui/icons-material/EditNote";
import { IconButton, Typography } from "@mui/material";
import Box from "@mui/material/Box";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Tooltip from '@mui/material/Tooltip';
import { useIntl } from "react-intl";
import { DragDropContext, Droppable, Draggable } from "react-beautiful-dnd";

interface ToggleCreateAttributetype {
  attributesData: any;
  ToggleCreateAttribute: () => void;
  DeleteAttributes: (data: number | string) => void;
  setEditId: any;
  setAttributesData: any,
  selectedData: any,
  sortingData: any,
  setsortingData: any
}




const DynamicFieldTable = ({
  attributesData,
  ToggleCreateAttribute,
  DeleteAttributes,
  setEditId,
  sortingData,
  setsortingData,
  setAttributesData
}: ToggleCreateAttributetype) => {
  const TableBodyStyle = {
    width: 30,
    position: "relative",
    color: "#0E0E0E",
    fontSize: "14px",
    fontWeight: 500,

  };

  const { formatMessage } = useIntl();

  const sortBy = (data: string, sort?: string) => {
    setsortingData([])
    console.log('unused', sort)

    // sort by id
    if (data === "id") {
      if (sortingData.length === 0) {
        setsortingData(["id", "desc"])
      } else {
        if (sortingData[1] === "desc") {
          setsortingData(["id", "asc"])
        } else {
          setsortingData(["id", "desc"])
        }

      }
    }

    // sort by name
    if (data === "name") {
      if (sortingData.length === 0) {
        setsortingData(["name", "desc"])
      } else {
        if (sortingData[1] === "desc") {
          setsortingData(["name", "asc"])
        } else {
          setsortingData(["name", "desc"])
        }

      }
    }

    // sort by entity_type
    if (data === "entity_type") {
      if (sortingData.length === 0) {
        setsortingData(["entity_type", "desc"])
      } else {
        if (sortingData[1] === "desc") {
          setsortingData(["entity_type", "asc"])
        } else {
          setsortingData(["entity_type", "desc"])
        }

      }
    }

    // sort by type
    if (data === "type") {
      if (sortingData.length === 0) {
        setsortingData(["type", "desc"])
      } else {
        if (sortingData[1] === "desc") {
          setsortingData(["type", "asc"])
        } else {
          setsortingData(["type", "desc"])
        }
      }
    }

    // sort by code
    if (data === "code") {
      if (sortingData.length === 0) {
        setsortingData(["code", "desc"])
      } else {
        if (sortingData[1] === "desc") {
          setsortingData(["code", "asc"])
        } else {
          setsortingData(["code", "desc"])
        }
      }
    }
  }

  const getItemStyle = (isDragging: any, draggableStyle: any) => ({
    ...draggableStyle,
    background: isDragging ? "#D3D3D3" : "white",
    display: isDragging ? 'flex' : '',
    alignItems: isDragging ? 'center' : '',
    justifyContent: isDragging ? "space-between" : '',
    borderBottom: isDragging ? "red" : 'white',
  });

  const onDragEnd = (result: any) => {

    if (!result.destination) {
      return;
    }
    const items = Array.from(attributesData.data);
    const [reorderedItem] = items.splice(result.source.index, 1);
    items.splice(result.destination.index, 0, reorderedItem);
    setAttributesData({ ...attributesData, data: items });
  };

  const pointerStyle = { cursor: "pointer" };

  return (
    <>
      {attributesData.data?.length === 0 ? <Box sx={{ height: "50vh", display: "flex", justifyContent: 'center', alignItems: "center" }}>
        <Typography sx={{ fontSize: '18px', fontWeight: '700', cursor: "pointer", }}>
          {formatMessage({ id: "settings.Nodata.Found" })}
        </Typography> </Box> :
        <>
          {/* Table header */}
          <TableHead sx={{ backgroundColor: "#F7F9FF" }}>
            <TableRow>
              {/* id */}
              <TableCell align="center" onClick={() => sortBy("id", "desc")} sx={pointerStyle}>
                <Box sx={{ display: 'flex', justifyContent: 'center' }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', fontWeight: 700, fontSize: "1rem" }}>
                    {formatMessage({ id: "settings.Table.Id" })}

                  </Box>
                  {sortingData.length !== 0 && sortingData[0] === "id" && sortingData[1] === "desc" ?
                    <IconButton size='small'>
                      <ArrowDropDownIcon />
                    </IconButton> :
                    sortingData.length !== 0 && sortingData[0] === "id" && sortingData[1] === "asc" ?
                      <IconButton size='small'>
                        <ArrowDropUpIcon />
                      </IconButton> :
                      null
                  }
                </Box>
              </TableCell>

              {/* name */}
              <TableCell align="center" onClick={() => sortBy("code", "desc")} sx={pointerStyle}>
                <Box sx={{ display: 'flex', justifyContent: 'center' }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', fontWeight: 700, fontSize: "1rem" }}>
                    {formatMessage({ id: "settings.Table.Code" })}
                  </Box>
                  {/* {sortingData?.length} */}
                  {sortingData.length !== 0 && sortingData[0] === "code" && sortingData[1] === "desc" ?
                    <IconButton size='small'>
                      <ArrowDropDownIcon />
                    </IconButton> :
                    sortingData.length !== 0 && sortingData[0] === "code" && sortingData[1] === "asc" ?
                      <IconButton size='small'>
                        <ArrowDropUpIcon />
                      </IconButton> :
                      null
                  }
                </Box>
              </TableCell>

              {/* name */}
              <TableCell align="center" onClick={() => sortBy("name", "desc")} sx={pointerStyle}>
                <Box sx={{ display: 'flex', justifyContent: 'center' }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', fontWeight: 700, fontSize: "1rem" }}>
                    {formatMessage({ id: "settings.Table.Name" })}
                  </Box>
                  {sortingData.length !== 0 && sortingData[0] === "name" && sortingData[1] === "desc" ?
                    <IconButton size='small'>
                      <ArrowDropDownIcon />
                    </IconButton> :
                    sortingData.length !== 0 && sortingData[0] === "name" && sortingData[1] === "asc" ?
                      <IconButton size='small'>
                        <ArrowDropUpIcon />
                      </IconButton> :
                      null
                  }
                </Box>
              </TableCell>

              {/* type */}
              <TableCell align="center" onClick={() => sortBy("type", "desc")} sx={pointerStyle}>
                <Box sx={{ display: 'flex', justifyContent: 'center' }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', fontWeight: 700, fontSize: "1rem" }}>
                    {formatMessage({ id: "settings.Table.Type" })}
                  </Box>
                  {sortingData.length !== 0 && sortingData[0] === "type" && sortingData[1] === "desc" ?
                    <IconButton size='small'>
                      <ArrowDropDownIcon />
                    </IconButton> :
                    sortingData.length !== 0 && sortingData[0] === "type" && sortingData[1] === "asc" ?
                      <IconButton size='small'>
                        <ArrowDropUpIcon />
                      </IconButton> :
                      null
                  }
                </Box>
              </TableCell>

              {/* required */}
              <TableCell align="center" sx={pointerStyle}>
                <Box sx={{ display: 'flex', justifyContent: 'center' }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', fontWeight: 700, fontSize: "1rem" }}>
                    {formatMessage({ id: "settings.Table.Required" })}
                  </Box>
                  {sortingData.length !== 0 && sortingData[0] === "code" && sortingData[1] === "desc" ?
                    <IconButton size='small'>
                      <ArrowDropDownIcon />
                    </IconButton> :
                    sortingData.length !== 0 && sortingData[0] === "code" && sortingData[1] === "asc" ?
                      <IconButton size='small'>
                        <ArrowDropUpIcon />
                      </IconButton> :
                      null
                  }
                </Box>
              </TableCell>

              <TableCell align="center">
                <Box sx={{ display: 'flex', justifyContent: 'center' }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', fontWeight: 700, fontSize: "1rem" }}>
                    {formatMessage({ id: "settings.Table.Unique" })}
                  </Box>
                </Box>
              </TableCell>

              <TableCell align="center">
                <Box sx={{ display: 'flex', justifyContent: 'center' }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', fontWeight: 700, fontSize: "1rem" }}>
                    {formatMessage({ id: "settings.Table.FormGroup" })}
                  </Box>
                </Box>
              </TableCell>

              <TableCell align="center">
                <Box sx={{ display: 'flex', justifyContent: 'center' }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', fontWeight: 700, fontSize: "1rem" }}>
                    {formatMessage({ id: "settings.Table.Status" })}
                  </Box>
                </Box>
              </TableCell>

              <TableCell align="center">
                <Box sx={{ display: 'flex', justifyContent: 'center' }}>
                  <Box sx={{ display: 'flex', alignItems: 'center', fontWeight: 700, fontSize: "1rem" }}>
                    {formatMessage({ id: "settings.Table.Action" })}
                  </Box>
                </Box>
              </TableCell>

            </TableRow>
          </TableHead>

          {/* Table Body */}
          <DragDropContext onDragEnd={onDragEnd}>
            <Droppable droppableId="droppable">
              {(provided) => (
                <TableBody{...provided.droppableProps}
                  ref={provided.innerRef}>
                  {attributesData.data?.map((row: any, index: number) => (
                    <Draggable
                      key={row.id}
                      draggableId={"q-" + row.id}
                      index={index}
                    >
                      {(provided, snapshot) => (
                        <TableRow
                          key={index}
                        
                          ref={provided.innerRef}
                          {...provided.draggableProps}
                          {...provided.dragHandleProps}
                          style={getItemStyle(
                            snapshot.isDragging,
                            provided.draggableProps.style
                          )}
                          sx={{
                            "&:last-child td, &:last-child th": { border: 0 } ,
                            'td': { fontSize: 14, padding: '10px 0px', color: '#0E0E0E', fontWeight: 500, textAlign: 'center',
                            borderBottom:snapshot.isDragging?"none":""
                         }
                        }}
                        >
                          <TableCell
                            align="center"
                            sx={TableBodyStyle}
                            component="th"
                            scope="row"
                            width="200px"
                            
                          >
                            <DragIndicatorIcon sx={{ position: "absolute", left: "-1%", bottom: "32%", height: '36%', width: '36%', fill: "#DDE2E4", paddingRight: 50 }} />
                            {row.id}
                          </TableCell>
                          <TableCell align="center" sx={TableBodyStyle}>
                            {row.code}
                          </TableCell>
                          <TableCell align="center" sx={TableBodyStyle}>
                            {row.name}
                          </TableCell>
                          <TableCell align="center" sx={TableBodyStyle}>
                            {row.type}
                          </TableCell>
                          <TableCell align="center" sx={TableBodyStyle}>
                            {row.is_required ? "true" : "false"}
                          </TableCell>
                          <TableCell align="center" sx={TableBodyStyle}>
                            {row.is_unique ? "true" : "false"}
                          </TableCell>
                          <TableCell align="center" sx={TableBodyStyle}>
                            {row.form_group}
                          </TableCell>
                          <TableCell align="center" sx={TableBodyStyle}>
                            {row.status}
                          </TableCell>
                          <TableCell align="center" sx={TableBodyStyle}>
                            {" "}
                            <Box sx={{ display: "flex", justifyContent: row.is_user_defined ? "center" : null }}>
                              <Tooltip title="Edit" placement="top">
                                <IconButton
                                  onClick={() => {
                                    ToggleCreateAttribute();
                                    setEditId(row.id);
                                  }}
                                >
                                  <EditNoteIcon />
                                </IconButton>
                              </Tooltip>

                              {!row.is_user_defined ?
                                <Tooltip title="Delete" placement="top">
                                  <ConfirmationPopup title={formatMessage({ id: "settings.dynamicfield.deleteconfirmation" })} callBack={() => DeleteAttributes(row.id)} />
                                </Tooltip>
                                : null}
                            </Box>
                          </TableCell>
                        </TableRow>
                      )}
                    </Draggable>
                  ))}
                  {provided.placeholder}
                </TableBody>
              )}
            </Droppable>
          </DragDropContext>
        </>
      }
    </>
  );
};

export default DynamicFieldTable;
