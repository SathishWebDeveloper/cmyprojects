/**
 *
 * This component is the skeleton around the actual pages, and should only
 * contain code that should be seen on all pages. (e.g. navigation bar)
 *
 */

import React from "react";
import {
    Route,
    Routes
} from "react-router-dom";
import DynamicFields from "@/plugins/settings/pages/dynamic-fields";
import MasterForm from "@/plugins/settings/pages/master-form";
import Error404 from "@/core/pages/Errors/404";

const App: React.FC = () => {
    return (
        <Routes >
            <Route path={'dynamic-field'} element={<DynamicFields />} />
            <Route path={'master-form'} element={<MasterForm />} />
            <Route path={'*'} element={<Error404 />} />
        </Routes>
    )
};

export default App;