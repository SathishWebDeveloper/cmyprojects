import { API_METHODS } from "@/types/common";

export const PLUGINS_API_END_POINTS = {
    // Get all in single
    getMasterFormAllData:  { endPoint: 'api/registration-management/masters', method: API_METHODS.GET },
    createMasterFormAllData:{ endPoint: 'api/registration-management/masters', method: API_METHODS.POST},
    MasterFormAllEditResponse: { endPoint: 'api/registration-management/masters', method: API_METHODS.GET },
    updateAllMasterFormResponse: { endPoint: 'api/registration-management/masters', method: API_METHODS.PUT },
    MasterFormDeleteResponse: { endPoint: 'api/registration-management/masters', method: API_METHODS.DELETE }
}

