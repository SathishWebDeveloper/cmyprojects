import { apiBaseUrl, request } from "@/core/utils";
import { PLUGINS_API_END_POINTS } from "@/plugins/settings/pages/master-form/RegistrationManagment/api/api-constants";



export const getMasterFormAllItems = async (item: string,sorting:{ orderBy: string, sortedBy: string, limit: number, page: number }) => {

    const getAllClassMasterFormResponse = await request({
        url: `${apiBaseUrl + PLUGINS_API_END_POINTS.getMasterFormAllData.endPoint}/${item}`,
        method: PLUGINS_API_END_POINTS.getMasterFormAllData.method,
        params:sorting
    })
     return getAllClassMasterFormResponse;

}

export const createMasterFormAllItems = async (item: string,data: any) => {
    const createAllClassMasterFormResponse = await request({
        url: `${apiBaseUrl + PLUGINS_API_END_POINTS.createMasterFormAllData.endPoint}/${item}`,
        method: PLUGINS_API_END_POINTS.createMasterFormAllData.method,
        body: { ...data },
    })
     return createAllClassMasterFormResponse;
}

//get for edit
export const getMasterFormEditAllResponse = async (item: string,data: any) => {
    const AllMasterFormEditResponse = await request({
        url: `${apiBaseUrl + PLUGINS_API_END_POINTS.MasterFormAllEditResponse.endPoint}/${item}/${data}`,
        method: PLUGINS_API_END_POINTS.MasterFormAllEditResponse.method,
    })
    return AllMasterFormEditResponse;
}

//update
export const AllMasterFormUpdateResponse = async (item: string|undefined,data: any, id: number | string) => {
    const updateMasterFormResponse = await request({
        url: `${apiBaseUrl + PLUGINS_API_END_POINTS.updateAllMasterFormResponse.endPoint}/${item}/${id}`,
        method: PLUGINS_API_END_POINTS.updateAllMasterFormResponse.method,
        body: { ...data },
    });
    return updateMasterFormResponse;
}

//delete
//delete  in master form
export const deleteAllMasterFormById = async (item: string,data: any) => {
    const deleteMasterForm = await request({
        url: `${apiBaseUrl + PLUGINS_API_END_POINTS.MasterFormDeleteResponse.endPoint}/${item}/${data}`,
        method: PLUGINS_API_END_POINTS.MasterFormDeleteResponse.method,
    })
    return deleteMasterForm;
}





