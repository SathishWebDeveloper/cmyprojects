import welcomeFormImage from "@/assets/images/welcome-image.svg";
import { Box, Stack, Typography } from "@mui/material";
import ReligionComponent from "../Religion";
import NationalityComponent from "../Nationality";
import SectionComponent from "../Section";
import ProfessionComponent from "../Profession";
import DesignationComponent from "../Designation";
import WingComponent from "../Wing";
import GradeComponent from "../Grade";


interface IRightContainerInterface {
    showFormContainer: string[];
    handleAddFormDisplay: () => void;
    isChecked: boolean;
    handleCheckboxStatus: () => void;
    showAddForm: boolean;
    showDataForm: any;
    GetAllReligionForm: (data?:string|undefined) => void;
    isTableFetchLoader: boolean;
    isEditForm: boolean;
    handleSubmit: () => void;
    editAttributesData: any;
    isSubmit: boolean;
    toggleValues: { status: boolean };
    setToggleValues: (data: any) => void;
    responseErr: any;
    setresponseErr: any;
    selectedItemData: string;
    sortingData: Array<string>;
    setsortingData: (data?: any) => void;
    setShowDataForm: any;
    isEditId: number | string | null;
    perPageValue: number;
    selectPageCount: number;
    DeleteMasterFormByID: (data: any, id: number) => void;
    setPerPageValue: (data?: any) => void;
    setSelectPageCount: (data?: any) => void;
    EditAllMasterFormApi: (data: string, index: number, selectedData: string, item: any) => void;
    showLoader:boolean;
    setsearchInTable:(data?: any) => void;
    searchInTable:string
}


const RegistrationRightContainer = ({ showFormContainer, handleAddFormDisplay, isChecked, handleCheckboxStatus,
    showAddForm, showDataForm, GetAllReligionForm, isTableFetchLoader, isEditForm, handleSubmit, editAttributesData,
    isSubmit, toggleValues, setToggleValues, responseErr, setresponseErr, selectedItemData, sortingData, setsortingData, setShowDataForm, isEditId, DeleteMasterFormByID, EditAllMasterFormApi, perPageValue, selectPageCount, setPerPageValue, setSelectPageCount , showLoader,
    setsearchInTable,searchInTable
}: IRightContainerInterface) => {



console.log(showFormContainer);

    return (
        <>
            {showFormContainer[0] === "religion" ?
                <ReligionComponent
                    handleAddFormDisplay={handleAddFormDisplay}
                    isChecked={isChecked}
                    handleCheckboxStatus={handleCheckboxStatus}
                    showAddForm={showAddForm}
                    showDataForm={showDataForm}
                    GetAllReligionForm={GetAllReligionForm}
                    isTableFetchLoader={isTableFetchLoader}
                    isEditForm={isEditForm}
                    handleSubmit={handleSubmit}
                    editAttributesData={editAttributesData}
                    isSubmit={isSubmit}
                    toggleValues={toggleValues}
                    setToggleValues={setToggleValues}
                    responseErr={responseErr}
                    setresponseErr={setresponseErr}
                    selectedItemData={selectedItemData}
                    setsortingData={setsortingData}
                    sortingData={sortingData}
                    setShowDataForm={setShowDataForm}
                    isEditId={isEditId}
                    DeleteMasterFormByID={DeleteMasterFormByID}
                    EditAllMasterFormApi={EditAllMasterFormApi}
                    selectPageCount={selectPageCount}
                    perPageValue={perPageValue}
                    setSelectPageCount={setSelectPageCount}
                    setPerPageValue={setPerPageValue}
                    showLoader={showLoader}
                    setsearchInTable={setsearchInTable}
                     searchInTable={searchInTable}
                /> : showFormContainer[0] === "nationality" ?
                    <NationalityComponent
                        handleAddFormDisplay={handleAddFormDisplay}
                        isChecked={isChecked}
                        handleCheckboxStatus={handleCheckboxStatus}
                        showAddForm={showAddForm}
                        showDataForm={showDataForm}
                        GetAllReligionForm={GetAllReligionForm}
                        isTableFetchLoader={isTableFetchLoader}
                        isEditForm={isEditForm}
                        handleSubmit={handleSubmit}
                        editAttributesData={editAttributesData}
                        isSubmit={isSubmit}
                        toggleValues={toggleValues}
                        setToggleValues={setToggleValues}
                        responseErr={responseErr}
                        setresponseErr={setresponseErr}
                        selectedItemData={selectedItemData}
                        setsortingData={setsortingData}
                        sortingData={sortingData}
                        setShowDataForm={setShowDataForm}
                        isEditId={isEditId}
                        DeleteMasterFormByID={DeleteMasterFormByID}
                        EditAllMasterFormApi={EditAllMasterFormApi}
                        selectPageCount={selectPageCount}
                        perPageValue={perPageValue}
                        setSelectPageCount={setSelectPageCount}
                        setPerPageValue={setPerPageValue}
                        showLoader={showLoader}
                        setsearchInTable={setsearchInTable}
                        searchInTable={searchInTable}
                    /> : showFormContainer[0] === "section" ?
                        <SectionComponent
                            handleAddFormDisplay={handleAddFormDisplay}
                            isChecked={isChecked}
                            handleCheckboxStatus={handleCheckboxStatus}
                            showAddForm={showAddForm}
                            showDataForm={showDataForm}
                            GetAllReligionForm={GetAllReligionForm}
                            isTableFetchLoader={isTableFetchLoader}
                            isEditForm={isEditForm}
                            handleSubmit={handleSubmit}
                            editAttributesData={editAttributesData}
                            isSubmit={isSubmit}
                            toggleValues={toggleValues}
                            setToggleValues={setToggleValues}
                            responseErr={responseErr}
                            setresponseErr={setresponseErr}
                            selectedItemData={selectedItemData}
                            setsortingData={setsortingData}
                            sortingData={sortingData}
                            setShowDataForm={setShowDataForm}
                            isEditId={isEditId}
                            DeleteMasterFormByID={DeleteMasterFormByID}
                            EditAllMasterFormApi={EditAllMasterFormApi}
                            selectPageCount={selectPageCount}
                            perPageValue={perPageValue}
                            setSelectPageCount={setSelectPageCount}
                            setPerPageValue={setPerPageValue}
                            showLoader={showLoader}
                            setsearchInTable={setsearchInTable}
                            searchInTable={searchInTable}
                        /> : showFormContainer[0] === "profession" ?
                            <ProfessionComponent
                                handleAddFormDisplay={handleAddFormDisplay}
                                isChecked={isChecked}
                                handleCheckboxStatus={handleCheckboxStatus}
                                showAddForm={showAddForm}
                                showDataForm={showDataForm}
                                GetAllReligionForm={GetAllReligionForm}
                                isTableFetchLoader={isTableFetchLoader}
                                isEditForm={isEditForm}
                                handleSubmit={handleSubmit}
                                editAttributesData={editAttributesData}
                                isSubmit={isSubmit}
                                toggleValues={toggleValues}
                                setToggleValues={setToggleValues}
                                responseErr={responseErr}
                                setresponseErr={setresponseErr}
                                selectedItemData={selectedItemData}
                                setsortingData={setsortingData}
                                sortingData={sortingData}
                                setShowDataForm={setShowDataForm}
                                isEditId={isEditId}
                                DeleteMasterFormByID={DeleteMasterFormByID}
                                EditAllMasterFormApi={EditAllMasterFormApi}
                                selectPageCount={selectPageCount}
                                perPageValue={perPageValue}
                                setSelectPageCount={setSelectPageCount}
                                setPerPageValue={setPerPageValue}
                                showLoader={showLoader}
                                setsearchInTable={setsearchInTable}
                                searchInTable={searchInTable}
                            /> : showFormContainer[0] === "designation" ?
                                <DesignationComponent
                                    handleAddFormDisplay={handleAddFormDisplay}
                                    isChecked={isChecked}
                                    handleCheckboxStatus={handleCheckboxStatus}
                                    showAddForm={showAddForm}
                                    showDataForm={showDataForm}
                                    GetAllReligionForm={GetAllReligionForm}
                                    isTableFetchLoader={isTableFetchLoader}
                                    isEditForm={isEditForm}
                                    handleSubmit={handleSubmit}
                                    editAttributesData={editAttributesData}
                                    isSubmit={isSubmit}
                                    toggleValues={toggleValues}
                                    setToggleValues={setToggleValues}
                                    responseErr={responseErr}
                                    setresponseErr={setresponseErr}
                                    selectedItemData={selectedItemData}
                                    setsortingData={setsortingData}
                                    sortingData={sortingData}
                                    setShowDataForm={setShowDataForm}
                                    isEditId={isEditId}
                                    DeleteMasterFormByID={DeleteMasterFormByID}
                                    EditAllMasterFormApi={EditAllMasterFormApi}
                                    selectPageCount={selectPageCount}
                                    perPageValue={perPageValue}
                                    setSelectPageCount={setSelectPageCount}
                                    setPerPageValue={setPerPageValue}
                                    showLoader={showLoader}
                                    setsearchInTable={setsearchInTable}
                                    searchInTable={searchInTable}
                                /> : showFormContainer[0] === "wing" ?
                                    <WingComponent
                                        handleAddFormDisplay={handleAddFormDisplay}
                                        isChecked={isChecked}
                                        handleCheckboxStatus={handleCheckboxStatus}
                                        showAddForm={showAddForm}
                                        showDataForm={showDataForm}
                                        GetAllReligionForm={GetAllReligionForm}
                                        isTableFetchLoader={isTableFetchLoader}
                                        isEditForm={isEditForm}
                                        handleSubmit={handleSubmit}
                                        editAttributesData={editAttributesData}
                                        isSubmit={isSubmit}
                                        toggleValues={toggleValues}
                                        setToggleValues={setToggleValues}
                                        responseErr={responseErr}
                                        setresponseErr={setresponseErr}
                                        selectedItemData={selectedItemData}
                                        setsortingData={setsortingData}
                                        sortingData={sortingData}
                                        setShowDataForm={setShowDataForm}
                                        isEditId={isEditId}
                                        DeleteMasterFormByID={DeleteMasterFormByID}
                                        EditAllMasterFormApi={EditAllMasterFormApi}
                                        selectPageCount={selectPageCount}
                                        perPageValue={perPageValue}
                                        setSelectPageCount={setSelectPageCount}
                                        setPerPageValue={setPerPageValue}
                                        showLoader={showLoader}
                                        setsearchInTable={setsearchInTable}
                                        searchInTable={searchInTable}
                                    /> : showFormContainer[0] === "grade" ?
                                        <GradeComponent
                                            handleAddFormDisplay={handleAddFormDisplay}
                                            isChecked={isChecked}
                                            handleCheckboxStatus={handleCheckboxStatus}
                                            showAddForm={showAddForm}
                                            showDataForm={showDataForm}
                                            GetAllReligionForm={GetAllReligionForm}
                                            isTableFetchLoader={isTableFetchLoader}
                                            isEditForm={isEditForm}
                                            handleSubmit={handleSubmit}
                                            editAttributesData={editAttributesData}
                                            isSubmit={isSubmit}
                                            toggleValues={toggleValues}
                                            setToggleValues={setToggleValues}
                                            responseErr={responseErr}
                                            setresponseErr={setresponseErr}
                                            selectedItemData={selectedItemData}
                                            setsortingData={setsortingData}
                                            sortingData={sortingData}
                                            setShowDataForm={setShowDataForm}
                                            isEditId={isEditId}
                                            DeleteMasterFormByID={DeleteMasterFormByID}
                                            EditAllMasterFormApi={EditAllMasterFormApi}
                                            selectPageCount={selectPageCount}
                                            perPageValue={perPageValue}
                                            setSelectPageCount={setSelectPageCount}
                                            setPerPageValue={setPerPageValue}
                                            showLoader={showLoader}
                                            setsearchInTable={setsearchInTable}
                                            searchInTable={searchInTable}
                                        />
                                        :showFormContainer.length===0? (
                                            <Stack width='60%' alignItems='center' pt='50px' px='50px' gap='10px' boxSizing='border-box'>
                                                <Box width='250px'>
                                                    <img width='100%' height='100%' src={welcomeFormImage} alt='welcome form' />
                                                </Box>
                                                <Typography sx={{ color: '#A2A2A2', fontSize: 19, fontWeight: 500, textAlign: 'center' }}>
                                                    Lorem Ipsum Dolor Sit Amet, Consectetur Adipiscing elit, sed do eiusmod tempo
                                                </Typography>
                                            </Stack>
                                        ):null}</>

    )
}



export default RegistrationRightContainer;