import { ErrorStyled, FormContainer, InputError, } from "@/core/pages/Login/components/LoginStyled";
import SearchTextField from "@/plugins/settings/components/SearchTextField";
import { AddBox } from "@mui/icons-material";
import { Box, Stack, Switch, Typography } from "@mui/material";
import { ErrorMessage, Field, Form, Formik } from "formik";
import { useIntl } from "react-intl";
import * as Yup from "yup";
import Filter from "@/plugins/settings/pages/master-form/Filter/index";
import { LoadingButtonStyledMasterForm, OutlinedButtonStyledMasterForm, OutlinedInputStyledMasterForm, OutlinedSelectStyledMasterForm, RequiredFieldStyleMasterForm, StyledAddBtn, StyledContainer, StyledPrimaryButton, StyledSecondaryButton } from "@/plugins/settings/pages/master-form/MasterFormStyled";
import DragableTable from "@/plugins/settings/pages/master-form/components/DragableTable";
import CircularProgress from '@mui/material/CircularProgress';

interface IReligionInterface {
    handleAddFormDisplay: () => void;
    isChecked: boolean;
    handleCheckboxStatus: () => void;
    showAddForm: boolean;
    showDataForm: any;
    GetAllReligionForm: () => void;
    isTableFetchLoader: boolean;
    isEditForm: boolean;
    handleSubmit: (values: any, type: string) => void;
    editAttributesData: any;
    isSubmit: boolean;
    toggleValues: { status: boolean };
    setToggleValues: (data: any) => void;
    responseErr: any;
    setresponseErr: any;
    selectedItemData: string;
    sortingData: Array<string>;
    setShowDataForm: any;
    setsortingData: (data?: any) => void;
    isEditId: number | string | null;
    perPageValue: number;
    selectPageCount: number;
    setPerPageValue: any;
    setSelectPageCount: any;
    DeleteMasterFormByID: (data: any, id: number) => void;
    EditAllMasterFormApi: (data: string, index: number, selectedData: string, item: any) => void;
    showLoader:boolean;
    setsearchInTable: (data?: any) => void;
    searchInTable: string;
}


interface ICreateAttrInitialValues {
    priority: number | any;
    wing: string | any;
    status: boolean;
}

function WingComponent({ handleAddFormDisplay, isChecked, handleCheckboxStatus,
    showAddForm, showDataForm, GetAllReligionForm, isTableFetchLoader, isEditForm, handleSubmit, editAttributesData, isSubmit, toggleValues, setToggleValues, responseErr, setresponseErr, selectedItemData, sortingData, setsortingData, setShowDataForm, isEditId, DeleteMasterFormByID, EditAllMasterFormApi,perPageValue, selectPageCount, setPerPageValue, setSelectPageCount ,showLoader
,setsearchInTable, searchInTable
}: IReligionInterface) {

    const { formatMessage } = useIntl();

    const MySpecialField = (setFieldValue: any) => {
        return <Switch {...setFieldValue} color="warning" />;
    };

    const initialValues: ICreateAttrInitialValues = {
        priority: editAttributesData?.priority ?? "",
        wing: editAttributesData?.wing ?? "",
        status: editAttributesData?.status === "active" ? true : false ?? false
    };

    const validationSchema = Yup.object().shape({
        wing: Yup.string()
            .required(
                formatMessage({
                    id: "settings.masterform.Field.required",
                })
            ).matches!(/^[a-zA-Z0-9_]*$/, formatMessage({ id: "settings.masterform.specialcharaceterandspace" })),

    });


    const handleInputChange = (e: any, setFieldValue: any, textValue: string) => {
        const inputValue = e.target.value.toLowerCase();

        if (textValue === "wing") {
            setresponseErr(null);
            setFieldValue("wing", inputValue);
        }
        else if (textValue === "priority") {
            setresponseErr(null);
            setFieldValue("priority", inputValue);
        }
        else if (textValue === "status") {
            setresponseErr(null);
            setFieldValue("status", e.target.checked ? true : false);
            setToggleValues(({ status: e.target.checked ? true : false }))
        }
    };

    const searchFilteredData: object[] = showDataForm.data.filter((item: any) => {
        if (searchInTable === "") {
            return item
        } else {
            return item[selectedItemData]?.toLowerCase().includes(searchInTable)
          }
    })


    return (
        <Box width='60%'>
            <StyledContainer>
                {/* form details  */}
                {!showAddForm ? (
                    <Box>
                        {!isChecked ? (
                            <Stack
                                direction='row' p='15px' justifyContent='space-between' alignItems='center' flexWrap='wrap' rowGap='5px'
                                sx={{ minHeight: '73px', boxSizing: 'border-box' }}
                            >
                                <Stack direction='row' width={{ xs: '180px', sm: '50%', md: '40%' }} alignItems='center' gap='8px'>
                                    <Box width={{ xs: '180px', sm: '50%', md: '40%' }} onChange={(event: React.ChangeEvent<HTMLInputElement>) => setsearchInTable(event.target.value)}>
                                        <SearchTextField placeholder={formatMessage({ id: "settings.masterform.searchfield" })} />
                                    </Box>
                                    <Filter />
                                </Stack>
                                <StyledAddBtn
                                    onClick={() => handleAddFormDisplay()}
                                >
                                    <AddBox />
                                    <Typography>{formatMessage({
                                        id: "settings.masterform.Addwing",
                                    })}</Typography>
                                </StyledAddBtn>
                            </Stack>
                        ) : (
                            <Stack
                                direction='row' p='15px' justifyContent='end' alignItems='center' gap='15px' flexWrap='wrap' rowGap='5px'
                                sx={{ minHeight: '73px', boxSizing: 'border-box', }}
                            >
                                <StyledSecondaryButton>{formatMessage({
                                    id: "settings.master.Changestatus",
                                })}</StyledSecondaryButton>
                                <StyledPrimaryButton>{formatMessage({
                                    id: "settings.master.Deleteall",
                                })}</StyledPrimaryButton>
                            </Stack>
                        )}

                        <Box p={1}>
                            <DragableTable
                                checked={isChecked}
                                handleCheckbox={handleCheckboxStatus}
                                handleAddFormDisplay={handleAddFormDisplay}
                                showDataForm={showDataForm}
                                showDeleteForms={GetAllReligionForm}
                                isTableFetchLoader={isTableFetchLoader}
                                selectedItemData={selectedItemData}
                                setsortingData={setsortingData}
                                sortingData={sortingData}
                                setShowDataForm={setShowDataForm}
                                DeleteMasterFormByID={DeleteMasterFormByID}
                                EditAllMasterFormApi={EditAllMasterFormApi}
                                selectPageCount={selectPageCount}
                                perPageValue={perPageValue}
                                setSelectPageCount={setSelectPageCount}
                                setPerPageValue={setPerPageValue}
                                showLoader={showLoader}
                                searchFilteredData={searchFilteredData}
                                setsearchInTable={setsearchInTable}
                            />
                        </Box>
                    </Box>
                ) : (
                    <>
                        {isEditId !== "" && initialValues.priority === "" && isEditForm ?
                            (
                                <Box sx={{ width: "100%", height: 150, display: "flex", alignItems: "center", justifyContent: "center" }}>
                                    <CircularProgress />
                                </Box>
                            )
                            :
                            (
                                <Stack p={'15px'} gap='20px'>
                                    <Stack direction='row' justifyContent='space-between' alignItems='center'>
                                        <Typography sx={{ fontSize: 17, fontWeight: 700, color: '#252525' }}>
                                            {isEditForm ? "Edit Details" : "Add Details"}
                                        </Typography>
                                    </Stack>
                                    <Stack p={"15px"} gap="20px">
                                        <Box>
                                            <Formik initialValues={initialValues}
                                                validationSchema={validationSchema}
                                                onSubmit={(values) => handleSubmit(values, "wing")}
                                                enableReinitialize>
                                                {({ setFieldValue }) => (
                                                    <Form>
                                                        <FormContainer
                                                            sx={{
                                                                display: "flex",
                                                                justifyContent: "center",
                                                                flexDirection: "column",
                                                            }}
                                                        >
                                                            <Box
                                                                sx={{
                                                                    display: "flex",
                                                                    justifyContent: "space-evenly",
                                                                }}
                                                            >
                                                                <Box component="div" sx={{ width: "340px" }}>
                                                                    <OutlinedSelectStyledMasterForm>
                                                                        <label>
                                                                            {formatMessage({
                                                                                id: "settings.masterform.wing",
                                                                            })}
                                                                            <RequiredFieldStyleMasterForm>
                                                                                <span>*</span>
                                                                            </RequiredFieldStyleMasterForm>
                                                                        </label>
                                                                        <Field
                                                                            type="text"
                                                                            as={OutlinedInputStyledMasterForm}
                                                                            placeholder="Enter wing"
                                                                            name="wing"
                                                                            id="wing"
                                                                            onChange={(event: string) =>
                                                                                handleInputChange(
                                                                                    event,
                                                                                    setFieldValue,
                                                                                    "wing"
                                                                                )
                                                                            }
                                                                        />
                                                                    </OutlinedSelectStyledMasterForm>
                                                                    <ErrorMessage name="wing">
                                                                        {(msg) => <ErrorStyled>{msg}</ErrorStyled>}
                                                                    </ErrorMessage>
                                                                    <InputError>{responseErr?.wing ?? ""}</InputError>


                                                                    {/* status */}
                                                                    <OutlinedSelectStyledMasterForm>
                                                                        <label htmlFor="status">
                                                                            {formatMessage({
                                                                                id: "settings.masterform.status",
                                                                            })}
                                                                            <RequiredFieldStyleMasterForm>
                                                                                <span>*</span>
                                                                            </RequiredFieldStyleMasterForm>
                                                                        </label>
                                                                        <Field
                                                                            type="Checkbox"
                                                                            name="status"
                                                                            value="false"

                                                                            checked={toggleValues.status}
                                                                            onChange={(event: any) => handleInputChange(event, setFieldValue, "status")}
                                                                            component={MySpecialField}
                                                                        />
                                                                    </OutlinedSelectStyledMasterForm>
                                                                    <ErrorMessage name="status">
                                                                        {(msg) => <ErrorStyled>{msg}</ErrorStyled>}
                                                                    </ErrorMessage>
                                                                    <InputError>{responseErr?.status ?? ""}</InputError>
                                                                </Box>
                                                                <Box component="div" sx={{ width: "340px" }}>
                                                                    <OutlinedSelectStyledMasterForm>
                                                                        <label>
                                                                            {formatMessage({
                                                                                id: "settings.masterform.priority",
                                                                            })}
                                                                            <RequiredFieldStyleMasterForm>
                                                                                <span>*</span>
                                                                            </RequiredFieldStyleMasterForm>
                                                                        </label>
                                                                        <Field
                                                                            type="number"
                                                                            as={OutlinedInputStyledMasterForm}
                                                                            placeholder="Enter Priority"
                                                                            name="priority"
                                                                            onChange={(event: string) =>
                                                                                handleInputChange(
                                                                                    event,
                                                                                    setFieldValue,
                                                                                    "priority"
                                                                                )
                                                                            }
                                                                        />
                                                                    </OutlinedSelectStyledMasterForm>
                                                                    <ErrorMessage name="priority">
                                                                        {(msg) => <ErrorStyled>{msg}</ErrorStyled>}
                                                                    </ErrorMessage>
                                                                    <InputError>{responseErr?.priority ?? ""}</InputError>
                                                                    <Box
                                                                        sx={{
                                                                            display: "flex",
                                                                            position: "reltaive",
                                                                            justifyContent: "end",
                                                                            width: "95%",
                                                                            height: "70%",
                                                                            alignItems: "center",
                                                                            right: "2%",
                                                                        }}
                                                                    >
                                                                        <OutlinedButtonStyledMasterForm
                                                                            onClick={handleAddFormDisplay}
                                                                        >
                                                                            {formatMessage({
                                                                                id: "settings.masterform.Cancel",
                                                                            })}
                                                                        </OutlinedButtonStyledMasterForm>
                                                                        <Box component="div">
                                                                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                                                        </Box>
                                                                        <LoadingButtonStyledMasterForm
                                                                            type="submit"
                                                                            variant="contained"
                                                                            loading={isSubmit}
                                                                        >
                                                                            {isEditForm ? "Update " : "Save "}
                                                                        </LoadingButtonStyledMasterForm>
                                                                    </Box>
                                                                </Box>
                                                            </Box>
                                                        </FormContainer>
                                                    </Form>
                                                )}
                                            </Formik>
                                        </Box>
                                    </Stack>
                                </Stack>
                            )
                        }
                    </>
                )}
                {/* and edit form  */}
            </StyledContainer>
        </Box>
    )
}



export default WingComponent;