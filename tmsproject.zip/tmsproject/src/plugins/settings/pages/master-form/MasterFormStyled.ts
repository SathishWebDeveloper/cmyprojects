import styled from "@emotion/styled";
import { LoadingButton } from "@mui/lab";
import { Box, Button, OutlinedInput } from "@mui/material";

export const StyledContainer = styled(Box)(() => ({
    boxShadow: '0px 4px 16px 0px #417EE31A',
    border: '1px solid #F2F4F7',
    borderRadius: '4px',
    backgroundColor: '#fff',
}));

export const StyledSearchContainer = styled('div')(() => ({
    display: 'flex',
    gap: '10px',
    alignItems: 'center',
    borderRadius: '4px',
}));

export const StyledFormButton = styled(Button)(() => ({
    width: '100%',
    justifyContent: 'start',
    padding: '15px 14px',
    gap: '8px',
    textTransform: 'none',
    borderBottom: '1px solid #DDE2E4',
    borderRadius: 0,
    ".MuiTouchRipple-root ": {
        color: '#000000',
    },
}));

export const StyledLetterAvatar = styled('div')((data:any) => ({
    width: '40px',
    height: '40px',
    backgroundColor: data.bgcolor ? data.bgcolor : '#D17777',
    color: '#fff',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: '6px',
    fontSize: 18,
}));

export const StyledFormItemBtn = styled(Button)((data:any) => ({
    backgroundColor: data.selected ? '#fff' : '#F7F9FF',
    width: '100%',
    justifyContent: 'start',
    padding: '15px 30px',
    gap: '8px',
    textTransform: 'none',
    borderBottom: '1px solid #DDE2E4',
    borderRadius: 0,
    ".MuiTouchRipple-root ": {
        color: '#000000',
    },
}));

export const StyledAddBtn = styled(Button)((data:any) => ({
    backgroundColor: data.bgcolor ? data.bgcolor : '#fff',
    padding: '6px 20px',
    gap: '8px',
    textTransform: 'none',
    border: '1px solid #DDE2E4',
    alignItems: 'center',
    ':hover': {
        backgroundColor: data.bgcolor ? data.bgcolor : '#fff',
    },
    'p': {
        fontSize: 13,
        color: data.fontcolor ? data.fontcolor : '#000000',
        fontWeight: 600,
        lineHeight: 1,
    },
    'svg': {
        color: data.iconcolor ? data.iconcolor : '#FF800F',
        fontSize: 25,
    }
}));

export const StyledPrimaryButton = styled(Button)((data:any) => ({
    backgroundColor: '#FF800F',
    color: '#fff',
    fontSize: 13,
    padding: '6px 20px',
    gap: '8px',
    textTransform: 'none',
    // border: '1px solid #DDE2E4',
    ':hover': {
        backgroundColor: '#FF800F',
        ...data.root?.hover
    },
    ...data.root
}));

export const StyledSecondaryButton = styled(Button)((data:any) => ({
    color: '#FF6A31',
    border: '1px solid #FF6A31',
    fontSize: 13,
    padding: '6px 20px',
    gap: '8px',
    textTransform: 'none',
    ...data.root
}));

export const OutlinedInputStyledMasterForm = styled(OutlinedInput)(() => ({
    width: '100%',
    'fieldse': {
        borderColor: '#DDE2E4',
    },
    'input': {
        padding: '8.5px 1px',
        paddingLeft: 10
    },
    'input::placeholder': {
        color: '#B0BABF',
        fontWeight: 100,
        fontSize: 15,
        opacity: 1,

    }
}))

export const RequiredFieldStyleMasterForm = styled(Box)(() => ({
    display: 'inline-block',
    'span': {
        color: "red"
    },
}))

export const OutlinedSelectStyledMasterForm = styled(Box)(() => ({
    width: "95%",
    display: "flex",
    flexDirection: 'column',
    justifyContent: "center",
    position: "relative",
    paddingTop: 10,
    // 'span': {
    //     color: "red"
    // },
    'svg': {
        position: "absolute",
        right: "10px",
        bottom: "5px"
    },
    'img': {
        position: "absolute",
        right: "10px",
        bottom: "5px"
    },
    '>select': {
        borderColor: "#D0D5DD",
        width: "100%",
        color: "#5F5F5F",
        fontWeight: 400,
        fontSize: "12px"
    },
    'label': {
        paddingBottom: 5,
        fontWeight: 500,
        fontSize: "14px"
    }
}))



export const OutlinedCheckboxStyledMasterForm = styled(Box)(() => ({
    width: "95%",
    display: "flex",
    flexDirection: 'row-reverse',
    justifyContent: "start",
    position: "relative",
    paddingTop: 10,

    // 'span': {
    //     color: "red"
    // },
    'svg': {
        position: "absolute",
        right: "10px",
        bottom: "5px"
    },
    'img': {
        position: "absolute",
        right: "10px",
        bottom: "5px"
    },
    '>select': {
        borderColor: "#D0D5DD",
        width: "100%",
        color: "#5F5F5F",
        fontWeight: 400,
        fontSize: "12px"
    },
    'label': {
        paddingBottom: 5,
        fontWeight: 500,
        fontSize: "14px"
    }
}))
export const FilledButtonStyledMasterForm = styled(Button)(() => ({
    backgroundColor: "#FF800F",
    color: "#FFFFFF",
    padding: "10px",
    borderRadius: "5px",
    height: 40,
    fontSize: "13px",
    fontStyle: "normal",
    fontWeight: 600,
    textTransform: "capitalize"
    // width: "158px"
}))


export const OutlinedButtonStyledMasterForm = styled(Button)(() => ({

    color: "#FF6A31",
    padding: "6px",
    borderRadius: "5px",
    height: 40,
    fontSize: "13px",
    fontStyle: "normal",
    fontWeight: 600,
    textTransform: "capitalize",
    border: "1.5px solid #FF6A31"
    // width: "158px"
}))



// Loading button
export const LoadingButtonStyledMasterForm = styled(LoadingButton)(() => ({
   
    textTransform: 'none',
    backgroundColor: '#FF800F',
    padding: "6px",
    borderRadius: "5px",
    height: 40,
    fontSize: "13px",
    '&:hover': {
        backgroundColor: '#FF800F',
    },
}))
