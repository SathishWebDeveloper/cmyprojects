
import ConfirmationPopup from "@/core/components/ConfirmationPopup";
import {
    ArrowBackIosNew, ArrowForwardIos, DragIndicator, EditNote
} from "@mui/icons-material";
import ArrowDropDownIcon from '@mui/icons-material/ArrowDropDown';
import ArrowDropUpIcon from '@mui/icons-material/ArrowDropUp';
import { Box, CircularProgress, FormControl, IconButton, MenuItem, Checkbox as MuiCheckbox, Paper, Select, Stack, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Tooltip, Typography } from "@mui/material";
import { DragDropContext, Draggable, Droppable } from "react-beautiful-dnd";
import { useIntl } from "react-intl";
import ButtonDropdown from "../ButtonDropdown";
import * as React from 'react';

interface IDragableTableInterface {
    checked: boolean;
    handleCheckbox: () => void;
    handleAddFormDisplay: (formData: string, editedData: number | any, masterType?: string) => void;
    showDataForm: any;
    showDeleteForms: () => void;
    isTableFetchLoader: boolean;
    selectedItemData: string;
    sortingData: Array<string>;
    setsortingData: (data?: any) => void;
    setShowDataForm: any;
    perPageValue: number;
    selectPageCount: number;
    setPerPageValue: (data?: any) => void;
    setSelectPageCount: (data?: any) => void;
    DeleteMasterFormByID: (data: any, id: number) => void;
    EditAllMasterFormApi: (data: string, index: number, selectedData: string, item: any) => void;
    showLoader: boolean;
    searchFilteredData: any;
    setsearchInTable: (data?: any) => void;
}

export default function DragableTable({ checked, handleCheckbox, handleAddFormDisplay, showDataForm, showDeleteForms, isTableFetchLoader, selectedItemData, sortingData, setsortingData, setShowDataForm, DeleteMasterFormByID, EditAllMasterFormApi, perPageValue, selectPageCount, setPerPageValue, setSelectPageCount, showLoader, searchFilteredData
    , setsearchInTable
}: IDragableTableInterface) {
    const { formatMessage } = useIntl();
    const paginationValues = [{ lable: 10, value: 10 }, { lable: 25, value: 25 }, { lable: 50, value: 50 }, { lable: 100, value: 100 }];
    const userPerPage = perPageValue;
    const pageCountValue = Math.ceil(showDataForm.pageCount / userPerPage);
    const pagecount = Array.from(Array(pageCountValue).keys(), (x) => x + 1);
    const [editIdLoader, seteditIdLoader] = React.useState<number | null>(null);
    const handleStatusChange = (data: string, index: number, selectedItemData: string, value: any) => {
        if (value) {
            seteditIdLoader(index);
            EditAllMasterFormApi(data, index, selectedItemData, value);
        }
        else if (data = 'delete') {
            seteditIdLoader(index);
        }
    };


    const getItemStyle = (isDragging: any, draggableStyle: any) => ({
        ...draggableStyle,
        padding: isDragging ? "15px 0px" : "0px",
        background: isDragging ? "#D3D3D3" : "white",
        display: isDragging ? 'flex' : '',
        alignItems: isDragging ? 'center' : '',
        justifyContent: isDragging ? "space-between" : '',

    });

    const onDragEnd = (result: any) => {
        if (!result.destination) {
            return;
        }
        const items = Array.from(searchFilteredData);
        const [reorderedItem] = items.splice(result.source.index, 1);
        items.splice(result.destination.index, 0, reorderedItem);
        setShowDataForm({ ...showDataForm, data: items });
    };


    const handlePerPageChange = (event: any) => {
        setsearchInTable("")
        setPerPageValue(event.target.value);
        setSelectPageCount(1);
    };

    const goToNextPage = () => {
        setsearchInTable("")
        if (selectPageCount !== pageCountValue)
            setSelectPageCount(selectPageCount + 1);
    };
    const goToPrevPage = () => {
        setsearchInTable("")
        if (selectPageCount !== 1) setSelectPageCount(selectPageCount - 1);
    };

    const handleChangeSelectPage = (event: any) => {
        setsearchInTable("")
        setSelectPageCount(event.target.value);
    };

    const dropDowndata = [
        {
            name: 'Active',
            value: 'active',
        },
        {
            name: 'inactive',
            value: 'inactive',
        }
    ];



    const sortBy = (data: string) => {
        setsortingData([])

        // sort by master form types
        if (data === selectedItemData) {
            if (sortingData.length === 0) {
                setsortingData([selectedItemData, "desc"])
            } else {
                if (sortingData[1] === "desc") {
                    setsortingData([selectedItemData, "asc"])
                } else {
                    setsortingData([selectedItemData, "desc"])
                }

            }
        }

        // sort by status
        if (data === "status") {
            if (sortingData.length === 0) {
                setsortingData(["status", "desc"])
            } else {
                if (sortingData[1] === "desc") {
                    setsortingData(["status", "asc"])
                } else {
                    setsortingData(["status", "desc"])
                }

            }
        }

    }


    return (
        <>
            {isTableFetchLoader ? (
                <Box
                    component="div"
                    sx={{
                        width: "98%",
                        minHeight: "70vh",
                        flexShrink: 0,
                        background: "#FFF",
                        display: "flex",
                        flexDirection: "column",
                        marginTop: 1,
                        justifyContent: isTableFetchLoader ? "center" : null,
                        alignItems: isTableFetchLoader ? "center" : null,
                    }}
                >
                    <CircularProgress />
                </Box>
            ) : (
                <>
                    {searchFilteredData?.length === 0 || searchFilteredData === null ? (
                        <Box
                            sx={{
                                height: "50vh",
                                display: "flex",
                                justifyContent: "center",
                                alignItems: "center",
                            }}
                        >
                            <Typography
                                sx={{ fontSize: "18px", fontWeight: "700", cursor: "pointer" }}
                            >
                                {formatMessage({ id: "settings.Nodata.Found" })}
                            </Typography>{" "}
                        </Box>
                    ) : (
                        <>
                            <TableContainer component={Paper} style={{ height: "70vh" }}>
                                <Table sx={{ border: '1px solid #DDE2E4', borderRadius: '8px' }}>
                                    <TableHead>


                                        <TableRow sx={{
                                            backgroundColor: '#F7F9FF',
                                            'th': {
                                                fontSize: 13, color: '#5F5F5F', fontWeight: 500, padding: '10px 0px', textAlign: 'center',
                                            }
                                        }}>
                                            <TableCell></TableCell>
                                            <TableCell>
                                                <MuiCheckbox
                                                    checked={checked}
                                                    onChange={handleCheckbox}
                                                />
                                            </TableCell>
                                            <TableCell>
                                                <Stack direction='row' onClick={() => sortBy(selectedItemData)} alignItems='center' gap='5px' sx={{ display: 'inline-flex', cursor: "pointer" }}>
                                                    <Typography sx={{ fontSize: 13, color: '#5F5F5F', fontWeight: 500, }}>{formatMessage({
                                                        id: "settings.masterform.Table.name",
                                                    })}
                                                        {sortingData.length !== 0 && sortingData[0] === selectedItemData && sortingData[1] === "desc" ?
                                                            <IconButton size='small'>
                                                                <ArrowDropDownIcon />
                                                            </IconButton> :
                                                            sortingData.length !== 0 && sortingData[0] === selectedItemData && sortingData[1] === "asc" ?
                                                                <IconButton size='small'>
                                                                    <ArrowDropUpIcon />
                                                                </IconButton> :
                                                                null
                                                        }
                                                    </Typography>
                                                </Stack>
                                            </TableCell>
                                            <TableCell>
                                                <Stack direction='row' onClick={() => sortBy("status")} alignItems='center' gap='5px' sx={{ display: 'inline-flex', cursor: "pointer" }}>
                                                    <Typography sx={{ fontSize: 13, color: '#5F5F5F', fontWeight: 500, }}>{formatMessage({
                                                        id: "settings.masterform.Table.status",
                                                    })}
                                                        {sortingData.length !== 0 && sortingData[0] === "status" && sortingData[1] === "desc" ?
                                                            <IconButton size='small'>
                                                                <ArrowDropDownIcon />
                                                            </IconButton> :
                                                            sortingData.length !== 0 && sortingData[0] === "status" && sortingData[1] === "asc" ?
                                                                <IconButton size='small'>
                                                                    <ArrowDropUpIcon />
                                                                </IconButton> :
                                                                null
                                                        }
                                                    </Typography>
                                                </Stack>
                                            </TableCell>
                                            <TableCell align='center'>{formatMessage({
                                                id: "settings.masterform.Table.options",
                                            })}</TableCell>
                                        </TableRow>
                                    </TableHead>
                                    <DragDropContext onDragEnd={onDragEnd}>
                                        <Droppable droppableId="droppable">
                                            {(provided) => (
                                                <>
                                                    {showLoader ?
                                                        <TableBody>
                                                            <TableRow sx={{
                                                                'td': {
                                                                    fontSize: 14, padding: '10px 0px', color: '#0E0E0E', fontWeight: 500, textAlign: 'center', height: '70vh'
                                                                }
                                                            }}>
                                                                <TableCell colSpan={5}>
                                                                    <CircularProgress size={40} />
                                                                </TableCell>
                                                            </TableRow>
                                                        </TableBody>
                                                        :
                                                        <TableBody
                                                            {...provided.droppableProps}
                                                            ref={provided.innerRef}>
                                                            {searchFilteredData?.map((data: { id: number, religion?: string, nationality?: string, status: string | null, section?: string, wing?: string, profession?: string, designation?: string, grade?: string ,receipt_head?:string }, index: number,) => (
                                                                <Draggable
                                                                    key={data.id}
                                                                    draggableId={"q-" + data.id}
                                                                    index={index}
                                                                >
                                                                    {(provided, snapshot) => (
                                                                        <TableRow
                                                                            ref={provided.innerRef}
                                                                            {...provided.draggableProps}
                                                                            {...provided.dragHandleProps}
                                                                            style={getItemStyle(
                                                                                snapshot.isDragging,
                                                                                provided.draggableProps.style
                                                                            )}

                                                                            sx={{
                                                                                'td': {
                                                                                    fontSize: 14, padding: '10px 0px', color: '#0E0E0E', fontWeight: 500, textAlign: 'center',
                                                                                }
                                                                            }}>
                                                                            <>
                                                                                {
                                                                                    showLoader && data.id === editIdLoader ?
                                                                                        <TableCell colSpan={5}>
                                                                                            <CircularProgress size={35} />
                                                                                        </TableCell>
                                                                                        :
                                                                                        <>
                                                                                            <TableCell sx={{
                                                                                                width: '30px',
                                                                                            }}>
                                                                                                <DragIndicator sx={{ fontSize: 27, color: '#DDE2E4' }} />
                                                                                            </TableCell>
                                                                                            <TableCell sx={{
                                                                                                width: '80px'
                                                                                            }}>
                                                                                                <MuiCheckbox checked={checked}
                                                                                                /> </TableCell>
                                                                                            <TableCell>{data?.religion ?? data.religion ?? data.nationality ?? data.nationality ?? data.section ?? data.section ?? data.wing ?? data.wing ?? data.profession
                                                                                                ?? data.profession ?? data.designation ?? data.designation ?? data.grade ?? data.grade ??
                                                                                                data.receipt_head ?? data.receipt_head 
                                                                                            
                                                                                                }</TableCell>
                                                                                            <TableCell>
                                                                                                <Box sx={{
                                                                                                    minWidth: 120
                                                                                                }}>
                                                                                                    {/* drop down  */}
                                                                                                    <ButtonDropdown
                                                                                                        value={data.status}
                                                                                                        data={dropDowndata}
                                                                                                        onChange={(item) => handleStatusChange(item, data.id, selectedItemData, data)}
                                                                                                        style={{
                                                                                                            select: {
                                                                                                                backgroundColor: data.status === 'active' ? '#e1ecfe' : data.status === 'inactive' ? '#fcd6d6' : '#F5F5F5',
                                                                                                                color: data.status === 'active' ? '#0e5ee1' : data.status === 'inactive' ? '#ef2424' : '#00000',

                                                                                                            },
                                                                                                            root: { width: '100px', borderRadius: '16px', }
                                                                                                        }}
                                                                                                    />
                                                                                                </Box>
                                                                                            </TableCell>
                                                                                            <TableCell align='center' sx={{
                                                                                                width: '80px', 'button': { color: '#252525', 'svg': { fontSize: 20 } }
                                                                                            }}>
                                                                                                <Stack direction='row'>
                                                                                                    <Tooltip title="Edit" placement="top">
                                                                                                        <IconButton onClick={() => handleAddFormDisplay('Edit', data.id, selectedItemData)}>
                                                                                                            <EditNote />
                                                                                                        </IconButton>
                                                                                                    </Tooltip>
                                                                                                    <ConfirmationPopup title={formatMessage({ id: "settings.masterform.deleteconfirmation" })} callBack={() => { DeleteMasterFormByID(selectedItemData, data.id); showDeleteForms(); handleStatusChange('delete', data.id, "", null) }} />
                                                                                                </Stack>
                                                                                            </TableCell>
                                                                                        </>
                                                                                }</>

                                                                        </TableRow>
                                                                    )}

                                                                </Draggable>
                                                            ))
                                                            }
                                                            {provided.placeholder}
                                                        </TableBody>
                                                    }
                                                </>
                                            )}
                                        </Droppable>
                                    </DragDropContext>
                                </Table>
                            </TableContainer>
                            {/* pagination  */}
                            <Stack
                                direction="row"
                                justifyContent="space-between"
                                py="6px"
                                pt="15px"
                                alignItems="center"
                            >
                                <Stack direction="row" gap="5px" alignItems="center">
                                    <FormControl
                                        sx={{ ".MuiSelect-select ": { padding: "5px" } }}
                                    >
                                        <Select value={perPageValue} onChange={handlePerPageChange}>
                                            {paginationValues.map((pageData, pgValue) => {
                                                return (
                                                    <MenuItem key={`${pgValue}`} value={pageData.value}>
                                                        {pageData.lable}
                                                    </MenuItem>
                                                );
                                            })}
                                        </Select>
                                    </FormControl>
                                    <Typography
                                        sx={{ color: "#84919A", fontSize: 13, fontWeight: 400 }}
                                    >
                                        {formatMessage({ id: "settings.Pages.Viewtype" })}
                                    </Typography>
                                </Stack>
                                <Stack direction="row" alignItems="center" gap="3px">
                                    <IconButton
                                        sx={{ p: "3px" }}
                                        onClick={() => {
                                            goToPrevPage();
                                        }}
                                        disabled={selectPageCount === 1}
                                    >
                                        <ArrowBackIosNew />
                                    </IconButton>
                                    <Box
                                        sx={{ display: "flex", gap: "10px", alignItems: "center" }}
                                    >
                                        <Box>
                                            {formatMessage({ id: "settings.Current.Page" })}{" "}
                                            {selectPageCount}{" "}
                                            {formatMessage({ id: "settings.Page.of" })}{" "}
                                            {pageCountValue}
                                        </Box>
                                        <Box sx={{ alignItem: "center" }}>
                                            {formatMessage({ id: "settings.Change.Page" })}
                                            <Select
                                                sx={{
                                                    m: 1,
                                                    minWidth: 70,
                                                    height: 30,
                                                }}
                                                value={selectPageCount}
                                                onChange={handleChangeSelectPage}
                                            >
                                                {pagecount.map((value, index) => {
                                                    return (
                                                        <MenuItem key={`${index}` + 1} value={value}>
                                                            {value}
                                                        </MenuItem>
                                                    );
                                                })}
                                            </Select>
                                        </Box>
                                    </Box>
                                    <IconButton
                                        sx={{ p: "3px" }}
                                        onClick={() => {
                                            goToNextPage();
                                        }}
                                        disabled={selectPageCount === pageCountValue}
                                    >
                                        <ArrowForwardIos />
                                    </IconButton>
                                </Stack>
                            </Stack>
                        </>
                    )}
                </>
            )
            }
        </>
    )
}