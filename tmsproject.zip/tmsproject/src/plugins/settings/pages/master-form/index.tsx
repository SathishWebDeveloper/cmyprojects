import SearchTextField from "@/plugins/settings/components/SearchTextField";
import { StyledContainer, StyledFormButton, StyledFormItemBtn, StyledLetterAvatar } from "@/plugins/settings/pages/master-form/MasterFormStyled";
import { Category, TripOrigin } from "@mui/icons-material";
import React, { useEffect, useState } from "react";
import { Box, Collapse, Stack, Typography } from "@mui/material";
import { AllMasterFormUpdateResponse, createMasterFormAllItems, deleteAllMasterFormById, getMasterFormAllItems, getMasterFormEditAllResponse } from "@/plugins/settings/pages/master-form/RegistrationManagment/api/api-handlers";
import { useSnackbar } from "notistack";
import RegistrationRightContainer from "@/plugins/settings/pages/master-form/RegistrationManagment/components/RegistrationRightContainer";
import { useIntl } from "react-intl";
import FeeMasterRightContainer from "./FeeManagment/components/FeeMasterRightContainer";
import {
    getFeeMasterFormAllItems, createFeeMasterFormAllItems, getFeeMasterFormEditAllResponse,
    updateAllFeeMasterFormResponseById, deleteAllFeeMasterFormById
} from "@/plugins/settings/pages/master-form/FeeManagment/api/api-handlers";

interface ICreateAttrInitialValues {
    priority: number | any;
    religion: string | any;
    status: boolean;
    // depend_on_join:boolean;  // added here 
}

const subListItems = [
    { label: 'Religion', value: 'religion' },
    { label: 'Nationality', value: 'nationality' },
    { label: 'Section', value: 'section' },
    { label: 'Profession', value: 'profession' },
    { label: 'Designation', value: 'designation' },
    { label: 'Grade', value: 'grade' },
    { label: 'Wing', value: 'wing' }
];

const feeSubListItems = [
    { label: "Fee Term Master", value: "fee-term" },
    { label: "Fee Heads", value: "fee-head" },
    { label: "Fee Group", value: "fee-group" },
    { label: "Modules", value: "fee-module" },
    { label: "Fee Receipt Head", value: "fee-receipt" },
    { label: "Fee Payment Type", value: "fee-payment-type" },
    { label: "Fee Counter", value: "fee-counter" },
    { label: "Fee Print Roll Master", value: "print-roll" },
    { label: "Bank", value: "bank" }
];

const getAttrforms = [
    {
        name: 'General Forms',
        category: 'General',
        iconColor: '#D17777',
        listItems: subListItems,
    },
    {
        name: 'Regristration Management',
        category: 'Administration',
        listItems: subListItems,
        iconColor: '#D0BD78',
    },
    {
        name: "Fee Management",
        category: "Administration",
        listItems: feeSubListItems,
        iconColor: "#74CFBF",
    },
    {
        name: 'Front Office Management',
        category: 'Administration',
        listItems: subListItems,
        iconColor: '#77A1D1',
    },
    {
        name: 'Clinic',
        category: 'Administration',
        listItems: subListItems,
        iconColor: '#CF74AB',
    },
    {
        name: 'BagdeMaker',
        category: 'Administration',
        listItems: subListItems,
        iconColor: '#CF74AB',
    },
    {
        name: 'Counsellors',
        category: 'Administration',
        listItems: subListItems,
        iconColor: '#CF74AB',
    },
]

const MasterForm = () => {
    const [showAddForm, setShowAddForm] = React.useState(false);
    const [isChecked, setIsChecked] = React.useState(false);
    const [selectedForm, setSelectedForm] = React.useState<number | null>(null);
    const [showFormContainer, setShowFormContainer] = React.useState<string[]>([]);
    const [selectedItemData, setSelectedItemData] = React.useState<string>("");
    const [selectedItemIndex, setselectedItemIndex] = React.useState<number | null>(null);
    const [selectedMasterFormName, setSelectedMasterFormName] = React.useState<[string] | string>([""]);
    const [isEditForm, setIsEditForm] = React.useState(false);
    const [showDataForm, setShowDataForm] = useState({ data: [], pageCount: 0 });
    const [sortingData, setsortingData] = React.useState([])
    const [isSubmit, setisSubmit] = React.useState(false);
    const [isEditId, setIsEditId] = React.useState('');
    const [editAttributesData, seteditAttributesData] = useState<any>({});
    const [isTableFetchLoader, setisTableFetchLoader] = React.useState(true);
    const [toggleValues, setToggleValues] = React.useState({
        status: false
    });     // added here 
    const [responseErr, setresponseErr] = React.useState<any>(null);
    const [perPageValue, setPerPageValue] = React.useState(10);
    const [selectPageCount, setSelectPageCount] = React.useState(1);
    const [showLoader, setIsShowLoader] = React.useState(false);
    const [searchData, setSearchData] = React.useState<string>("")
    const [searchInTable, setsearchInTable] = React.useState("");

    const { enqueueSnackbar } = useSnackbar();
    const { formatMessage } = useIntl();

    useEffect(() => {
        if (selectedItemData !== "") {
            GetAllMasterFormData(selectedItemData)
        }
    }, [sortingData, perPageValue, selectPageCount])

    const handleCheckboxStatus = () => {
        setIsChecked((prev) => !prev);
    }

    const handleErrorResponse = (response: any) => 
    { const responseKey = Object.entries(response.errors); 
      responseKey.forEach((errs:any) => { setresponseErr((prev:object) => { return { ...prev, [errs[0]]: errs[1][0] } }) })
    return 
}
    const GetEditReligionFormById = async (selectedItemData: string, editId: number) => {
        //Registration management edit
        if (selectedMasterFormName[0] === "Regristration Management") {
            const response = await getMasterFormEditAllResponse(selectedItemData, editId);
            seteditAttributesData(response.data);
            setToggleValues({ status: response.data.status === 'inactive' ? false : true });
        }
        // Fee management edit
        else if (selectedMasterFormName[0] === "Fee Management") {
            const response = await getFeeMasterFormEditAllResponse(selectedItemData, editId);
            seteditAttributesData(response.data);
            setToggleValues({ status: response.data.status === 'inactive' ? false : true });
        }
    }

    const handleAddFormDisplay = (formData?: string, editedData?: number | any) => {
        setsearchInTable("")
        setShowAddForm((prev) => !prev);
        if (formData === 'Edit') {
            setIsEditForm(true);
            GetEditReligionFormById(selectedItemData, editedData);
            setIsEditId(editedData);

            // need to check this
        }
        else {
            setIsEditForm(false)
            setresponseErr(null);
            seteditAttributesData({});
        }
    }

    const handleChange = (index: number) => {
        if (index === selectedForm) {
            setSelectedForm(null);
            return
        }
        setSelectedForm(index)
    };



    const handleButtonClick = (item: string, index: number, data?: any) => {
        setSelectedMasterFormName([data?.name])
        setsearchInTable("")
        setsortingData([])
        setShowAddForm(false);
        setSelectedItemData(item);
        setselectedItemIndex(index);
        setSelectPageCount(1);
    }


    // edit status api call
    const EditAllMasterFormApi = async (data: string, editId: number, selectedItemData: string, list: any) => {
        setIsShowLoader(true);
        let payload = {};
        payload = {
            ...list,
            status: data === "active" ? "active" : "inactive",
        }
        //Registration management edit with update
        if (selectedMasterFormName[0] === "Regristration Management") {
            const response = await AllMasterFormUpdateResponse(selectedItemData, payload, editId);
            if (response?.code === 200) {
                setIsShowLoader(false);
                enqueueSnackbar(response.message, { variant: "success" });
                GetAllMasterFormData(selectedItemData);
            } else if ((response?.code === 422) || response?.errors) {
                setIsShowLoader(false);
                handleErrorResponse(response);
            }
        }
        // Fee management edit with update
        else if (selectedMasterFormName[0] === "Fee Management") {
            const response = await updateAllFeeMasterFormResponseById(selectedItemData, payload, editId);
            if (response?.code === 200) {
                setIsShowLoader(false);
                enqueueSnackbar(response.message, { variant: "success" });
                GetAllMasterFormData(selectedItemData);
            } else if ((response?.code === 422) || response?.errors) {
                setIsShowLoader(false);
                handleErrorResponse(response);
            }

        }


    }


    //DELETE AN MASTER FORM     
    const DeleteMasterFormByID = async (selectedItemData: string, id: number | null | any = null) => {
        setIsShowLoader(true);
        //Registration management delete

        if (selectedMasterFormName[0] === "Regristration Management") {
            const response = await deleteAllMasterFormById(selectedItemData, id);
            if (response.code === 200) {
                setIsShowLoader(false);
                enqueueSnackbar(response.message, { variant: "success" });
                GetAllMasterFormData(selectedItemData);
            }
            else if (response.code === 400) {
                setIsShowLoader(false);
                enqueueSnackbar(response.message, { variant: "error", autoHideDuration: 4000 });
            }

        }
        // Fee management delete
        else if (selectedMasterFormName[0] === "Fee Management") {
            const response = await deleteAllFeeMasterFormById(selectedItemData, id);
            if (response.code === 200) {
                setIsShowLoader(false);
                enqueueSnackbar(response.message, { variant: "success" });
                GetAllMasterFormData(selectedItemData);
            }
            else if (response.code === 400) {
                setIsShowLoader(false);
                enqueueSnackbar(response.message, { variant: "error", autoHideDuration: 4000 });
            }

        }

    };


    const GetAllMasterFormData = async (item: any) => {
        setIsShowLoader(true)


        // Registration form
        if (selectedMasterFormName[0] === "Regristration Management") {
            let sorting: { orderBy: string, sortedBy: string, limit: number, page: number } = { orderBy: sortingData?.length === 0 ? "id" : sortingData[0], sortedBy: sortingData?.length === 0 ? `desc` : `${sortingData[1]}`, limit: perPageValue, page: selectPageCount };
            const response = await getMasterFormAllItems(item, sorting);
            if (response?.code === 200) {
                setShowDataForm({
                    ...showDataForm,
                    data: response.data,
                    pageCount: response.total,
                });
                setisTableFetchLoader(false)
                setIsShowLoader(false)
            }
        }
        // Fee Management
        else if (selectedMasterFormName[0] === "Fee Management") {

            let sorting: { orderBy: string, sortedBy: string, limit: number, page: number } = { orderBy: sortingData?.length === 0 ? "id" : sortingData[0], sortedBy: sortingData?.length === 0 ? `desc` : `${sortingData[1]}`, limit: perPageValue, page: selectPageCount };
            const response = await getFeeMasterFormAllItems(item, sorting);

            if (response?.code === 200) {

                setShowDataForm({
                    ...showDataForm,
                    data: response.data,
                    pageCount: response.total,
                });
                setisTableFetchLoader(false)
                setIsShowLoader(false)
            }
        }

    }



    const handleSubmit = async (value?: ICreateAttrInitialValues, masterType?: string) => {
        setsearchInTable("")
        setisSubmit(true);
        setresponseErr(null);
        if (isEditForm) {
            let payload = {};
            payload = {
                ...value,
                status: value?.status ? "active" : "inactive",
            }
            if (selectedMasterFormName[0] === "Regristration Management") {
                //Registration management update
                const response = await AllMasterFormUpdateResponse(masterType, payload, isEditId);
                setisSubmit(false)
                if (response?.code === 200) {
                    enqueueSnackbar(response.message, { variant: "success" });
                    setShowAddForm((prev) => !prev);

                    // setIsEditForm(false);
                    GetAllMasterFormData(selectedItemData);
                } else if ((response?.code === 422) || response?.errors) {
                    handleErrorResponse(response);
                }
            } else if (selectedMasterFormName[0] === "Fee Management") {
                // Fee management update
                const response = await updateAllFeeMasterFormResponseById(masterType, payload, isEditId);
                setisSubmit(false)
                if (response?.code === 200) {
                    enqueueSnackbar(response.message, { variant: "success" });
                    setShowAddForm((prev) => !prev);

                    // setIsEditForm(false);
                    GetAllMasterFormData(selectedItemData);
                } else if ((response?.code === 422) || response?.errors) {
                    handleErrorResponse(response);
                }

            }



        }
        else {
            let payload = {
                head_name: "Term Feeas Anzczznuals",
                academic_year_code: "2022-23",
                fee_module_id: "2",
                receipt_head_id: "123",
                type: "structured",
                depend_on_join: "yes",
                status: "active"
              }
            // payload = {
            //     ...value,
            //     status: value?.status ? "active" : "inactive",
            //     // depend_on_join : value?.depend_on_join ?"yes" : "no", 
            //     // added here need to add on edit field 
            // }

            console.log('payload value', payload);

            if (selectedMasterFormName[0] === "Regristration Management") {
                //Registration management creation
                const response = await createMasterFormAllItems(selectedItemData, payload);
                setisSubmit(false);
                if (response?.code === 200) {
                    enqueueSnackbar(response.message, { variant: "success" });
                    setShowAddForm((prev) => !prev);
                    GetAllMasterFormData(selectedItemData);
                } else if (response?.code === 500) {
                    enqueueSnackbar(response.error, { variant: "error", autoHideDuration: 4000 });
                }
                else if ((response?.code === 422) || response?.errors) {
                    handleErrorResponse(response);
                }
                else {
                    enqueueSnackbar(response.message, { variant: "error", autoHideDuration: 4000 });
                }
            } else if (selectedMasterFormName[0] === "Fee Management") {
                // Fee management creation
                const response = await createFeeMasterFormAllItems(selectedItemData, payload);
                console.log('payload',payload);
                
                setisSubmit(false);
                if (response?.code === 200) {
                    enqueueSnackbar(response.message, { variant: "success" });
                    setShowAddForm((prev) => !prev);
                    GetAllMasterFormData(selectedItemData);
                } else if (response?.code === 500) {
                    enqueueSnackbar(response.error, { variant: "error", autoHideDuration: 4000 });
                }
                else if ((response?.code === 422) || response?.errors) {
                    handleErrorResponse(response);
                }
                else {
                    enqueueSnackbar(response.message, { variant: "error", autoHideDuration: 4000 });
                }
            }


        }

    };
    const handleFilterChange = (event: any) => { setSearchData(event.target.value.toLowerCase()) };
    const formValue = getAttrforms.filter((item: any) => item.name.toLowerCase().includes(searchData))
    return (
        <Stack direction='row' p='14px' gap={1}>
            {/* left section  */}
            <Box width='40%' >
                <StyledContainer>
                    <Box p='10px' borderBottom='1px solid #E5E9EB'>
                        <Typography component={'h2'} sx={{ fontSize: 16, fontWeight: 700, color: '#000000' }}>
                            {formatMessage({ id: "settings.masterform.Selectform", })}
                        </Typography>
                    </Box>
                    <Box p='15px 10px' m='10px' mb='20px' border='1px solid #E7EAF3'>
                        <Box onChange={handleFilterChange}>
                            <SearchTextField placeholder='Search' />
                        </Box>
                    </Box>
                    <Stack pb={5} sx={{ borderTop: '1px solid #DDE2E4' }}>
                        {
                            formValue.length === 0 ?
                                <Typography
                                    sx={{ fontSize: "18px", fontWeight: "700", cursor: "pointer", textAlign: 'center' }}
                                >
                                    {formatMessage({ id: "settings.Nodata.Found" })}
                                </Typography>
                                :
                                <>
                                    {formValue.map((data, index) => (
                                        <div key={index}>
                                            <StyledFormButton onClick={() => handleChange(index)}>
                                                <StyledLetterAvatar bgcolor={data.iconColor}>R</StyledLetterAvatar>
                                                <Stack>
                                                    <Typography sx={{ fontSize: 15, color: '#252525', fontWeight: 700 }}>
                                                        {data.name}
                                                    </Typography>
                                                    <Stack direction='row' gap='5px' alignItems='end'>
                                                        <Category sx={{ color: '#A2A2A2', fontSize: 16 }} />
                                                        <Typography sx={{ fontSize: 12, color: '#A2A2A2', fontWeight: 500, lineHeight: 1 }}>
                                                            {data.category}
                                                        </Typography>
                                                    </Stack>
                                                </Stack>
                                            </StyledFormButton>

                                            <Collapse in={selectedForm === index ? true : false}>
                                                {data.listItems.map((item, index) => (
                                                    <StyledFormItemBtn
                                                        key={index}
                                                        selected={index === selectedItemIndex ? true : null}
                                                        onClick={() => {
                                                            handleButtonClick(item.value, index, data)
                                                            setShowFormContainer([item.value])
                                                        }}
                                                    >
                                                        <TripOrigin sx={{ fontSize: 10, color: '#252525' }} />
                                                        <Typography sx={{ fontSize: 13, color: '#252525', fontWeight: 600, lineHeight: 1 }}>
                                                            {item.label}
                                                        </Typography>
                                                    </StyledFormItemBtn>
                                                ))}
                                            </Collapse>
                                        </div>
                                    ))}
                                </>

                        }
                    </Stack>
                </StyledContainer>
            </Box>

            {/* right section  */}
            <RegistrationRightContainer
                showFormContainer={showFormContainer}
                handleAddFormDisplay={handleAddFormDisplay}
                isChecked={isChecked}
                handleCheckboxStatus={handleCheckboxStatus}
                showAddForm={showAddForm}
                showDataForm={showDataForm}
                GetAllReligionForm={GetAllMasterFormData}
                isTableFetchLoader={isTableFetchLoader}
                isEditForm={isEditForm}
                handleSubmit={handleSubmit}
                editAttributesData={editAttributesData}
                isSubmit={isSubmit}
                toggleValues={toggleValues}
                setToggleValues={setToggleValues}
                responseErr={responseErr}
                setresponseErr={setresponseErr}
                selectedItemData={selectedItemData}
                setsortingData={setsortingData}
                sortingData={sortingData}
                setShowDataForm={setShowDataForm}
                isEditId={isEditId}
                DeleteMasterFormByID={DeleteMasterFormByID}
                EditAllMasterFormApi={EditAllMasterFormApi}
                selectPageCount={selectPageCount}
                perPageValue={perPageValue}
                setSelectPageCount={setSelectPageCount}
                setPerPageValue={setPerPageValue}
                showLoader={showLoader}
                setsearchInTable={setsearchInTable}
                searchInTable={searchInTable}
            />


            {/* Fee right section  */}
            <FeeMasterRightContainer
                showFormContainer={showFormContainer}
                handleAddFormDisplay={handleAddFormDisplay}
                isChecked={isChecked}
                handleCheckboxStatus={handleCheckboxStatus}
                showAddForm={showAddForm}
                showDataForm={showDataForm}
                GetAllReligionForm={GetAllMasterFormData}
                isTableFetchLoader={isTableFetchLoader}
                isEditForm={isEditForm}
                handleSubmit={handleSubmit}
                editAttributesData={editAttributesData}
                isSubmit={isSubmit}
                toggleValues={toggleValues}
                setToggleValues={setToggleValues}
                responseErr={responseErr}
                setresponseErr={setresponseErr}
                selectedItemData={selectedItemData}
                setsortingData={setsortingData}
                sortingData={sortingData}
                setShowDataForm={setShowDataForm}
                isEditId={isEditId}
                DeleteMasterFormByID={DeleteMasterFormByID}
                EditAllMasterFormApi={EditAllMasterFormApi}
                selectPageCount={selectPageCount}
                perPageValue={perPageValue}
                setSelectPageCount={setSelectPageCount}
                setPerPageValue={setPerPageValue}
                showLoader={showLoader}
                setsearchInTable={setsearchInTable}
                searchInTable={searchInTable}
            />
        </Stack>
    )
}

export default MasterForm;

