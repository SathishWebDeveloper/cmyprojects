import { API_METHODS } from "@/types/common";

export const PLUGINS_API_END_POINTS = {
    // Get all in single
    getFeeMasterFormAllData:  { endPoint: 'api/admin/settings/fee', method: API_METHODS.GET },
    createFeeMasterFormAllData:{ endPoint: 'api/admin/settings/fee', method: API_METHODS.POST},
    feeMasterFormAllEditResponseById: { endPoint: 'api/admin/settings/fee', method: API_METHODS.GET},
    updateFeeAllMasterFormResponse: { endPoint: 'api/admin/settings/fee', method: API_METHODS.PUT},
    masterFeeFormDeleteResponseById: { endPoint: 'api/admin/settings/fee', method: API_METHODS.DELETE}
    
}

