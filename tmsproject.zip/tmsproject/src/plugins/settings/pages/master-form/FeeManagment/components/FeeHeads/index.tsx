import { ErrorStyled, FormContainer, InputError, } from "@/core/pages/Login/components/LoginStyled";
import SearchTextField from "@/plugins/settings/components/SearchTextField";
import { AddBox } from "@mui/icons-material";
import { Box, Stack, Switch, Typography } from "@mui/material";
import { ErrorMessage, Field, Form, Formik } from "formik";
import { useIntl } from "react-intl";
import * as Yup from "yup";
import Filter from "@/plugins/settings/pages/master-form/Filter/index";
import { LoadingButtonStyledMasterForm, OutlinedButtonStyledMasterForm, OutlinedInputStyledMasterForm, OutlinedSelectStyledMasterForm, RequiredFieldStyleMasterForm, StyledAddBtn, StyledContainer, StyledPrimaryButton, StyledSecondaryButton } from "@/plugins/settings/pages/master-form/MasterFormStyled";
import DragableTable from "@/plugins/settings/pages/master-form/components/DragableTable";
import CircularProgress from '@mui/material/CircularProgress';

interface IFeeHeadsInterface {
    handleAddFormDisplay: () => void;
    isChecked: boolean;
    handleCheckboxStatus: () => void;
    showAddForm: boolean;
    showDataForm: any;
    GetAllReligionForm: () => void;
    isTableFetchLoader: boolean;
    isEditForm: boolean;
    handleSubmit: (values: any, type: string) => void;
    editAttributesData: any;
    isSubmit: boolean;
    toggleValues: { status: boolean }; // need to be chaNAGE
    setToggleValues: (data: any) => void;
    responseErr: any;
    setresponseErr: any;
    selectedItemData: string;
    sortingData: Array<string>;
    setsortingData: (data?: any) => void
    setShowDataForm: any;
    isEditId: number | string | null;
    perPageValue: number;
    selectPageCount: number;
    setPerPageValue: (data?: any) => void;
    setSelectPageCount: (data?: any) => void;
    DeleteMasterFormByID: (data: any, id: number) => void;
    EditAllMasterFormApi: (data: string, index: number, selectedData: string, item: any) => void;
    showLoader: boolean;
    setsearchInTable: (data?: any) => void;
    searchInTable: string
}

interface ICreateAttrInitialValues {
    head_name: number | any;
    fee_module_id: number | any;
    status: boolean;
    receipt_head_id:number;
    academic_year_code:number;
    type:string;
    depend_on_join:boolean;
    // fee_module_id:number;

}

function FeeHeads({ handleAddFormDisplay, isChecked, handleCheckboxStatus,
    showAddForm, showDataForm, GetAllReligionForm, isTableFetchLoader, isEditForm, handleSubmit, editAttributesData, isSubmit, toggleValues, setToggleValues, responseErr,
    setresponseErr, selectedItemData, sortingData, setsortingData, setShowDataForm, isEditId, DeleteMasterFormByID, EditAllMasterFormApi, perPageValue, selectPageCount, setPerPageValue, setSelectPageCount, showLoader,
    setsearchInTable, searchInTable
}: IFeeHeadsInterface) {

    const { formatMessage } = useIntl();

    const MySpecialField = (setFieldValue: any) => {
        return <Switch {...setFieldValue} color="warning" />;
    };

    const initialValues: ICreateAttrInitialValues = {
        fee_module_id: editAttributesData?.fee_module_id ?? "",
        head_name: editAttributesData?.head_name ?? "",
        status: editAttributesData?.status === "active" ? true : false ?? false,
        receipt_head_id: editAttributesData?.receipt_head_id ?? "",
        academic_year_code: editAttributesData?.academic_year_code ?? "",
        type: editAttributesData?.type ?? "",
        depend_on_join: editAttributesData?.depend_on_join === "yes" ? true : false ?? false,
    };
    //validation need to be change 
    // const validationSchema = Yup.object().shape({
    //     head_name: Yup.string()
    //         .required(
    //             formatMessage({
    //                 id: "settings.masterform.Field.required",
    //             })
    //         ).matches!(/^[a-zA-Z0-9_]*$/, formatMessage({ id: "settings.masterform.specialcharaceterandspace" })),
    // });

    const handleInputChange = (e: any, setFieldValue: any, textValue: string) => {
        const inputValue = e.target.value.toLowerCase();

        if (textValue === "head_name") {
            setresponseErr(null);
            setFieldValue("head_name", inputValue);
        }
        else if (textValue === "fee_module_id") {
            setresponseErr(null);
            setFieldValue("fee_module_id", inputValue);
        }
        else if (textValue === "status") {
            setresponseErr(null);
            setFieldValue("status", e.target.checked ? true : false);
            setToggleValues(({ status: e.target.checked ? true : false }))
        }
        else if (textValue === "depend_on_join") {
            setresponseErr(null);
            setFieldValue("depend_on_join", e.target.checked ? true : false);
            // setToggleValues(({ depend_on_join: e.target.checked ? true : false }))
        }
        else if (textValue === "receipt_head_id") {
            setresponseErr(null);
            setFieldValue("receipt_head_id", inputValue);
        }
        else if (textValue === "academic_year_code") {
            setresponseErr(null);
            setFieldValue("academic_year_code", inputValue);
        }
        else if (textValue === "type") {
            setresponseErr(null);
            setFieldValue("type", inputValue);
        }
    };

    const searchFilteredData: object[] = showDataForm.data.filter((item: any) => {
        if (searchInTable === "") {
            return item
        } else {
            return item[selectedItemData]?.toLowerCase().includes(searchInTable)
          }
    })




return (
    <Box width='60%'>
        <StyledContainer>
            {/* form details  */}
            {!showAddForm ? (
                <Box>
                    {!isChecked ? (
                        <Stack
                            direction='row' p='15px' justifyContent='space-between' alignItems='center' flexWrap='wrap' rowGap='5px'
                            sx={{ minHeight: '73px', boxSizing: 'border-box' }}
                        >
                            <Stack direction='row' width={{ xs: '180px', sm: '50%', md: '40%' }} alignItems='center' gap='8px'>
                                <Box width={{ xs: '180px', sm: '50%', md: '40%' }} onChange={(event: React.ChangeEvent<HTMLInputElement>) => setsearchInTable(event.target.value)}>
                                    <SearchTextField placeholder={formatMessage({ id: "settings.masterform.searchfield" })} />
                                </Box>
                                <Filter />
                            </Stack>
                            <StyledAddBtn
                                onClick={() => handleAddFormDisplay()}
                            >
                                <AddBox />
                                <Typography>{formatMessage({
                                    id: "settings.masterform.FeeHeads",
                                })}</Typography>
                            </StyledAddBtn>
                        </Stack>
                    ) : (
                        <Stack
                            direction='row' p='15px' justifyContent='end' alignItems='center' gap='15px' flexWrap='wrap' rowGap='5px'
                            sx={{ minHeight: '73px', boxSizing: 'border-box', }}
                        >
                            <StyledSecondaryButton>{formatMessage({
                                id: "settings.master.Changestatus",
                            })}</StyledSecondaryButton>
                            <StyledPrimaryButton>{formatMessage({
                                id: "settings.master.Deleteall",
                            })}</StyledPrimaryButton>
                        </Stack>
                    )}

                    <Box p={1}>
                        <DragableTable
                            checked={isChecked}
                            handleCheckbox={handleCheckboxStatus}
                            handleAddFormDisplay={handleAddFormDisplay}
                            showDataForm={showDataForm}
                            showDeleteForms={GetAllReligionForm}
                            isTableFetchLoader={isTableFetchLoader}
                            selectedItemData={selectedItemData}
                            setsortingData={setsortingData}
                            sortingData={sortingData}
                            setShowDataForm={setShowDataForm}
                            DeleteMasterFormByID={DeleteMasterFormByID}
                            EditAllMasterFormApi={EditAllMasterFormApi}
                            selectPageCount={selectPageCount}
                            perPageValue={perPageValue}
                            setSelectPageCount={setSelectPageCount}
                            setPerPageValue={setPerPageValue}
                            showLoader={showLoader}
                            searchFilteredData={searchFilteredData}
                            setsearchInTable={setsearchInTable}
                        />
                    </Box>
                </Box>
            ) : (
                <>
                    {isEditId !== "" && initialValues.fee_module_id === "" && isEditForm ?
                        (
                            <Box sx={{ width: "100%", height: 150, display: "flex", alignItems: "center", justifyContent: "center" }}>
                                <CircularProgress />
                            </Box>
                        )
                        :
                        (
                            <Stack p={'15px'} gap='20px'>
                                <Stack direction='row' justifyContent='space-between' alignItems='center'>
                                    <Typography sx={{ fontSize: 17, fontWeight: 700, color: '#252525' }}>
                                        {isEditForm ? "Edit Details" : "Add Details"}
                                    </Typography>
                                </Stack>
                                <Stack p={"15px"} gap="20px">
                                    <Box>
                                        <Formik initialValues={initialValues}
                                            // validationSchema={validationSchema}
                                            onSubmit={(values) => handleSubmit(values, "fee-head")}
                                            enableReinitialize>
                                            {({ setFieldValue }) => (
                                                <Form>
                                                    <FormContainer
                                                        sx={{
                                                            display: "flex",
                                                            justifyContent: "center",
                                                            flexDirection: "column",
                                                        }}
                                                    >
                                                        <Box
                                                            sx={{
                                                                display: "flex",
                                                                justifyContent: "space-evenly",
                                                            }}
                                                        >
                                                            <Box component="div" sx={{ width: "340px" }}>
                                                                <OutlinedSelectStyledMasterForm>
                                                                    <label>
                                                                        {formatMessage({
                                                                            id: "settings.masterform.HeadName",
                                                                        })}
                                                                        <RequiredFieldStyleMasterForm>
                                                                            <span>*</span>
                                                                        </RequiredFieldStyleMasterForm>
                                                                    </label>
                                                                    
                                                                    <Field
                                                                        type="text"
                                                                        as={OutlinedInputStyledMasterForm}
                                                                        placeholder="Enter Head Name"
                                                                        name="head_name"
                                                                        id="head_name"
                                                                        onChange={(event: string) =>
                                                                            handleInputChange(
                                                                                event,
                                                                                setFieldValue,
                                                                                "head_name"
                                                                            )
                                                                        }
                                                                    />
                                                                </OutlinedSelectStyledMasterForm>
                                                                <ErrorMessage name="head_name">
                                                                    {(msg) => <ErrorStyled>{msg}</ErrorStyled>}
                                                                </ErrorMessage>
                                                                <InputError>{responseErr?.head_name ?? ""}</InputError>



                                                                        {/*ReceiptHeadId  */}
                                                                        <OutlinedSelectStyledMasterForm>
                                                                    <label>
                                                                        {formatMessage({
                                                                            id: "settings.masterform.ReceiptHeadId",
                                                                        })}
                                                                        <RequiredFieldStyleMasterForm>
                                                                            <span>*</span>
                                                                        </RequiredFieldStyleMasterForm>
                                                                    </label>
                                                                    
                                                                    <Field
                                                                        type="number"
                                                                        as={OutlinedInputStyledMasterForm}
                                                                        placeholder="Enter Receipt Head Id"
                                                                        name="receipt_head_id"
                                                                        id="receipt_head_id"
                                                                        onChange={(event: string) =>
                                                                            handleInputChange(
                                                                                event,
                                                                                setFieldValue,
                                                                                "receipt_head_id"
                                                                            )
                                                                        }
                                                                    />
                                                                </OutlinedSelectStyledMasterForm>
                                                                <ErrorMessage name="receipt_head_id">
                                                                    {(msg) => <ErrorStyled>{msg}</ErrorStyled>}
                                                                </ErrorMessage>
                                                                <InputError>{responseErr?.receipt_head_id ?? ""}</InputError>


                                                                         {/* AcademicYearCode  */}
                                                                         <OutlinedSelectStyledMasterForm>
                                                                    <label>
                                                                        {formatMessage({
                                                                            id: "settings.masterform.AcademicYearCode",
                                                                        })}
                                                                        <RequiredFieldStyleMasterForm>
                                                                            <span>*</span>
                                                                        </RequiredFieldStyleMasterForm>
                                                                    </label>
                                                                    
                                                                    <Field
                                                                        type="number"
                                                                        as={OutlinedInputStyledMasterForm}
                                                                        placeholder="Enter Academic Year Code"
                                                                        name="academic_year_code"
                                                                        id="academic_year_code"
                                                                        onChange={(event: string) =>
                                                                            handleInputChange(
                                                                                event,
                                                                                setFieldValue,
                                                                                "academic_year_code"
                                                                            )
                                                                        }
                                                                    />
                                                                </OutlinedSelectStyledMasterForm>
                                                                <ErrorMessage name="academic_year_code">
                                                                    {(msg) => <ErrorStyled>{msg}</ErrorStyled>}
                                                                </ErrorMessage>
                                                                <InputError>{responseErr?.academic_year_code ?? ""}</InputError>

                                                                

                                                                {/* status */}
                                                                <OutlinedSelectStyledMasterForm>
                                                                    <label htmlFor="status">
                                                                        {formatMessage({
                                                                            id: "settings.masterform.status",
                                                                        })}
                                                                        <RequiredFieldStyleMasterForm>
                                                                            <span>*</span>
                                                                        </RequiredFieldStyleMasterForm>
                                                                    </label>
                                                                    <Field
                                                                        type="Checkbox"
                                                                        name="status"
                                                                        value="false"

                                                                        checked={toggleValues.status}
                                                                        onChange={(event: any) => handleInputChange(event, setFieldValue, "status")}
                                                                        component={MySpecialField}
                                                                    />
                                                                </OutlinedSelectStyledMasterForm>
                                                                <ErrorMessage name="status">
                                                                    {(msg) => <ErrorStyled>{msg}</ErrorStyled>}
                                                                </ErrorMessage>
                                                                <InputError>{responseErr?.status ?? ""}</InputError>
                                                            </Box>


                                                            <Box component="div" sx={{ width: "340px" }}>
                                                                 {/* //FeeModuleId */}
                                                                <OutlinedSelectStyledMasterForm>
                                                                    <label>
                                                                        {formatMessage({
                                                                            id: "settings.masterform.FeeModuleId",
                                                                        })}
                                                                        <RequiredFieldStyleMasterForm>
                                                                            <span>*</span>
                                                                        </RequiredFieldStyleMasterForm>
                                                                    </label>
                                                                    <Field
                                                                        type="number"
                                                                        as={OutlinedInputStyledMasterForm}
                                                                        placeholder="Enter Fee Module Id"
                                                                        name="fee_module_id"
                                                                        onChange={(event: string) =>
                                                                            handleInputChange(
                                                                                event,
                                                                                setFieldValue,
                                                                                "fee_module_id"
                                                                            )
                                                                        }
                                                                    />
                                                                </OutlinedSelectStyledMasterForm>
                                                                <ErrorMessage name="fee_module_id">
                                                                    {(msg) => <ErrorStyled>{msg}</ErrorStyled>}
                                                                </ErrorMessage>
                                                                <InputError>{responseErr?.fee_module_id ?? ""}</InputError>
                                                                {/* //type number */}
                                                                <OutlinedSelectStyledMasterForm>
                                                                    <label>
                                                                        {formatMessage({
                                                                            id: "settings.masterform.Type",
                                                                        })}
                                                                        <RequiredFieldStyleMasterForm>
                                                                            <span>*</span>
                                                                        </RequiredFieldStyleMasterForm>
                                                                    </label>
                                                                    <Field
                                                                        type="text"
                                                                        as={OutlinedInputStyledMasterForm}
                                                                        placeholder="Enter Type"
                                                                        name="type"
                                                                        onChange={(event: string) =>
                                                                            handleInputChange(
                                                                                event,
                                                                                setFieldValue,
                                                                                "type"
                                                                            )
                                                                        }
                                                                    />
                                                                </OutlinedSelectStyledMasterForm>
                                                                <ErrorMessage name="type">
                                                                    {(msg) => <ErrorStyled>{msg}</ErrorStyled>}
                                                                </ErrorMessage>
                                                                <InputError>{responseErr?.type ?? ""}</InputError>

                                                                {/* {depend on join} */}

                                                                <OutlinedSelectStyledMasterForm>
                                                                    <label htmlFor="depend_on_join">
                                                                        {formatMessage({
                                                                            id: "settings.masterform.DependOnJoin",
                                                                        })}
                                                                        <RequiredFieldStyleMasterForm>
                                                                            <span>*</span>
                                                                        </RequiredFieldStyleMasterForm>
                                                                    </label>
                                                                    <Field
                                                                        type="Checkbox"
                                                                        name="depend_on_join"
                                                                        value="false"

                                                                        checked={toggleValues.depend_on_join}
                                                                        onChange={(event: any) => handleInputChange(event, setFieldValue, "depend_on_join")}
                                                                        component={MySpecialField}
                                                                    />
                                                                </OutlinedSelectStyledMasterForm>
                                                                <ErrorMessage name="depend_on_join">
                                                                    {(msg) => <ErrorStyled>{msg}</ErrorStyled>}
                                                                </ErrorMessage>
                                                                <InputError>{responseErr?.depend_on_join ?? ""}</InputError>



                                                                <Box
                                                                    sx={{
                                                                        display: "flex",
                                                                        position: "reltaive",
                                                                        justifyContent: "end",
                                                                        width: "95%",
                                                                        height: "70%",
                                                                        alignItems: "center",
                                                                        right: "2%",
                                                                    }}
                                                                >
                                                                    <OutlinedButtonStyledMasterForm
                                                                        onClick={handleAddFormDisplay}
                                                                    >
                                                                        {formatMessage({
                                                                            id: "settings.masterform.Cancel",
                                                                        })}
                                                                    </OutlinedButtonStyledMasterForm>
                                                                    <Box component="div">
                                                                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                                                    </Box>
                                                                    <LoadingButtonStyledMasterForm
                                                                        type="submit"
                                                                        variant="contained"
                                                                        loading={isSubmit}
                                                                    >
                                                                        {isEditForm ? "Update " : "Save "}
                                                                    </LoadingButtonStyledMasterForm>
                                                                </Box>
                                                            </Box>
                                                        </Box>
                                                    </FormContainer>
                                                </Form>
                                            )}
                                        </Formik>
                                    </Box>
                                </Stack>
                            </Stack>
                        )
                    }
                </>
            )}
            {/* and edit form  */}
        </StyledContainer>
    </Box>
)
}



export default FeeHeads;