import { apiBaseUrl, request } from "@/core/utils";
import { PLUGINS_API_END_POINTS } from "@/plugins/settings/pages/master-form/FeeManagment/api/api-constants";


// get fee master form
export const getFeeMasterFormAllItems = async (item: string,sorting:{ orderBy: string, sortedBy: string, limit: number, page: number }) => {
    console.log(`${apiBaseUrl + PLUGINS_API_END_POINTS.getFeeMasterFormAllData.endPoint}/${item}`);
    
    const getAllClassMasterFormResponse = await request({
        url: `${apiBaseUrl + PLUGINS_API_END_POINTS.getFeeMasterFormAllData.endPoint}/${item}`,
        method: PLUGINS_API_END_POINTS.getFeeMasterFormAllData.method,
        params:sorting
    })
     return getAllClassMasterFormResponse;
     
}

// create
export const createFeeMasterFormAllItems = async (item: string,data: any) => {
    const createAllClassMasterFormResponse = await request({
        url: `${apiBaseUrl + PLUGINS_API_END_POINTS.createFeeMasterFormAllData.endPoint}/${item}`,
        method: PLUGINS_API_END_POINTS.createFeeMasterFormAllData.method,
        body: { ...data },
    })
     return createAllClassMasterFormResponse;
}

//get for edit
export const getFeeMasterFormEditAllResponse = async (item: string,data: any) => {
    const AllMasterFormEditResponse = await request({
        url: `${apiBaseUrl + PLUGINS_API_END_POINTS.feeMasterFormAllEditResponseById.endPoint}/${item}/${data}`,
        method: PLUGINS_API_END_POINTS.feeMasterFormAllEditResponseById.method,
    })
    return AllMasterFormEditResponse;
}

//update
export const updateAllFeeMasterFormResponseById = async (item: string|undefined,data: any, id: number | string) => {
    const updateMasterFormResponse = await request({
        url: `${apiBaseUrl + PLUGINS_API_END_POINTS.updateFeeAllMasterFormResponse.endPoint}/${item}/${id}`,
        method: PLUGINS_API_END_POINTS.updateFeeAllMasterFormResponse.method,
        body: { ...data },
    });
    return updateMasterFormResponse;
}

//delete
//delete  in master form
export const deleteAllFeeMasterFormById = async (item: string,data: any) => {
    console.log('item are 123', item,data);
    
    const deleteMasterForm = await request({
        url: `${apiBaseUrl + PLUGINS_API_END_POINTS.masterFeeFormDeleteResponseById.endPoint}/${item}/${data}`,
        method: PLUGINS_API_END_POINTS.masterFeeFormDeleteResponseById.method,
    })
    return deleteMasterForm;
}





