// import welcomeFormImage from "@/assets/images/welcome-image.svg";
// import { Box, Stack, Typography } from "@mui/material";

import FeeHeads from "../FeeHeads";
import FeePrintRollMaster from "../FeePrintRollMaster";
import FeeReceiptHead from "../FeeReceiptHead";


interface IRightContainerInterface {
    showFormContainer: string[];
    handleAddFormDisplay: () => void;
    isChecked: boolean;
    handleCheckboxStatus: () => void;
    showAddForm: boolean;
    showDataForm: any;
    GetAllReligionForm: (data?:string|undefined) => void;
    isTableFetchLoader: boolean;
    isEditForm: boolean;
    handleSubmit: () => void;
    editAttributesData: any;
    isSubmit: boolean;
    toggleValues: { status: boolean };
    setToggleValues: (data: any) => void;
    responseErr: any;
    setresponseErr: any;
    selectedItemData: string;
    sortingData: Array<string>;
    setsortingData: (data?: any) => void;
    setShowDataForm: any;
    isEditId: number | string | null;
    perPageValue: number;
    selectPageCount: number;
    DeleteMasterFormByID: (data: any, id: number) => void;
    setPerPageValue: (data?: any) => void;
    setSelectPageCount: (data?: any) => void;
    EditAllMasterFormApi: (data: string, index: number, selectedData: string, item: any) => void;
    showLoader:boolean;
    setsearchInTable:(data?: any) => void;
    searchInTable:string
}


const FeeMasterRightContainer = ({ showFormContainer, handleAddFormDisplay, isChecked, handleCheckboxStatus,
    showAddForm, showDataForm, GetAllReligionForm, isTableFetchLoader, isEditForm, handleSubmit, editAttributesData,
    isSubmit, toggleValues, setToggleValues, responseErr, setresponseErr, selectedItemData, sortingData, setsortingData, setShowDataForm, isEditId, DeleteMasterFormByID, EditAllMasterFormApi, perPageValue, selectPageCount, setPerPageValue, setSelectPageCount , showLoader,
    setsearchInTable,searchInTable
}: IRightContainerInterface) => {




    return (
        <>
            {showFormContainer[0] === "fee-term" ?
                <FeeTermMaster
                    handleAddFormDisplay={handleAddFormDisplay}
                    isChecked={isChecked}
                    handleCheckboxStatus={handleCheckboxStatus}
                    showAddForm={showAddForm}
                    showDataForm={showDataForm}
                    GetAllReligionForm={GetAllReligionForm}
                    isTableFetchLoader={isTableFetchLoader}
                    isEditForm={isEditForm}
                    handleSubmit={handleSubmit}
                    editAttributesData={editAttributesData}
                    isSubmit={isSubmit}
                    toggleValues={toggleValues}
                    setToggleValues={setToggleValues}
                    responseErr={responseErr}
                    setresponseErr={setresponseErr}
                    selectedItemData={selectedItemData}
                    setsortingData={setsortingData}
                    sortingData={sortingData}
                    setShowDataForm={setShowDataForm}
                    isEditId={isEditId}
                    DeleteMasterFormByID={DeleteMasterFormByID}
                    EditAllMasterFormApi={EditAllMasterFormApi}
                    selectPageCount={selectPageCount}
                    perPageValue={perPageValue}
                    setSelectPageCount={setSelectPageCount}
                    setPerPageValue={setPerPageValue}
                    showLoader={showLoader}
                    setsearchInTable={setsearchInTable}
                     searchInTable={searchInTable}
                /> : showFormContainer[0] === "fee-head" ?
                    <FeeHeads
                        handleAddFormDisplay={handleAddFormDisplay}
                        isChecked={isChecked}
                        handleCheckboxStatus={handleCheckboxStatus}
                        showAddForm={showAddForm}
                        showDataForm={showDataForm}
                        GetAllReligionForm={GetAllReligionForm}
                        isTableFetchLoader={isTableFetchLoader}
                        isEditForm={isEditForm}
                        handleSubmit={handleSubmit}
                        editAttributesData={editAttributesData}
                        isSubmit={isSubmit}
                        toggleValues={toggleValues}
                        setToggleValues={setToggleValues}
                        responseErr={responseErr}
                        setresponseErr={setresponseErr}
                        selectedItemData={selectedItemData}
                        setsortingData={setsortingData}
                        sortingData={sortingData}
                        setShowDataForm={setShowDataForm}
                        isEditId={isEditId}
                        DeleteMasterFormByID={DeleteMasterFormByID}
                        EditAllMasterFormApi={EditAllMasterFormApi}
                        selectPageCount={selectPageCount}
                        perPageValue={perPageValue}
                        setSelectPageCount={setSelectPageCount}
                        setPerPageValue={setPerPageValue}
                        showLoader={showLoader}
                        setsearchInTable={setsearchInTable}
                        searchInTable={searchInTable}
                    /> : showFormContainer[0] === "fee-group" ?
                        <FeeGroup
                            handleAddFormDisplay={handleAddFormDisplay}
                            isChecked={isChecked}
                            handleCheckboxStatus={handleCheckboxStatus}
                            showAddForm={showAddForm}
                            showDataForm={showDataForm}
                            GetAllReligionForm={GetAllReligionForm}
                            isTableFetchLoader={isTableFetchLoader}
                            isEditForm={isEditForm}
                            handleSubmit={handleSubmit}
                            editAttributesData={editAttributesData}
                            isSubmit={isSubmit}
                            toggleValues={toggleValues}
                            setToggleValues={setToggleValues}
                            responseErr={responseErr}
                            setresponseErr={setresponseErr}
                            selectedItemData={selectedItemData}
                            setsortingData={setsortingData}
                            sortingData={sortingData}
                            setShowDataForm={setShowDataForm}
                            isEditId={isEditId}
                            DeleteMasterFormByID={DeleteMasterFormByID}
                            EditAllMasterFormApi={EditAllMasterFormApi}
                            selectPageCount={selectPageCount}
                            perPageValue={perPageValue}
                            setSelectPageCount={setSelectPageCount}
                            setPerPageValue={setPerPageValue}
                            showLoader={showLoader}
                            setsearchInTable={setsearchInTable}
                            searchInTable={searchInTable}
                        /> : showFormContainer[0] === "fee-module" ?
                            <Modules
                                handleAddFormDisplay={handleAddFormDisplay}
                                isChecked={isChecked}
                                handleCheckboxStatus={handleCheckboxStatus}
                                showAddForm={showAddForm}
                                showDataForm={showDataForm}
                                GetAllReligionForm={GetAllReligionForm}
                                isTableFetchLoader={isTableFetchLoader}
                                isEditForm={isEditForm}
                                handleSubmit={handleSubmit}
                                editAttributesData={editAttributesData}
                                isSubmit={isSubmit}
                                toggleValues={toggleValues}
                                setToggleValues={setToggleValues}
                                responseErr={responseErr}
                                setresponseErr={setresponseErr}
                                selectedItemData={selectedItemData}
                                setsortingData={setsortingData}
                                sortingData={sortingData}
                                setShowDataForm={setShowDataForm}
                                isEditId={isEditId}
                                DeleteMasterFormByID={DeleteMasterFormByID}
                                EditAllMasterFormApi={EditAllMasterFormApi}
                                selectPageCount={selectPageCount}
                                perPageValue={perPageValue}
                                setSelectPageCount={setSelectPageCount}
                                setPerPageValue={setPerPageValue}
                                showLoader={showLoader}
                                setsearchInTable={setsearchInTable}
                                searchInTable={searchInTable}
                            /> : showFormContainer[0] === "fee-receipt" ?
                                <FeeReceiptHead
                                    handleAddFormDisplay={handleAddFormDisplay}
                                    isChecked={isChecked}
                                    handleCheckboxStatus={handleCheckboxStatus}
                                    showAddForm={showAddForm}
                                    showDataForm={showDataForm}
                                    GetAllReligionForm={GetAllReligionForm}
                                    isTableFetchLoader={isTableFetchLoader}
                                    isEditForm={isEditForm}
                                    handleSubmit={handleSubmit}
                                    editAttributesData={editAttributesData}
                                    isSubmit={isSubmit}
                                    toggleValues={toggleValues}
                                    setToggleValues={setToggleValues}
                                    responseErr={responseErr}
                                    setresponseErr={setresponseErr}
                                    selectedItemData={selectedItemData}
                                    setsortingData={setsortingData}
                                    sortingData={sortingData}
                                    setShowDataForm={setShowDataForm}
                                    isEditId={isEditId}
                                    DeleteMasterFormByID={DeleteMasterFormByID}
                                    EditAllMasterFormApi={EditAllMasterFormApi}
                                    selectPageCount={selectPageCount}
                                    perPageValue={perPageValue}
                                    setSelectPageCount={setSelectPageCount}
                                    setPerPageValue={setPerPageValue}
                                    showLoader={showLoader}
                                    setsearchInTable={setsearchInTable}
                                    searchInTable={searchInTable}
                                /> : showFormContainer[0] === "fee-payment-type" ?
                                    <FeePaymentType
                                        handleAddFormDisplay={handleAddFormDisplay}
                                        isChecked={isChecked}
                                        handleCheckboxStatus={handleCheckboxStatus}
                                        showAddForm={showAddForm}
                                        showDataForm={showDataForm}
                                        GetAllReligionForm={GetAllReligionForm}
                                        isTableFetchLoader={isTableFetchLoader}
                                        isEditForm={isEditForm}
                                        handleSubmit={handleSubmit}
                                        editAttributesData={editAttributesData}
                                        isSubmit={isSubmit}
                                        toggleValues={toggleValues}
                                        setToggleValues={setToggleValues}
                                        responseErr={responseErr}
                                        setresponseErr={setresponseErr}
                                        selectedItemData={selectedItemData}
                                        setsortingData={setsortingData}
                                        sortingData={sortingData}
                                        setShowDataForm={setShowDataForm}
                                        isEditId={isEditId}
                                        DeleteMasterFormByID={DeleteMasterFormByID}
                                        EditAllMasterFormApi={EditAllMasterFormApi}
                                        selectPageCount={selectPageCount}
                                        perPageValue={perPageValue}
                                        setSelectPageCount={setSelectPageCount}
                                        setPerPageValue={setPerPageValue}
                                        showLoader={showLoader}
                                        setsearchInTable={setsearchInTable}
                                        searchInTable={searchInTable}
                                    /> : showFormContainer[0] === "fee-counter" ?
                                        <FeeCounter
                                            handleAddFormDisplay={handleAddFormDisplay}
                                            isChecked={isChecked}
                                            handleCheckboxStatus={handleCheckboxStatus}
                                            showAddForm={showAddForm}
                                            showDataForm={showDataForm}
                                            GetAllReligionForm={GetAllReligionForm}
                                            isTableFetchLoader={isTableFetchLoader}
                                            isEditForm={isEditForm}
                                            handleSubmit={handleSubmit}
                                            editAttributesData={editAttributesData}
                                            isSubmit={isSubmit}
                                            toggleValues={toggleValues}
                                            setToggleValues={setToggleValues}
                                            responseErr={responseErr}
                                            setresponseErr={setresponseErr}
                                            selectedItemData={selectedItemData}
                                            setsortingData={setsortingData}
                                            sortingData={sortingData}
                                            setShowDataForm={setShowDataForm}
                                            isEditId={isEditId}
                                            DeleteMasterFormByID={DeleteMasterFormByID}
                                            EditAllMasterFormApi={EditAllMasterFormApi}
                                            selectPageCount={selectPageCount}
                                            perPageValue={perPageValue}
                                            setSelectPageCount={setSelectPageCount}
                                            setPerPageValue={setPerPageValue}
                                            showLoader={showLoader}
                                            setsearchInTable={setsearchInTable}
                                            searchInTable={searchInTable}
                                        />: showFormContainer[0] === "print-roll" ?
                                        <FeePrintRollMaster
                                            handleAddFormDisplay={handleAddFormDisplay}
                                            isChecked={isChecked}
                                            handleCheckboxStatus={handleCheckboxStatus}
                                            showAddForm={showAddForm}
                                            showDataForm={showDataForm}
                                            GetAllReligionForm={GetAllReligionForm}
                                            isTableFetchLoader={isTableFetchLoader}
                                            isEditForm={isEditForm}
                                            handleSubmit={handleSubmit}
                                            editAttributesData={editAttributesData}
                                            isSubmit={isSubmit}
                                            toggleValues={toggleValues}
                                            setToggleValues={setToggleValues}
                                            responseErr={responseErr}
                                            setresponseErr={setresponseErr}
                                            selectedItemData={selectedItemData}
                                            setsortingData={setsortingData}
                                            sortingData={sortingData}
                                            setShowDataForm={setShowDataForm}
                                            isEditId={isEditId}
                                            DeleteMasterFormByID={DeleteMasterFormByID}
                                            EditAllMasterFormApi={EditAllMasterFormApi}
                                            selectPageCount={selectPageCount}
                                            perPageValue={perPageValue}
                                            setSelectPageCount={setSelectPageCount}
                                            setPerPageValue={setPerPageValue}
                                            showLoader={showLoader}
                                            setsearchInTable={setsearchInTable}
                                            searchInTable={searchInTable}
                                        />: showFormContainer[0] === "bank" ?
                                        <Bank
                                            handleAddFormDisplay={handleAddFormDisplay}
                                            isChecked={isChecked}
                                            handleCheckboxStatus={handleCheckboxStatus}
                                            showAddForm={showAddForm}
                                            showDataForm={showDataForm}
                                            GetAllReligionForm={GetAllReligionForm}
                                            isTableFetchLoader={isTableFetchLoader}
                                            isEditForm={isEditForm}
                                            handleSubmit={handleSubmit}
                                            editAttributesData={editAttributesData}
                                            isSubmit={isSubmit}
                                            toggleValues={toggleValues}
                                            setToggleValues={setToggleValues}
                                            responseErr={responseErr}
                                            setresponseErr={setresponseErr}
                                            selectedItemData={selectedItemData}
                                            setsortingData={setsortingData}
                                            sortingData={sortingData}
                                            setShowDataForm={setShowDataForm}
                                            isEditId={isEditId}
                                            DeleteMasterFormByID={DeleteMasterFormByID}
                                            EditAllMasterFormApi={EditAllMasterFormApi}
                                            selectPageCount={selectPageCount}
                                            perPageValue={perPageValue}
                                            setSelectPageCount={setSelectPageCount}
                                            setPerPageValue={setPerPageValue}
                                            showLoader={showLoader}
                                            setsearchInTable={setsearchInTable}
                                            searchInTable={searchInTable}
                                        />
                                        : null}</>

    )
}



export default FeeMasterRightContainer;