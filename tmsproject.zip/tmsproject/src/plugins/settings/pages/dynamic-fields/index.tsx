import FormLogo from '@/assets/images/formIcon.svg';
import CreateAttribute from '@/plugins/settings/components/CreateAttribute/index';
import DynamicFieldTable from '@/plugins/settings/components/DynamicFieldTable/index';
import { OutlinedInputStyled } from "@/plugins/settings/pages/dynamic-fields/dynamic-fieldsStyled";
import AddIcon from '@mui/icons-material/Add';
import ArrowBackIosIcon from "@mui/icons-material/ArrowBackIos";
import ArrowForwardIosIcon from "@mui/icons-material/ArrowForwardIos";
import SearchIcon from '@mui/icons-material/Search';
import { Button, IconButton, InputAdornment, Typography } from "@mui/material";
import Box from '@mui/material/Box';
import CircularProgress from '@mui/material/CircularProgress';
import InputLabel from "@mui/material/InputLabel";
import MenuItem from "@mui/material/MenuItem";
import Paper from '@mui/material/Paper';
import Select from "@mui/material/Select";
import Table from '@mui/material/Table';
import TableContainer from '@mui/material/TableContainer';
import { enqueueSnackbar } from "notistack";
import React, { useState } from "react";
import { useIntl } from "react-intl";
import { deleteAttributeById, getAllAttributes, getAttributesForms } from "@/plugins/settings/api/api-handlers";
import "@/plugins/settings/pages/dynamic-fields/dynamic-fields.css";

const DynamicFields: React.FC = () => {
    const { formatMessage } = useIntl();
    const [isCreateAttr, setisCreateAttr] = useState(false);
    const [getAttrforms, setgetAttrforms] = useState([]);
    const [attributesData, setAttributesData] = useState({ data: [], pageCount: 0 });
    const [selectedData, setSelectedData] = useState<any>([]);
    const [editId, setEditId] = useState("");
    const [isLoading, setisLoading] = useState(false)
    const [searchData, setsearchData] = useState("");
    const [pageCount] = useState({
        page: 1,
        rowsPerPage: 10
    })
    const [values] = useState([10, 25, 50, 100]);
    const [sortingData, setsortingData] = useState([]);
    const [selectedPageNumber, setSelectedPageNumber] = useState(10);
    const [selectPageCount, setSelectPageCount] = useState(1);
    const userPerPage = selectedPageNumber;
    const pageCountValue = Math.ceil(attributesData.pageCount / userPerPage);
    const pagecount = Array.from(Array(pageCountValue).keys(), (x) => x + 1);

    const goToNextPage = () => {
        if (selectPageCount !== pageCountValue)
            setSelectPageCount(selectPageCount + 1);
    };
    const goToPrevPage = () => {
        if (selectPageCount !== 1) setSelectPageCount(selectPageCount - 1);
    };

    const handleChange = (event: any) => {
        setsearchData(event.target.value.toLowerCase());
    };

    const handleChangePageCount = (event: any) => {
        setSelectedPageNumber(event.target.value);
        setSelectPageCount(1);

    };
    const handleChangeSelectPage = (event: any) => {
        setSelectPageCount(event.target.value);
    };

    React.useEffect(() => {
        Getattributesform();
    }, []);

    React.useEffect(() => {
        handleChangePage();
    }, [sortingData, selectedPageNumber, selectPageCount, isCreateAttr])


    // fetch when pagination
    const handleChangePage = async () => {
        const response = await getAllAttributes({ orderBy: sortingData?.length === 0 ? `id` : `${sortingData[0]}`, sortedBy: sortingData?.length === 0 ? `desc` : `${sortingData[1]}`, limit: `${selectedPageNumber}`, page: `${selectPageCount}`, search: `entity_type:${selectedData?.value}` });
        setAttributesData({ ...attributesData, data: response.data, pageCount: response.total })
    }

    const Getattributesform = async () => {

        const result = await getAttributesForms();
        if (result?.code === 200) {
            setgetAttrforms(result.data);
            GetAllAttributes(result?.data[0])
        }
    }


    // Initial fetch
    const GetAllAttributes = async (entityType: any) => {
        setisLoading(true)
        setSelectedData(entityType);
        const response = await getAllAttributes({ orderBy: sortingData?.length === 0 ? `id` : `${sortingData[0]}`, sortedBy: sortingData?.length === 0 ? `desc` : `${sortingData[1]}`, limit: `${pageCount.rowsPerPage}`, page: `${pageCount.page}`, search: `entity_type:${entityType.value}` });
        if (response?.code === 200) {
            setAttributesData({ ...attributesData, data: response.data, pageCount: response.total })
            setisLoading(false)
        }
    }

    const GetattributeForm = async (entityType: any) => {
        setSelectPageCount(1)
        // Toggle when user click attribute form
        if (isCreateAttr) {
            ToggleCreateAttribute()
        }

        setisLoading(true)
        setSelectedData(entityType);
        const response = await getAllAttributes({ limit: `${pageCount.rowsPerPage}`, page: `${pageCount.page}`, search: `entity_type:${entityType.value}` });

        if (response?.code === 200) {
            setAttributesData({ data: response.data, pageCount: response.total })
            setisLoading(false)
            
        }

    }

    const ToggleCreateAttribute = async () => {
        setisCreateAttr(prev => !prev)
    };


    //delete attributes
    const DeleteAttributes = async (id: number | null | any = null) => {
        const response = await deleteAttributeById(id);
        if (response.code === 200) {
            enqueueSnackbar(response.message, { variant: "success" });
        }
        else if (response.code === 400) {
            enqueueSnackbar(response.message, { variant: "error", autoHideDuration: 4000 });
        }
    };

    // It returns filtered value as array
    const searchFilteredData: object[] = getAttrforms.filter((name: any) => name.label.toLowerCase().includes(searchData))

    return <>
        <Box sx={{ width: "100%", display: "flex", justifyContent: "center" }}>
            <Box component="div" sx={{ width: "30%", minHeight: "70vh", flexShrink: 0, borderRadius: 2, border: "1px solid #F2F4F7", background: "#FFF", boxShadow: "0px 4px 16px 0px rgba(65, 126, 227, 0.10)" }}>
                {/* Select Item -left container */}
                <Box component="div" sx={{ width: 397, height: 60, display: "flex", alignItems: "center" }}>
                    <span style={{ left: 10, position: "relative", color: "#344054", fontSize: "18px", fontWeight: 700, lineHeight: "28px" }}>
                        {formatMessage({ id: "settings.Select.Item" })}</span>
                </Box>
                {/* Search and filter */}
                <Box component="div" sx={{ width: "100%", height: 160, display: "flex", alignItems: "center", justifyContent: "center", borderBottom: "0.5px solid #DDE2E4", borderTop: "0.5px solid #DDE2E4" }}>
                    {/* Search */}
                    <Box component="div" sx={{ width: "95%", borderRadius: 1, height: 130, display: "flex", flexDirection: "column", alignItems: "center", border: "0.5px solid #DDE2E4", }}>
                        <Box component="div" sx={{ width: "100%", borderRadius: 1, height: 130, display: "flex", alignItems: "center", border: "0.5px solid transparent", justifyContent: "center" }} onChange={handleChange}>
                            <OutlinedInputStyled
                                startAdornment={
                                    <InputAdornment position="start" >
                                        <SearchIcon sx={{ color: "#B0BABF" }} />
                                    </InputAdornment>
                                }
                                placeholder={formatMessage({ id: "settings.Search.Placeholder" })}
                            />
                        </Box>
                    </Box>
                </Box>

                {/* select list */}
                {getAttrforms?.length === 0 ? <Box component="div" sx={{ display: "flex", justifyContent: "center" }}><CircularProgress /></Box> :
                    searchFilteredData?.length === 0 ? <Box sx={{ height: "10%", display: "flex", justifyContent: 'center', alignItems: "center", }}>
                        <Typography sx={{ fontSize: '18px', fontWeight: '700', cursor: "pointer", }}>
                            {formatMessage({ id: "settings.Nodata.Found" })}
                        </Typography> </Box> :
                        searchFilteredData.map((filteredName: any, index: number) => {
                            const First_Letter = filteredName.label.charAt(0);
                            // let random_no = Math.floor((Math.random() * 3) + 1);
                            return (
                                <Box key={index} component="div" sx={filteredName.value === selectedData.value ?
                                    { backgroundColor: '#E0E0E0' } : { border: '1px solid white' }
                                } style={{ height: "70px", display: "flex", alignItems: "center", paddingLeft: 30, cursor: "pointer" }} onClick={() => GetattributeForm(filteredName)} >
                                    <Box component="div" style={{ height: "41px", width: "41px", background: `#D17777`, borderRadius: "5px", display: "flex", justifyContent: "center", alignItems: "center", fontSize: 22, color: "#FFFFFF" }}
                                    >{First_Letter}</Box>
                                    <Box component="div" style={{ display: "flex", flexDirection: "column", position: "relative", left: 10, height: "41px", justifyContent: "space-between" }}>
                                        <b style={{ fontSize: "16PX", fontWeight: 700, lineHeight: "24px" }}>{filteredName.label}</b>
                                        <Box component="div" style={{ display: "flex" }}>
                                            <img src={FormLogo} style={{ width: "18", height: "15", fill: '#A2A2A2' }} alt='' />

                                            <span style={{ fontSize: "12PX", fontWeight: 200, color: "#A2A2A2", marginLeft: 5 }}>{filteredName.value}</span>
                                        </Box>
                                    </Box>
                                </Box>
                            )
                        })
                }
            </Box>

            {/* Right container */}
            <Box component="div" sx={{ width: "68%", flexShrink: 0, borderRadius: 2, display: "flex", alignItems: "end", flexDirection: "column" }}>
                {/* Online Register Form  */}
                <Box component="div" sx={{ width: "98%", height: 112, flexShrink: 0, borderRadius: 1, border: "0.5px solid #F2F4F7", background: "#FFF", boxShadow: "0px 4px 16px 0px rgba(65, 126, 227, 0.10)", position: "relative", display: "flex", flexDirection: "column", alignItems: 'center' }}>
                    <Box style={{ height: 51, width: "95%", display: "flex", alignItems: "end", color: "#0E0E0E", fontSize: "18px", fontWeight: 700 }}>{selectedData.label}</Box>
                    <Box style={{ height: 51, width: "95%", display: "flex", paddingTop: 15 }}>
                        <Box component="div" style={{ display: "flex", alignItems: 'center' }}>
                            <img src={FormLogo} style={{ width: "18", height: "15", fill: '#A2A2A2' }} alt='' />

                            <span style={{ fontSize: "12PX", fontWeight: 200, color: "#A2A2A2", marginLeft: 5 }}> {selectedData.value}</span>
                        </Box>

                        <Box component="div" style={{ display: "flex", marginLeft: 15, alignItems: 'center' }}>
                            <img src={FormLogo} style={{ width: "18", height: "15", fill: '#A2A2A2' }} alt='' />
                            <span style={{ fontSize: "12PX", fontWeight: 200, color: "#A2A2A2", marginLeft: 5 }}> {attributesData.pageCount} {formatMessage({ id: "settings.Table.Field" })}</span>
                        </Box>

                        <Box style={{ display: "flex", flex: 1 }}></Box>
                        {isCreateAttr ? null :
                            <Button onClick={ToggleCreateAttribute} variant="outlined" sx={{ textTransform: "capitalize" }} startIcon={<AddIcon sx={{ backgroundColor: '#ff800f', color: 'white' }} />} style={{ height: "35px", borderColor: '#DDE2E4', color: 'black' }} >
                                <p style={{ fontSize: "14px", fontWeight: 600 }}>
                                    {formatMessage({ id: "settings.Createattribute.Button" })}</p>
                            </Button>
                        }
                    </Box>
                </Box>

                {/* Table */}
                <Box component="div" sx={{ width: "98%", minHeight: "70vh", flexShrink: 0, borderRadius: 1, border: "0.5px solid #F2F4F7", background: "#FFF", boxShadow: "0px 4px 16px 0px rgba(65, 126, 227, 0.10)", marginTop: 1, display: "flex", flexDirection: "column", justifyContent: isLoading ? `center` : null, alignItems: isLoading ? `center` : null }}>
                    {isLoading ? <CircularProgress /> :
                        <Box>
                            <TableContainer component={Paper} style={{ height: "70vh" }}>
                                <Table sx={{ minWidth: 650 }} aria-label="simple table">
                                    {isCreateAttr ?
                                        <CreateAttribute ToggleCreateAttribute={ToggleCreateAttribute}
                                            editId={editId} setEditId={setEditId} selectedData={selectedData} setsortingData={setsortingData}
                                        /> :
                                        <DynamicFieldTable attributesData={attributesData} ToggleCreateAttribute={ToggleCreateAttribute} DeleteAttributes={DeleteAttributes} setEditId={setEditId} setAttributesData={setAttributesData} selectedData={selectedData} sortingData={sortingData} setsortingData={setsortingData} />
                                    }
                                </Table>
                            </TableContainer>

                            {isCreateAttr ? null : (
                                <Box
                                    component="div"
                                    sx={{
                                        width: "100%",
                                        height: "10%",
                                        display: "flex",
                                        justifyContent: "space-between",
                                        alignItem: "center",
                                        marginTop: '7px'
                                    }}
                                >
                                    <Box sx={{ display: "flex", marginTop: "1%" }}>
                                        <Select
                                            sx={{ m: 1, minWidth: 70, height: 30 }}
                                            value={selectedPageNumber}
                                            onChange={handleChangePageCount}
                                        >
                                            {values.map((value, index) => {
                                                return (
                                                    <MenuItem key={index} value={value}>
                                                        {value}
                                                    </MenuItem>
                                                );
                                            })}
                                        </Select>
                                        <InputLabel sx={{ marginTop: "15px" }}> {formatMessage({ id: "settings.Pages.Viewtype" })}</InputLabel>
                                    </Box>

                                    <Box sx={{ display: "flex", marginTop: "1%", alignItem: "center" }}>
                                        <IconButton
                                            onClick={() => {
                                                goToPrevPage();
                                            }}
                                            disabled={selectPageCount === 1}
                                        >
                                            <ArrowBackIosIcon />
                                        </IconButton>
                                        <Box sx={{ display: "flex", gap: "10px", alignItems: "center" }}>
                                            <Box >
                                                {formatMessage({ id: "settings.Current.Page" })} {selectPageCount} {formatMessage({ id: "settings.Page.of" })}  {pageCountValue}
                                            </Box>
                                            <Box sx={{ alignItem: "center" }}>
                                                {formatMessage({ id: "settings.Change.Page" })}
                                                <Select
                                                    sx={{
                                                        m: 1,
                                                        minWidth: 70,
                                                        height: 30,

                                                    }}
                                                    value={selectPageCount}
                                                    onChange={handleChangeSelectPage}
                                                >
                                                    {pagecount.map((value, index) => {
                                                        return (
                                                            <MenuItem key={index + 1} value={value}>
                                                                {value}
                                                            </MenuItem>
                                                        );
                                                    })}
                                                </Select>
                                            </Box>
                                        </Box>
                                        <IconButton
                                            onClick={() => {
                                                goToNextPage();
                                            }}
                                            disabled={selectPageCount === pageCountValue}
                                        >
                                            <ArrowForwardIosIcon />
                                        </IconButton>
                                    </Box>
                                </Box>
                            )}
                        </Box>
                    }
                </Box>
            </Box>
        </Box>
    </>;
};

export default DynamicFields;

