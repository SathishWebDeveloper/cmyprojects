/* eslint-disable @typescript-eslint/no-explicit-any */
import { Box, OutlinedInput } from "@mui/material";
import { styled } from "@mui/system";


export const OutlinedInputStyled = styled(OutlinedInput)(() => ({

    width: '80%',
    'fieldse': {
        borderColor: '#DDE2E4',
    },
    'input': {
        padding: '10px 1px',
    },
    'input::placeholder': {
        color: '#B0BABF',
        fontWeight: 100,
        fontSize: 15,
        opacity: 1,

    }
}))


export const OutlinedSelectStyled = styled(Box)(() => ({
width:"89%",
display:"flex",
justifyContent:"center",
position:"relative",
'svg':{
    position:"absolute",
    right:"15%",
    top:"40%"
},
'img':{
    position:"absolute",
    right:"15%",
    top:"40%"
}
}))


export const OutlinedSelectStyledOrange = styled(Box)(() => ({
width:"100%",
display:"flex",
justifyContent:"center",
position:"relative",
'svg':{
    position:"absolute",
    right:"8%",
    top:"11%"
},
'img':{
    position:"absolute",
    right:"8%",
    top:"11%"
},
}))

