import Initializer from "@/plugins/sample/components/Initializer/index";
import {BootstrappedPlugin,  PluginConfig, RegisterTypes} from "@/types/pluginsTypes";
import reducer from "@/plugins/sample/reducers/sample";
import {log} from "@/core/utils/log";

const name = "Sample plugin";
import pluginId from "@/plugins/sample/PluginId";
import {prefixPluginTranslations} from "@/core/utils";

const PluginIcon = () => {
};

const plugin: PluginConfig = {
    register(app: RegisterTypes) {
        app.addMenuLink({
            to: `/sample/${pluginId}`,
            icon: PluginIcon,
            intlLabel: {
                id: `${pluginId}.plugin.name`,
                defaultMessage: name,
            },
            Component: async () => {
                return await import("./pages/App");
            },
            permissions: [
                // Uncomment to set the permissions of the plugin here
                // {
                //   action: '', // the action name should be plugin::plugin-name.actionType
                //   subject: null,
                // },
            ],
        });
        app.registerPlugin({
            id: pluginId,
            pluginId,
            initializer: Initializer,
            isReady: false,
            name,
        });

        app.addReducers({sample: reducer});
    },

    bootstrap(app: BootstrappedPlugin) {
        log("bootstrapping plugin ", app.getPlugin(pluginId));
    },
    async registerLanguages(params:{ locales: string[] })  {

        const importedTrads = await Promise.all(
            params.locales.map((locale) => {
                return import(
                      `./translations/${locale}.json`
                    )
                    .then(({ default: data }) => {
                        return {
                            data: prefixPluginTranslations(data, pluginId),
                            locale,
                        };
                    })
                    .catch(() => {
                        return {
                            data: {},
                            locale,
                        };
                    });
            })
        );

        return Promise.resolve(importedTrads);
    },
};

export default plugin;
