/**
 *
 * This component is the skeleton around the actual pages, and should only
 * contain code that should be seen on all pages. (e.g. navigation bar)
 *
 */

import React from "react";

const App: React.FC = () => {
  return <div>Hello from sample plugin</div>;
};

export default App;
