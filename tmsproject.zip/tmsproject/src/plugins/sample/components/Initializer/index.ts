/**
 *
 * Initializer
 *
 */

import  { useEffect, useRef } from "react";
import PropTypes from "prop-types";
import pluginId from "@/plugins/sample/PluginId";
import {InitPluginProps} from "@/types/pluginsTypes";



const Initializer  = ({setPlugin}: InitPluginProps) => {
  const ref = useRef<(id: string) => void>();
  ref.current = setPlugin;
  useEffect(() => {
    if (ref.current) ref.current(pluginId);
  }, []);

  return null;
};

Initializer.propTypes = {
  setPlugin: PropTypes.func.isRequired,
};

export default Initializer;
