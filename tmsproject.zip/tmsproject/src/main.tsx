import ReactDOM from "react-dom/client";
import plugins from "./plugins";
import appReducers from "./reducers";
import { Middlewares, Reducers } from "@/core/apis";
import './index.css'

declare global {
  interface Window {
    tms: {
      backendURL: string;
      appVersion: string;
      appEnv: string;
      env: object;
      features: object;
      projectType: string;
      logLevel: string;
    };
  }
}

window.tms = {
  backendURL: import.meta.env.VITE_ADMIN_BACKEND_URL,
  env: import.meta.env,
  features: {},
  projectType: "Private",
  appEnv: import.meta.env.VITE_APP_ENV ?? "development",
  appVersion: import.meta.env.VITE_APP_VERSION ?? "1.0.0",
  logLevel: import.meta.env.VITE_LOG_LEVEL ?? "debug",
};

const middlewares = Middlewares();
 const reducers = new Reducers({ appReducers });

 const run = async () => {
  try {
    // load initial configs from server
  } catch (err) {
    console.error(err);
  }

  const TmsApp = await import("./TmsApp");

  const customConfig = {};
  const app = TmsApp.default({
    appPlugins: plugins,
    adminConfig: customConfig,
    middlewares,
    reducers,
  });

  await app.initialize();
  await app.bootstrap();
  await app.registerLanguages();

  ReactDOM.createRoot(document.getElementById("root")!).render(app.render());
};

run();
