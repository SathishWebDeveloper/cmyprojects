import { SnackbarProvider } from "notistack";

const Snackbarprovider: React.FC<{ children: React.ReactNode }> = ({
  children,
}) => {
  // React.FC<ILanguageProviderProps & { children: React.ReactNode }

  return (
    <SnackbarProvider
      autoHideDuration={3000}
      maxSnack={1}
      anchorOrigin={{ horizontal: "center", vertical: "top" }}

    >
      {children}
    </SnackbarProvider>
  );
};

export default Snackbarprovider;
