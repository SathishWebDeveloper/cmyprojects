import React, {createContext} from 'react';

interface ILocalesProviderContext {
    changeLocale: (locale: string) => void
    localeNames: string[]
    messages: object
}

export const LocalesProviderContext = createContext<ILocalesProviderContext | undefined>(undefined);

interface ILocaleProviderProps {
    changeLocale: (locale: string) => void
    localeNames: string[]
    messages: object
}

const LocalesProvider: React.FC<ILocaleProviderProps & { children: React.ReactNode }> = ({
                                                                                             changeLocale,
                                                                                             children,
                                                                                             localeNames,
                                                                                             messages
                                                                                         }): JSX.Element => {
    return (
        <LocalesProviderContext.Provider value={{changeLocale, localeNames, messages}}>
            {children}
        </LocalesProviderContext.Provider>
    );
};


export default LocalesProvider;

