import {createSlice, Draft} from '@reduxjs/toolkit'
import type {PayloadAction} from '@reduxjs/toolkit'
import {languageKey} from "@/core/utils";

export interface LanguageState {
    localeNames: { [key: string]: string },
    locale: string,
}

const languageFromLocaleStorage = window.localStorage.getItem(languageKey);

const initialState: LanguageState = {
    localeNames: {en: 'English'},
    locale: languageFromLocaleStorage ?? 'en',
};


export const languageProviderSlice = createSlice({
    name: 'language',
    initialState,
    reducers: {

        setLocale: (state: Draft<any>, action: PayloadAction<string>) => {
            if (state.localeNames[action.payload]) {
                state.locale = action.payload;
            }
        },
    },
})

// Action creators are generated for each case reducer function
export const {setLocale} = languageProviderSlice.actions

export default languageProviderSlice.reducer