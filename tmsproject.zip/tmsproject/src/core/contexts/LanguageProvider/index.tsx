/*
 *
 * LanguageProvider
 *
 * this component connects the redux state language locale to the
 * IntlProvider component and i18n messages (loaded from `app/translations`)
 */

import React, {useEffect} from 'react';
import {IntlProvider} from 'react-intl';
import defaultsDeep from 'lodash/defaultsDeep';
import {languageKey} from "@/core/utils";
import LocalesProvider from "@/core/contexts/LocaleProvider";
import {useDispatch, useSelector} from "react-redux";
import {RootState} from "@/core/store";
import {setLocale} from "@/core/contexts/LanguageProvider/reducer";
interface ILanguageProviderProps {

    localeNames: string[]
    messages: {
        [key: string]: {
            [key: string]: string
        }
    }

}

const LanguageProvider:React.FC<ILanguageProviderProps & { children: React.ReactNode }> = ({children, localeNames, messages}):JSX.Element => {

    const locale = useSelector((state: RootState) => state.language.locale )
    const dispatch = useDispatch()

    console.log("??locale??", locale)

    useEffect(() => {
        // Set user language in local storage.
        window.localStorage.setItem(languageKey, locale);
        document.documentElement.setAttribute('lang', locale);
    }, [locale]);

    const changeLocale = (locale: string) => {
        dispatch( setLocale(locale));
    };

    const appMessages = defaultsDeep(messages[locale], messages.en);

    return (
        <IntlProvider locale={locale} defaultLocale="en" messages={appMessages} textComponent="span">
            <LocalesProvider changeLocale={changeLocale} localeNames={localeNames} messages={appMessages}>
                {children}
            </LocalesProvider>
        </IntlProvider>
    );
};

export default LanguageProvider;
