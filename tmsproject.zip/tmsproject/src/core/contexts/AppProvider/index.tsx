import React, { createContext, useContext, useMemo } from "react";
import {Plugins} from "@/types/pluginsTypes";

interface AppProviderContextType {
  getPlugin: (pluginId: string) => any;
  menu: any[];
  plugins: Plugins;
  settings: object;
}

const AppProviderContext = createContext<AppProviderContextType | undefined>(
  undefined
);

export function useAppContext() {
  const context = useContext(AppProviderContext);
  if (!context) {
    throw new Error("useAppContext must be used within a AppProvider");
  }
  return context;
}

const AppProvider: React.FC<
  AppProviderContextType & { children: React.ReactNode }
> = ({ children, getPlugin, menu, plugins, settings }) => {
  const configurationValue = useMemo(
    () => ({
      getPlugin,
      menu,
      plugins,
      settings,
    }),
    [getPlugin, menu, plugins, settings]
  );

  return (
    <AppProviderContext.Provider value={configurationValue}>
      {children}
    </AppProviderContext.Provider>
  );
};



export default AppProvider;
