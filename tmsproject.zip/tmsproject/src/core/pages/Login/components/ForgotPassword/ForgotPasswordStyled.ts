import styled from "@emotion/styled";
import { LoadingButton } from "@mui/lab";
import { Typography } from "@mui/material";

export const SubTitleStyled = styled(Typography)(() => ({
    color: '#828282',
    fontWeight: 400,
    fontSize: 14,
    marginTop: 0,

    'b': {
        display: "flex",
        color: '#383838',

    },
    'b> #Email_Edit_Icon': {
        color: "#828282"
    }
}))

// Loading button
export const LoadingButtonStyled = styled(LoadingButton)(() => ({
    width: '100%',
    textTransform: 'none',
    backgroundColor: '#007AFF',
    fontSize: 14,
    '&:hover': {
        backgroundColor: '#007AFF',
    },
}))
