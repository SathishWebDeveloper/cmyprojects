import { ErrorMessage, Field, Form, Formik } from "formik";
import * as React from "react";
import * as Yup from "yup";
import { ArrowBack } from "@mui/icons-material";
import { forgotPasswordRequest } from "@/core/apis/api-handlers";
import { IForgotPasswordValues } from "@/types/login";
import { useSnackbar } from "notistack";
import { useIntl } from "react-intl";
import {
  ErrorStyled,
  FormContainer,
  InputError,
  OutlinedInputStyled,
  TitleStyled
} from "@/core/pages/Login/components/LoginStyled";
import VerificationComponent from "@/core/pages/Login/components/VerificationComponent";
import { LoadingButtonStyled, SubTitleStyled } from "@/core/pages/Login/components/ForgotPassword/ForgotPasswordStyled";

interface IForgotPassword {
  handleForgotPassword: () => void;
}

export default function ForgotPassword({
  handleForgotPassword,
}: IForgotPassword) {
  const [showVerification, setShowVerification] = React.useState(false);
  const [isFetching, setFetching] = React.useState(false);
  const [resendToken, setResendToken] = React.useState(null);
  const [ErrorMsg, setErrorMsg] = React.useState<any>(null);
  const [resendEmail, setResendmail] = React.useState("");
  const { enqueueSnackbar } = useSnackbar();
  const { formatMessage } = useIntl();

  const validationSchema = Yup.object().shape({
    email: Yup.string()
      .trim()
      .email(formatMessage({ id: "Auth.login.validation.email" }))
      .required(formatMessage({ id: "Auth.login.required.email" })),
  });
  console.log('unused validationschema', validationSchema);
  

  const handleSubmit = async (value: IForgotPasswordValues) => {
    setErrorMsg(null)
    setResendmail(value.email);
    setFetching(true);
    const response = await forgotPasswordRequest({
      ...value,
      reference_type: "tenant_user_registration",
      app_type: "saas-admin-web",
      otp_type: "email",
    });


    if (!response) {
      enqueueSnackbar("Something went wrone", { variant: "error" ,autoHideDuration: 4000});
    }
    if (response && response.code === 200) {
      enqueueSnackbar(response.message, { variant: "success" });
      setResendToken(response.data.token);
      setShowVerification(true);
      setFetching(false);
    } else if (response && (response.code === 400 || response.code === 500)) {
      enqueueSnackbar(response.message, { variant: "error",autoHideDuration: 4000 });
      setFetching(false);
    } else {
      // error 422
      if (response?.errors) {
        setErrorMsg({
          email: response.errors.email,
        })
        setFetching(false);
      }
      
    }
  };

  const editEmail = () => {
    setShowVerification((prev) => !prev);
  };

  return (
    <>
      {showVerification ? (
        <VerificationComponent
          resendEmail={resendEmail}
          handleForgotPassword={handleForgotPassword}
          resendToken={resendToken}
          editEmail={editEmail}
        />
      ) : (
        <>
          <ArrowBack sx={{ mb: "10px" }} onClick={handleForgotPassword} />
          <TitleStyled>Forgot Password</TitleStyled>
          <SubTitleStyled>
            Enter Your Email for the verification process,we will send 4 digits
            code to your email
          </SubTitleStyled>
          <Formik
            initialValues={{ email: "" }}
          //  validationSchema={validationSchema}
            onSubmit={handleSubmit}
          >
            <Form>
              <FormContainer>
                <label htmlFor="email">
                  {formatMessage({ id: "Auth.login.email" })}
                </label>
                <Field
                  type="email"
                  id="email"
                  name="email"
                  as={OutlinedInputStyled}
                  placeholder="Email Address"
                />
                <ErrorMessage name="email">
                  {(msg) => <ErrorStyled>{msg}</ErrorStyled>}
                </ErrorMessage>
                {/* Custom server error handled as client side */}
                <InputError>{ErrorMsg?.email}</InputError>
                {/* For loading button when submit */}
                <LoadingButtonStyled
                  loading={isFetching}
                  type="submit"
                  sx={{ mt: "15px" }}
                  variant="contained"
                >
                  Continue
                </LoadingButtonStyled>
              </FormContainer>
            </Form>
          </Formik>
        </>
      )}
    </>
  );
}
