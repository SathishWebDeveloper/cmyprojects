/* eslint-disable @typescript-eslint/no-explicit-any */
import { Box, Button, OutlinedInput, Typography, Switch } from "@mui/material"
import { styled } from "@mui/system"
import { LoadingButton } from "@mui/lab";

export const TmsLogoContainer = styled(Box)(() => ({
    marginTop: '50px',
    marginBottom: '30px',
    height: 'fit-content',
    paddigTop: '10px',
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'center',
    alignItems: 'center',
    '> img': {
        width: '77px',
    },
}))

export const TextContaier = styled(Box)(() => ({
    display: 'flex',
    gap: '5px',
    '> span': {
        fontSize: 22,
        fontWeight: 700,
    }
}))

export const FormContainer = styled('div')(() => ({
    'label, input': {
        display: 'block',
    },
    'label': {
        color: '#333333',
        fontWeight: 500,
        fontSize: 15,
        marginTop: '10px',
        marginBottom: '3px',
    }
}))



export const TitleStyled = styled('h4')(
    () => ({
        color: '#0E0E0E',
        fontWeight: 700,
        fontSize: 20,
        marginTop: 0,
        marginBottom: '15px',
    })
)

export const OutlinedInputStyled = styled(OutlinedInput)(() => ({


    width: '100%',
    'fieldset': {
        borderColor: '#D0D5DD',
    },
    'input': {
        padding: '10px 8px',
    },
    'input::placeholder': {
        color: '#808080',
        fontWeight: 400,
        fontSize: 12,
        opacity: 1,
    }
}))

export const ErrorStyled = styled(Box)(() => ({
    color: 'red',
    fontWeight: 600,
    fontSize: 13,
}))

export const IOSSwitch = styled(Switch)(({ theme }: any) => ({
    transform: 'scale(.8)',
    width: 42,
    height: 26,
    padding: 0,
    '& .MuiSwitch-switchBase': {
        padding: 0,
        margin: 2,
        transitionDuration: '300ms',
        '&.Mui-checked': {
            transform: 'translateX(16px)',
            color: '#fff',
            '& + .MuiSwitch-track': {
                backgroundColor: '#EF770B',
                opacity: 1,
                border: 0,
            },
            '&.Mui-disabled + .MuiSwitch-track': {
                opacity: 0.5,
            },
        },
        '&.Mui-focusVisible .MuiSwitch-thumb': {
            color: '#33cf4d',
            border: '6px solid #fff',
        },
        // '&.Mui-disabled .MuiSwitch-thumb': {
        //     color:
        //         theme.palette.mode === 'light'
        //             ? theme.palette.grey[300]
        //             : theme.palette.grey[600],
        // },
        '&.Mui-disabled + .MuiSwitch-track': {
            opacity: theme.palette.mode === 'light' ? 0.7 : 0.3,
        },
    },
    '& .MuiSwitch-thumb': {
        boxSizing: 'border-box',
        width: 22,
        height: 22,
    },
    '& .MuiSwitch-track': {
        borderRadius: 26 / 2,
        backgroundColor: '#F2F2F2',
        opacity: 1,
        // transition: theme.transitions.create(['background-color'], {
        //     duration: 500,
        // }),
    },
}));

export const LinkStyled = styled('p')(() => ({
    textDecoration: 'none',
    color: '#007AFF',
    fontSize: 12,
    ':hover': {
        textDecoration: 'underline'
    }
}))

export const ButtonStyled = styled(Button)(() => ({
    width: '100%',
    textTransform: 'none',
    backgroundColor: '#007AFF',
    fontSize: 14,
    '&:hover': {
        backgroundColor: '#007AFF',
    },
}))

// Loading button
export const LoadingButtonStyled = styled(LoadingButton)(() => ({
    width: '100%',
    textTransform: 'none',
    backgroundColor: '#007AFF',
    fontSize: 14,
    '&:hover': {
        backgroundColor: '#007AFF',
    },
}))

export const GoogleBtnStyled = styled(Button)(() => ({
    marginTop: '35px',
    minHeight: '36px',
    gap: '10px',
    width: '100%',
    backgroundColor: '#0E0E0E',
    '&:hover': {
        backgroundColor: '#0E0E0E',
    },
    'p': {
        fontSize: 12,
        color: '#FFFFFF',
        textTransform: 'none',
        fontWeight: 400,
    }
}))

export const RightBoxContainer = styled(Box)(() => ({
    boxSizing: 'border-box',
    margin: 'auto',
    backgroundColor: '#EF770B',
    borderRadius: '40px',
    paddingTop: '30px',
    '@media (max-width: 900px)': {
        display: 'none',
    }
    // padding: '30px 25px 10px 25px'
}))

export const DescriptionStyled = styled(Typography)(() => ({
    margin: '0px 25px',
    color: 'white',
    fontWeight: 500,
    fontSize: 22,
}))

// Error span custom styled
export const InputError = styled('span')(() => ({
    color: 'red',
    fontWeight: 600,
    fontSize: '13px'
}))