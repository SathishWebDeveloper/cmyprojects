import * as React from "react";
import styled from "@emotion/styled";
import { Typography, Stack, OutlinedInput } from "@mui/material";
import { ButtonStyled, TitleStyled } from "@/core/pages/Login/components/LoginStyled";
import { SubTitleStyled } from "@/core/pages/Login/components/ForgotPassword/ForgotPasswordStyled";
import { resendOtp, validateOtp } from "@/core/apis/api-handlers";
import { useSnackbar } from "notistack";
import NewPassword from "@/core/pages/Login/components/NewPassword";
import EditIcon from "@mui/icons-material/Edit";

const ResendTextBox = styled("div")(() => ({
  textAlign: "center",
  marginTop: "20px",
  "> span": {
    fontSize: "13px",
    fontWeight: 400,
    color: "#828282",
  },
  "> button": {
    fontSize: "13px",
    fontWeight: 500,
    border: "none",
    backgroundColor: "#ffffff",
  },
}));

const OtpInputStyle = styled(OutlinedInput)(() => ({
  width: "60px",
  height: "60px",
  input: {
    padding: 25,
  },
  fieldset: {
    borderColor: "#D0D5DD",
  },
}));

interface IForgotPassword {
  resendEmail: string;
  resendToken: string | null;
  handleForgotPassword: () => void;
  editEmail: () => void;
}

export default function VerificationComponent({
  resendEmail,
  resendToken,
  handleForgotPassword,
  editEmail,
}: IForgotPassword) {
  const [showNewPassword, setShowNewPassword] = React.useState(false);
  const [timer, setTimer] = React.useState(59);
  const [rememberToken, setRememberToken] = React.useState("");
  const [id, setId] = React.useState(0);
  const { enqueueSnackbar } = useSnackbar();
  const ref1 = React.useRef<any>();
  const ref2 = React.useRef<any>();
  const ref3 = React.useRef<any>();
  const ref4 = React.useRef<any>();

  React.useEffect(() => {
    const interval = setInterval(() => {
      if (timer === 0) {
        clearInterval(interval);
      } else {
        setTimer((timer) => {
          return timer - 1;
        });
      }
    }, 1000);

    return () => {
      clearInterval(interval);
    };
  }, [timer]);

  const handleResend = async () => {
    setTimer(30);
    const response = await resendOtp({
      otp_type: "email",
      token: resendToken,
      app_type: "saas-admin-web",
      reference_type: "tenant_user_registration",
      email: resendEmail,
    });
    
    
    if (response && response.code === 200) {
      enqueueSnackbar(response.message, { variant: "success" });
    } else {
      enqueueSnackbar(response.message, { variant: "success" });
    }
  };

  const handleSubmit = async () => {
    // setShowNewPassword(!showNewPassword);
    const OTP =
      ref1.current.value +
      ref2.current.value +
      ref3.current.value +
      ref4.current.value;
    const response = await validateOtp({
      otp_type: "email",
      otp: OTP,
      app_type: "saas-admin-web",
      reference_type: "tenant_user_registration",
      email: resendEmail,
    });
   
    
    if (response && response.code === 200) {
      enqueueSnackbar("OTP Verified", { variant: "success" });
      setRememberToken(response.data.remember_token);
      setId(response.data.id)
      setShowNewPassword(!showNewPassword);
    } else {
      enqueueSnackbar(response.message, { variant: "error",autoHideDuration: 4000 });
    }
  };

  const handleBoxes = (e: any) => {
    const regex: RegExp = /^[0-9\b]+$/;
    if (e.target.value.length === 4 && regex.test(e.target.value)) {
      const splitted = e.target.value.split("");
      ref1.current.value = splitted[0];
      ref2.current.value = splitted[1];
      ref3.current.value = splitted[2];
      ref4.current.value = splitted[3];
      ref4.current.focus();
      return;
    }
    // setOtp((prev) => ({ ...prev, [e.target.name]: e.target.value }));

    if (e.target.name === "boxOne") {
      if (e.target.value && regex.test(e.target.value)) {
        ref1.current.value = e.target.value;
        ref2.current.focus();
      } else {
        ref1.current.value = "";
      }
    } else if (e.target.name === "boxTwo") {
      if (e.target.value && regex.test(e.target.value)) {
        ref2.current.value = e.target.value;
        ref3.current.focus();
      } else {
        if (e.target.value === "") {
          ref1.current.focus();
        } else if (!regex.test(e.target.value)) {
          ref2.current.value = "";
        }
      }
    } else if (e.target.name === "boxThree") {
      if (e.target.value && regex.test(e.target.value)) {
        ref3.current.value = e.target.value;
        ref4.current.focus();
      } else {
        if (e.target.value === "") {
          ref2.current.focus();
        } else if (!regex.test(e.target.value)) {
          ref3.current.value = "";
        }
      }
    } else if (e.target.name === "boxFour") {
      if (e.target.value && regex.test(e.target.value)) {
        ref4.current.value = e.target.value;
        ref4.current.focus();
      } else {
        if (e.target.value === "") {
          ref3.current.focus();
        } else if (!regex.test(e.target.value)) {
          ref4.current.value = "";
        }
      }
    }
  };
  const inputs: { name: string; refs: any; onKeyDown: any }[] = [
    {
      name: "boxOne",
      refs: ref1,
      onKeyDown: (e: any) => {
        e.keyCode === 8 && !e.target.value && ref1.current.focus();
      },
    },
    {
      name: "boxTwo",
      refs: ref2,
      onKeyDown: (e: any) => {
        e.keyCode === 8 && !e.target.value && ref1.current.focus();
      },
    },
    {
      name: "boxThree",
      refs: ref3,
      onKeyDown: (e: any) => {
        e.keyCode === 8 && !e.target.value && ref2.current.focus();
      },
    },
    {
      name: "boxFour",
      refs: ref4,
      onKeyDown: (e: any) => {
        e.keyCode === 8 && !e.target.value && ref3.current.focus();
      },
    },
  ];

  return (
    <>
      {showNewPassword ? (
        <>
          <NewPassword
            handleForgotPassword={handleForgotPassword}
            rememberToken={rememberToken}
            id={id}
          />
        </>
      ) : (
        <>
          <TitleStyled>Verification</TitleStyled>
          <SubTitleStyled>
            The code has been emailed to{" "}
            <b>
              {resendEmail}
              <EditIcon
                onClick={() => {
                  editEmail();
                }}
                style={{ left: 2, position: "relative", cursor: "pointer" }}
                id="Email_Edit_Icon"
              />
            </b>
          </SubTitleStyled>
          <Stack
            direction="row"
            justifyContent="space-evenly"
            sx={{ mt: "20px" }}
          >
            {inputs.map((item, index) => {
              return (
                <OtpInputStyle
                  key={`OTP-inputbox_${index}`}
                  autoFocus={index === 0}
                  onChange={handleBoxes}
                  name={item.name}
                  inputRef={item.refs}
                  inputProps={{ maxLength: index === 0 ? 4 : 1 }}
                />
              );
            })}
          </Stack>
          <Typography
            sx={{ mt: "10px", color: "#F2451C", textAlign: "center" }}
          >
            {`00:${timer < 10 ? 0 : ""}${timer}`}
          </Typography>
          <ButtonStyled
            onClick={handleSubmit}
            type="submit"
            sx={{ mt: "15px" }}
            variant="contained"
          >
            Continue
          </ButtonStyled>
          <ResendTextBox>
            <Typography component="span">
              If you didn’t receive a code!
            </Typography>
            <button
              onClick={handleResend}
              disabled={timer !== 0}
              style={{
                color: timer === 0 ? "#F2451C" : "",
                cursor: timer === 0 ? "pointer" : "not-allowed",
              }}
            >
              Resend
            </button>
          </ResendTextBox>
        </>
      )}
    </>
  );
}
