
/* eslint-disable @typescript-eslint/no-explicit-any */
import LoadingButton from '@mui/lab/LoadingButton';
import { styled } from "@mui/system";

export const LoadingButtonStyled = styled(LoadingButton)(() => ({
    width: '100%',
    textTransform: 'none',
    backgroundColor: '#007AFF',
    fontSize: 14,
    '&:hover': {
        backgroundColor: '#007AFF',
    },
}))