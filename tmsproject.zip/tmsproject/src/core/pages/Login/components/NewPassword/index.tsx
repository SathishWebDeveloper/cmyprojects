import { newPassword } from "@/core/apis/api-handlers";
import {
  ErrorStyled,
  FormContainer,
  InputError,
  OutlinedInputStyled,
  TitleStyled,
} from "@/core/pages/Login/components/LoginStyled";
import { INewPasswordValues } from "@/types/login";
import { Visibility, VisibilityOff } from "@mui/icons-material";
import { IconButton, InputAdornment } from "@mui/material";
import { ErrorMessage, Field, Form, Formik } from "formik";
import { useSnackbar } from "notistack";
import * as React from "react";
import { useIntl } from "react-intl";
import { SubTitleStyled } from "@/core/pages/Login/components/ForgotPassword/ForgotPasswordStyled";
import { LoadingButtonStyled } from "@/core/pages/Login/components/NewPassword/NewPasswordStyled";

interface IForgotPassword {
  handleForgotPassword: () => void;
  rememberToken: string;
  id:any
}

export default function NewPassword({
  handleForgotPassword,
  rememberToken,
  id
}: IForgotPassword) {
  const { formatMessage } = useIntl();
  const [showPassword, setShowPassword] = React.useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = React.useState(false);
  const [ErrorMsg, setErrorMsg] = React.useState<any>(null);
  const [isFetching, setFetching] = React.useState(false);

  const { enqueueSnackbar } = useSnackbar();

  const handleClickShowPassword = () => setShowPassword((show) => !show);
  const handleClickShowConfirmPassword = () =>
    setShowConfirmPassword((show) => !show);

  const initialValues: INewPasswordValues = {
    password: "",
    confirm_password: "",
  };

  const handleMouseDownPassword = (event: any) => {
    event.preventDefault();
  };

  const handlePasteEvent = (event: any) => {
    event.preventDefault();
  };

  // Password validation
  // const getCharacterValidationError = (str) => {
  //   return `Your password must have at least 1 ${str} character`;
  // };

  const handleInputChange = (e:any, setFieldValue:any, textValue:string) => {
    const inputValue = e.target.value;
    const filteredInputValue = inputValue.slice(0,15);
    
    if (textValue === "password") {
      setFieldValue("password", filteredInputValue);
    }
    else if(textValue === "confirm_password"){
      setFieldValue("confirm_password", filteredInputValue);    
    }
  };



  const handleSubmit = async (value: INewPasswordValues) => {
    setFetching(true);
    setErrorMsg(null);
    
    const response = await newPassword({
      ...value,
      remember_token: rememberToken,
      id: id,
    });

    setFetching(false);
    if (response?.code === 400) {
      if(response.errors.details){
        enqueueSnackbar(response.errors.details[0], { variant: "error",autoHideDuration: 4000 });
      }else{
        enqueueSnackbar(response.message, { variant: "error",autoHideDuration: 4000 });
      }
     
    } else if (response?.code === 200) {
      enqueueSnackbar(response.message, { variant: "success" });
      handleForgotPassword();
    } else {
      // Set Error if 422 status code
      if (response?.errors) {
        if(!response.errors.password){
          setErrorMsg({
            confirm_password:response.errors.confirm_password
          })
        }else if(!response.errors.confirm_password){
          setErrorMsg({
            password: response.errors.password,
          })
        }else{
          setErrorMsg({
            password: response.errors.password,
            confirm_password:response.errors.confirm_password
          })
        }      
        setFetching(false);
      }
    }
  };
  return (
    <>
      <TitleStyled>New Password</TitleStyled>
      <SubTitleStyled>
        Set the new password for your account so you can login and access all
        features.
      </SubTitleStyled>
      <Formik
        initialValues={initialValues}
      //  validationSchema={validationSchema}
        onSubmit={handleSubmit}
      >
        {({ setFieldValue }) => (
        <Form>
          <FormContainer>
            <label htmlFor="password">
              {formatMessage({ id: "Auth.login.password" })}
            </label>
            <Field
              id="password"
              name="password"
              type={showPassword ? "text" : "password"}
              placeholder="Enter password"
              as={OutlinedInputStyled}
              onChange={(event:string)=>handleInputChange(event,setFieldValue,"password")}
              endAdornment={
                <InputAdornment position="end">
                  <IconButton
                    aria-label="toggle password visibility"
                    onClick={handleClickShowPassword}
                    onMouseDown={handleMouseDownPassword}
                    edge="end"
                  >
                    {showPassword ? <VisibilityOff /> : <Visibility />}
                  </IconButton>
                </InputAdornment>
              }
              onPaste={handlePasteEvent}
            />
            <ErrorMessage name="password">
              {(msg) => <ErrorStyled>{msg}</ErrorStyled>}
            </ErrorMessage>
            {/* This error corresponded to API response error like 422 code error */}
            <InputError>{ErrorMsg?.password}</InputError>
            <label htmlFor="password">
              {formatMessage({ id: "Auth.login.confirmpassword" })}
            </label>
            <Field
              id="confirm_password"
              name="confirm_password"
              type={showConfirmPassword ? "text" : "password"}
              placeholder="Enter password"
              as={OutlinedInputStyled}
              onChange={(event:string)=>handleInputChange(event,setFieldValue,"confirm_password")}
              endAdornment={
                <InputAdornment position="end">
                  <IconButton
                    aria-label="toggle password visibility"
                    onClick={handleClickShowConfirmPassword}
                    onMouseDown={handleMouseDownPassword}
                    edge="end"
                  >
                    {showConfirmPassword ? <VisibilityOff /> : <Visibility />}
                  </IconButton>
                </InputAdornment>
              }
              onPaste={handlePasteEvent}
            />
            <ErrorMessage name="confirm_password">
              {(msg) => <ErrorStyled>{msg}</ErrorStyled>}
            </ErrorMessage>

            {/* This error corresponded to API response error like 422 code error */}
            <InputError>{ErrorMsg?.confirm_password}</InputError>

            {/* <ButtonStyled loading type='submit' sx={{ mt: '35px' }} variant="contained" >Update Password</ButtonStyled> */}

            {/* Loading Button using MUI */}
            <LoadingButtonStyled
              type="submit"
              loading={isFetching}
              sx={{ mt: "35px" }}
              variant="contained"
            >
              Update Password
            </LoadingButtonStyled>
          </FormContainer>
        </Form>
        )}
      </Formik>
    </>
  );
}
