/* eslint-disable @typescript-eslint/no-unused-vars */
import { ErrorMessage, Field, Form, Formik } from "formik";
import * as React from "react";
import * as Yup from "yup";

import loginBgImg from "@/assets/images/login-page-image.png";
import tmsLogo from "@/assets/images/tmslogo-2.png";

import { loginRequest } from "@/core/apis/api-handlers";
import { auth } from "@/core/utils";
import { ILoginInitialValues } from "@/types/login";
import { Google, Visibility, VisibilityOff } from "@mui/icons-material";
import {
  Box,
  FormControlLabel,
  IconButton,
  InputAdornment,
  Stack,
  Typography,
} from "@mui/material";
import { useSnackbar } from "notistack";
import { useIntl } from "react-intl";
import { Navigate, useNavigate } from "react-router-dom";
import ForgotPassword from "@/core/pages/Login/components/ForgotPassword";
import {
  DescriptionStyled,
  ErrorStyled,
  FormContainer,
  GoogleBtnStyled,
  IOSSwitch,
  InputError,
  LinkStyled,
  LoadingButtonStyled,
  OutlinedInputStyled,
  RightBoxContainer,
  TextContaier,
  TitleStyled,
  TmsLogoContainer,
} from "@/core/pages/Login/components/LoginStyled";

const Login: React.FC = (): JSX.Element => {
  const [showPassword, setShowPassword] = React.useState(false);
  const [showForgotPassword, setShowForgotPassword] = React.useState(false);
  const [isSubmit, setSubmit] = React.useState(false);
  const { formatMessage } = useIntl();
  const { enqueueSnackbar, } = useSnackbar();
  const navigate = useNavigate();
  const [ErrorMsg, setErrorMsg] = React.useState<any>(null);

  const formRef = React.useRef<any>();
  const [isRemember, setRemember] = React.useState<boolean>(false);

  const handleClickShowPassword = () => setShowPassword((show) => !show);

  const handleMouseDownPassword = (event: React.SyntheticEvent) => {
    event.preventDefault();
  };



  const initialValues: ILoginInitialValues = {
    email: auth.get("userInfo")?.user.email ?? "",
    password: "",
  };
 
  React.useEffect(() => {
    if (auth.get("userInfo")) {
      setRemember(true);
    }
  }, []);

  const validationSchema = Yup.object().shape({
    email: Yup.string()
      .trim()
      .email(formatMessage({ id: "Auth.login.validation.email" }))
      .required(formatMessage({ id: "Auth.login.required.email" })),
    password: Yup.string()
      .trim()
      .required(
        formatMessage({
          id: "Auth.login.required.password",
        })
      ),
    // Match case  #temporary comment
    // .matches(
    //   // eslint-disable-next-line no-useless-escape
    //   /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{6,})/,
    //   passwordValidationText
    // ),
  });
  console.log('unused validation schema', validationSchema)

  const handleInputChange = (e: any, setFieldValue: any, textValue: string) => {
    const inputValue = e.target.value;
    let filteredInputValue = inputValue.slice(0, 15);

    if (textValue === "password") {
      setFieldValue("password", filteredInputValue);
    }

  };

  // sample response for 422 status code
  // const response = {
  //   message: "The email must be a valid email address (and 1 more error)",
  //   errors: {
  //     email: ["The email must be a valid email address"],
  //     password: ["The password field is required"],
  //   },
  // };

  const handleSubmit = async (value: ILoginInitialValues) => {
    setErrorMsg(null)
    setSubmit(!isSubmit);
    const loginResponse = await loginRequest(value);
    if (loginResponse?.code === 200) {
      enqueueSnackbar(loginResponse.message, { variant: "success" });
      navigate("/admin/2023/dashboard");
      if (isRemember) {
        auth.set(loginResponse.data, "userInfo", true);
        auth.setToken(loginResponse.data.access_token, true);
      } else {
        auth.set(loginResponse.data, "userInfo", false);
        auth.setToken(loginResponse.data.access_token, false);
      }
    }
    if (loginResponse?.code === 401) {
      enqueueSnackbar(loginResponse.message, { variant: "error",  autoHideDuration: 4000  });
      setSubmit(false);
    } else {
      if (loginResponse?.errors) {
        setErrorMsg({
          email: loginResponse.errors.email,
          password: loginResponse.errors.password
        })
        setSubmit(false)
      }
      // Assign custom error for 422 error code

    }
  };

  const handleForgotPassword = () => {
    setErrorMsg(null)
    setShowForgotPassword(!showForgotPassword);
  };

  // if (!isRemember) {
  //   console.log("seesion");
  //   const input_values = formRef.current.values;
  //   auth.setUserInfo(`${input_values.email},${input_values.password}`, false);
  // }else{

  // }

  const rememberMe = () => {
    setRemember((prev) => !prev);
    //const input_values = formRef.current.values;
    // if (event.target.checked) {
    //   auth.setUserInfo(`${input_values.email},${input_values.password}`, true);
    // } else {
    //   auth.clear("userInfo");
    // }
  };

  if (auth.getToken()) {
    return (
      <Navigate
        to={{
          pathname: "/admin/dashboard",
        }}
      />
    );
  }


  return (
    <>
      <Stack
        direction={{ xs: "column", md: "row" }}
        justifyContent="space-between"
        gap="15px"
        sx={{
          background: "#f4f4f4",
          minHeight: "100vh",
          padding: "10px 20px",
          boxSizing: "border-box",
        }}
      >
        <Box
          width={{ xs: "100%", md: "50%" }}
          sx={{
            minHeight: { xs: "95vh", md: "none" },
            backgroundColor: "#FAFBFD",
            borderRadius: "40px",
          }}
        >
          <TmsLogoContainer>
            <img src={tmsLogo} alt="tms" />
            <TextContaier>
              <Typography component="span" color="#F0B01D">
                Track
              </Typography>
              <Typography component="span" color="#417EE3">
                My
              </Typography>
              <Typography component="span" color="#000000">
                School
              </Typography>
            </TextContaier>
          </TmsLogoContainer>

          <Box width={{ xs: "90%", sm: "400px" }} sx={{ margin: "auto" }}>
            {showForgotPassword ? (
              <ForgotPassword handleForgotPassword={handleForgotPassword} />
            ) : (
              <>
                <TitleStyled>Hi Welcome Back</TitleStyled>
                <Formik
                  initialValues={initialValues}
                  // validationSchema={validationSchema}
                  onSubmit={handleSubmit}
                  innerRef={formRef}
                >
                  {({ setFieldValue, resetForm }) => (
                    <Form>
                      <FormContainer>
                        <label htmlFor="email">
                          {formatMessage({ id: "Auth.login.email" })}
                        </label>
                        <Field
                          type="text"
                          id="email"
                          name="email"
                          as={OutlinedInputStyled}
                          placeholder="Email Address"
                        />
                        <ErrorMessage name="email">
                          {(msg) => <ErrorStyled>{msg}</ErrorStyled>}
                        </ErrorMessage>
                        {/* Custom server error handled as client side */}
                        <InputError>{ErrorMsg?.email}</InputError>
                        <label htmlFor="password">
                          {formatMessage({ id: "Auth.login.password" })}
                        </label>
                        <Field
                          id="password"
                          name="password"
                          type={showPassword ? "text" : "password"}
                          placeholder="Enter password"
                          as={OutlinedInputStyled}
                          onChange={(event: string) => handleInputChange(event, setFieldValue, "password")}
                          endAdornment={
                            <InputAdornment position="end">
                              <IconButton
                                aria-label="toggle password visibility"
                                onClick={handleClickShowPassword}
                                onMouseDown={handleMouseDownPassword}
                                edge="end"
                              >
                                {showPassword ? (
                                  <VisibilityOff />
                                ) : (
                                  <Visibility />
                                )}
                              </IconButton>
                            </InputAdornment>
                          }
                        />
                        <ErrorMessage name="password">
                          {(msg) => <ErrorStyled>{msg}</ErrorStyled>}
                        </ErrorMessage>
                        {/* Custom server error handled as client side */}
                        <InputError>{ErrorMsg?.password}</InputError>
                        <Stack
                          direction="row"
                          justifyContent="space-between"
                          alignItems="center"
                        >
                          <Stack>
                            <FormControlLabel
                              control={
                                <IOSSwitch
                                  sx={{ m: 1 }}
                                  checked={isRemember}
                                  defaultChecked={false}
                                  onChange={rememberMe}
                                />
                              }
                              label={
                                <Typography
                                  component="span"
                                  sx={{
                                    color: "#1A1A1A",
                                    fontWeight: 400,
                                    fontSize: 12,
                                  }}
                                >
                                  {formatMessage({ id: "Auth.login.rememberme" })}
                                </Typography>
                              }
                            />

                          </Stack>
                          <Box>
                            <LinkStyled
                              onClick={handleForgotPassword}
                              sx={{ cursor: "pointer" }}
                            >
                              {formatMessage({ id: "Auth.login.forgotPassword" })}
                              ?
                            </LinkStyled>
                          </Box>

                        </Stack>
                        <LinkStyled
                          onClick={() => resetForm()}
                          sx={{ cursor: "pointer" }}
                        >
                          {formatMessage({ id: "Auth.login.reset" })}
                        </LinkStyled>
                        <LoadingButtonStyled
                          type="submit"
                          sx={{ mt: "15px" }}
                          variant="contained"
                          loading={isSubmit}
                        >
                          {formatMessage({ id: "Auth.login.signin" })}
                        </LoadingButtonStyled>

                        {/* <ButtonStyled
                        type="submit"
                        sx={{ mt: "15px" }}
                        variant="contained"
                        disabled={isSubmit}
                      >
                        {formatMessage({ id: "Auth.login.signin" })}
                      </ButtonStyled> */}
                      </FormContainer>
                    </Form>
                  )}
                </Formik>
                <GoogleBtnStyled>
                  <Google />
                  <Typography>
                    Or {formatMessage({ id: "Auth.login.signin.google" })}
                  </Typography>
                </GoogleBtnStyled>

              </>
            )}
          </Box>
        </Box>
        <RightBoxContainer width={{ xs: "90%", md: "50%" }}>
          <DescriptionStyled>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
            eiusmod tempor incididunt{" "}
          </DescriptionStyled>
          <Box
            sx={{
              marginTop: "10px",
              display: "flex",
              justifyContent: "end",
            }}
          >
            <img width="85%" src={loginBgImg} alt="loginbg" />
          </Box>
        </RightBoxContainer>
      </Stack>
    </>
  );
};

// eslint-disable-next-line react-refresh/only-export-components
export const redirectIfUser = () => {
  // todo: check if user is logged in , call auth.getToken() and api to verify token
  return false;
};

export default Login;
