import React from "react";



const Dashboard: React.FC = () => {

    return <div>
       dashboard
    </div>;
};

export default Dashboard;
