import React from "react";
import { useRouteError } from "react-router-dom";

const PageNotFound: React.FC = () => {
  const error: any = useRouteError();
   return (
    <div id="error-page">
      <h1>Oops!</h1>
      <p>Sorry, page your are looking not found.</p>
      <p>
        <i>{error?.statusText || error?.message}</i>
      </p>
    </div>
  );
};

export default PageNotFound;
