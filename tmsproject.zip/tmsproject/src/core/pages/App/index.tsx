import React, { Suspense, lazy, useEffect, useState } from "react";
import LoadingIndicator from "@/core/components/LoadingIndicator";
import {
    Route,
    RouterProvider,
    createBrowserRouter,
    createRoutesFromElements,
} from "react-router-dom";
import Dashboard from "@/core/pages/Dashboard";

const AuthenticatedApp = lazy(
    () =>
        import(
            "@/core/components/AuthenticatedApp"
        )
);
const DefaultLayout = lazy(() => import("@/layouts/DefaultLayout"));
const AuthenticatedLayout = lazy(() => import("@/layouts/AuthenticatedLayout"));
const Error404 = lazy(() => import("@/core/pages/Errors/404"));
const Login = lazy(() => import("@/core/pages/Login"));
const App: React.FC = () => {
    const [{ isLoading }, setState] = useState({
        isLoading: true,
        hasAdmin: false,
    });

    useEffect(() => {
        const getData = async () => {
            try {
                const { hasAdmin }: any = await new Promise((resolve) => {
                    setTimeout(() => {
                        resolve({ hasAdmin: true });
                    }, 1000);
                });

                setState({ isLoading: false, hasAdmin });
            } catch (err) {
            }
        };
        getData();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    if (isLoading) {
        return <LoadingIndicator />;
    }

    const router = createBrowserRouter(
        createRoutesFromElements(
            <Route path="/" errorElement={<Error404 />} element={<DefaultLayout />}>
                <Route path="/admin/*" element={<AuthenticatedLayout />}>
                    <Route path="dashboard" element={<Dashboard />} />
                    <Route index path=":year/*" element={<AuthenticatedApp />} />
                </Route>
                <Route index path="auth/login" element={<Login />} />
            </Route>
        )
    );
    // DynamicFields
    return (
        <Suspense fallback={<LoadingIndicator />}>
            <RouterProvider router={router} />
        </Suspense>
    );
};

export default App;
