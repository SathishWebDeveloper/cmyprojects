import React, {lazy, useMemo} from "react";
import {Route, Routes} from "react-router-dom";
import {useAppContext} from "@/core/contexts/AppProvider";
import {createRoute} from "@/core/utils";
// import LoadingIndicator from "@/core/components/LoadingIndicator";

const Dashboard = lazy(() => import("@/core/pages/Dashboard"));
const PageNotFound = lazy(() => import("@/core/pages/Errors/PageNotFound"));


const Admin: React.FC = () => {
    const { menu } = useAppContext();
    const routes = useMemo(() => {
        return menu
            .filter((link) => link.Component)
            .map(({ to, Component }) => createRoute(Component, to));
    }, [menu]);


    return <>
        {/*<Suspense fallback={<LoadingIndicator/>}>*/}
            <Routes>
                <Route path="/" >
                    <Route path="dashboard" element={<Dashboard/>}/>
                    {routes}
                    <Route path="*" element={<PageNotFound/>}/>
                </Route>

            </Routes>
        {/*</Suspense>*/}
    </>;
};

export default Admin;
