import { API_METHODS, IAPIEndpoints } from "@/types/common";


export const API_END_POINTS: IAPIEndpoints = {
  login: { endPoint: "api/auth/login", method: API_METHODS.POST },
  forgotPassword: { endPoint: "api/auth/generate-otp", method: API_METHODS.POST, },
  validateOtp: { endPoint: "api/auth/validate-otp", method: API_METHODS.POST },
  resendOtp: { endPoint: "api/auth/resend-otp", method: API_METHODS.POST },
  newpassword: { endPoint: 'api/auth/change-password', method: API_METHODS.PATCH },

};
