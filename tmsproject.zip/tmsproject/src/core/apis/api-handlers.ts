import { IForgotPasswordValues, ILoginInitialValues, INewPasswordValues, IOtpValues, IResendOtpValues } from "@/types/login";
import { apiBaseUrl, request } from "../utils";
import { API_END_POINTS } from "./api-constants";


// Auth Handlers

// login
export const loginRequest = async (data: ILoginInitialValues) => {

  const loginResponse = await request({
    url: apiBaseUrl + API_END_POINTS.login.endPoint,
    method: API_END_POINTS.login.method,
    body: { ...data },
  });
  return loginResponse;

}

// forgot password
export const forgotPasswordRequest = async (data: IForgotPasswordValues) => {
  const forgotPasswordResponse = await request({
    url: apiBaseUrl + API_END_POINTS.forgotPassword.endPoint,
    method: API_END_POINTS.forgotPassword.method,
    body: { ...data },
  })
  return forgotPasswordResponse
}


// validate OTP
export const validateOtp = async (data: IOtpValues) => {
  const validateOtpResponse = await request({
    url: apiBaseUrl + API_END_POINTS.validateOtp.endPoint,
    method: API_END_POINTS.validateOtp.method,
    body: { ...data },
  });
  return validateOtpResponse;
};

// Resend OTP
export const resendOtp = async (data: IResendOtpValues) => {
  const validateOtpResponse = await request({
    url: apiBaseUrl + API_END_POINTS.resendOtp.endPoint,
    method: API_END_POINTS.resendOtp.method,
    body: { ...data },
  });
  return validateOtpResponse;
};

// NewPassword
export const newPassword = async (data: INewPasswordValues) => {

  const newpasswordResponse = await request({
    url: apiBaseUrl + API_END_POINTS.newpassword.endPoint,
    method: API_END_POINTS.newpassword.method,
    body: { ...data },
  });
  return newpasswordResponse;

}
