// type Reducer = (state: any, action: any) => any;

import type { Reducer } from "redux";

export interface ReducersType {
  reducers: Record<string, Reducer<any>>;
  add: (reducerName: string, reducer: Reducer) => void;
}

/*
const Reducers = ({
  appReducers,
}: {
  appReducers: Record<string, Reducer>;
}): ReducersType => {
  let reducers: Record<string, Reducer> = { ...appReducers };

  console.log("reducers", reducers)
  const add = (reducerName: string, reducer: Reducer) => {
    reducers[reducerName] = reducer;
  };

  return {
    reducers,
    add,
  };
};
*/

class ReducersClass {
  reducers: Record<string, Reducer>;
  constructor({ appReducers }: { appReducers: Record<string, Reducer> }) {
    this.reducers = { ...appReducers };
  }

  add(reducerName: string, reducer: Reducer) {
    this.reducers[reducerName] = reducer;
  }
}

export default ReducersClass;
