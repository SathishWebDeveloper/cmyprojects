import {PluginInitializer, PluginRegisterTypes} from "@/types/pluginsTypes";

class Plugin {
    public initializer: PluginInitializer;
    public isReady: boolean;
    public name: string;
    public pluginId: string;
    prototype: any;

    constructor(pluginConf: PluginRegisterTypes) {
        this.initializer = pluginConf.initializer;
        this.isReady = pluginConf.isReady !== undefined ? pluginConf.isReady : true;
        this.name = pluginConf.name;
        this.pluginId = pluginConf.id;
    }
}

export default Plugin;
