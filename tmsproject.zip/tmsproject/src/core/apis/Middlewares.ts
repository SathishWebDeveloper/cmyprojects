export interface MiddlewaresType {
  middlewares: any[];
  add(middleware: any): void;
}

const Middlewares: () => MiddlewaresType = () => {
  const middlewares: any[] = [];

  const add = (middleware: any) => {
    middlewares.push(middleware);
  };

  return {
    middlewares,
    add,
  };
};

export default Middlewares;
