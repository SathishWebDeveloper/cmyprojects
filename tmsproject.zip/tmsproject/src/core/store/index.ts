import { configureStore } from "@reduxjs/toolkit";
import {MiddlewaresType, ReducersType} from "@/core/apis";

let store = configureStore({
    reducer: {},
});

const createStore = (
  appMiddlewares: MiddlewaresType,
  appReducers: ReducersType
) => {

  store = configureStore({
    reducer:
      appReducers && appReducers.reducers ? { ...appReducers.reducers } : {},
    middleware: appMiddlewares ? appMiddlewares.middlewares : [],
  });

  return store;
};

// Infer the `RootState` and `AppDispatch` types from the store itself
export type RootState = ReturnType<typeof store.getState>;
// Inferred type: {posts: PostsState, comments: CommentsState, users: UsersState}
//export type AppDispatch = typeof store.dispatch;

export default createStore;
