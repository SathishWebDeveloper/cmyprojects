const languageNativeNames = {
    ar: 'العربية',
    en: 'English',

};

export default languageNativeNames;
