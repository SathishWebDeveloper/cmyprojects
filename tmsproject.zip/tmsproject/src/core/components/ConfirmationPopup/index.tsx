
import styled from '@emotion/styled';
import { DeleteOutlineOutlined, InfoOutlined } from '@mui/icons-material';
import { Divider, IconButton, Stack } from '@mui/material';
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import Modal from '@mui/material/Modal';
import Tooltip from '@mui/material/Tooltip';
import Typography from '@mui/material/Typography';
import * as React from 'react';


const style = {
    position: 'absolute',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    minWidth: 400,
    bgcolor: '#fff',
    borderRadius: '8px',
    pt: 3,
    pb: 2,
};

const StyledPrimaryButton = styled(Button)((data: any) => ({
    backgroundColor: '#FF800F',
    color: '#fff',
    fontSize: 13,
    padding: '5px 16px',
    gap: '8px',
    textTransform: 'none',
    ':hover': {
        backgroundColor: '#FF800F',
        ...data.root?.hover
    },
    ...data.root
}));

const StyledSecondaryButton = styled(Button)((data: any) => ({
    color: '#FF6A31',
    border: '1px solid #FF6A31',
    fontSize: 13,
    padding: '4px 16px',
    gap: '8px',
    textTransform: 'none',
    ...data.root
}));


function ConfirmationPopup({ title, callBack  }: { title?: string, callBack?: any }) {
    const [open, setOpen] = React.useState(false);
    const handleOpen = () => {
        setOpen(true)
    };
    const handleClose = (data: string) => {
        if (data === "cancel") {
            setOpen(false)
        } else {
            if (callBack) {
              callBack()
            }
            setOpen(false)
        }
    };
    return (
        <div>
            <Tooltip title="Delete" placement="top">
            <IconButton onClick={handleOpen}><DeleteOutlineOutlined /></IconButton>
            </Tooltip>
            <Modal
                open={open}
                onClose={handleClose}
                aria-labelledby="modal-modal-title"
                aria-describedby="modal-modal-description"
            >
                <Box sx={style}>
                    <Stack alignItems='center'>
                        <InfoOutlined sx={{ color: '#417EE3', fontSize: 50 }} />
                    </Stack>
                    <Typography
                        sx={{ fontSize: 17, color: '#252525', fontWeight: 500, textAlign: 'center', mt: 1 }}
                    >
                        {title}
                    </Typography>
                    <Divider sx={{ my: '15px' }} />
                    <Stack direction='row' justifyContent='end' gap='15px' alignItems='center' px='10px'>
                        <StyledSecondaryButton onClick={() => handleClose("cancel")}>Cancel</StyledSecondaryButton>
                        <StyledPrimaryButton onClick={() => handleClose("Delete")}>Delete</StyledPrimaryButton>
                    </Stack>
                </Box>
            </Modal>
        </div>
    );
}

export default ConfirmationPopup;
