
import React, {memo} from 'react';
import {Navigate, useLocation} from 'react-router-dom';
import {auth} from "@/core/utils";

const PrivateRoute:  React.FC<any & { children: React.ReactNode }> = ({children}) => {
    const {pathname, search} = useLocation();
     if (auth.getToken() == null) {

        return <Navigate
            to={{
                pathname: '/auth/login',
                search: pathname !== '/' ? `?redirectTo=${encodeURIComponent(`${pathname}${search}`)}` : '',
            }}
        />
    }

    return children;
};


export default memo(PrivateRoute);
