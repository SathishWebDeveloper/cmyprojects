import { Alert, Snackbar } from "@mui/material";

interface IToastProps {
  open: boolean;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  mode: any;
  message: string;
  duration: number;
  handleClose?: () => void;
}

const Toast = ({ open, mode, message, duration, handleClose }: IToastProps) => {
  return (
    <Snackbar
      open={open}
      autoHideDuration={duration}
      onClose={handleClose}
      anchorOrigin={{ horizontal: "center", vertical: "top" }}
    >
      <Alert
        variant="filled"
        onClose={handleClose}
        severity={mode}
        sx={{ width: "100%" }}
      >
        {message}
      </Alert>
    </Snackbar>
  );
};

export default Toast;
