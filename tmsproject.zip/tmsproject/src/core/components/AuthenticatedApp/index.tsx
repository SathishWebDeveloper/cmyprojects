import React from "react";
import PluginsInitializer from "../PluginsInitializer";

const AuthenticatedApp: React.FC = () => {
   return (
    <>
      <PluginsInitializer />
     </>
  );
};

export default AuthenticatedApp;
