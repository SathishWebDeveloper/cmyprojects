import React, { useReducer, useRef} from "react";

import reducer, {initialState, setPluginReady} from "./reducer";
import init from "./init";
import {useAppContext} from "@/core/contexts/AppProvider";
import Admin from "@/core/pages/Admin";

const PluginsInitializer: React.FC = () => {
     const {plugins: appPlugins} = useAppContext();

    const [{plugins} , dispatch] = useReducer (reducer, initialState, () =>
        init(appPlugins)
    );

    const setPlugin = useRef((pluginId: string) => {
        // noinspection TypeScriptValidateTypes
        dispatch(setPluginReady(pluginId));
    });

    const hasPluginNotReady = Object.keys(plugins).some(
        (plugin) => plugins[plugin].isReady === false
    );

    if (hasPluginNotReady) {
        return Object.keys(plugins).reduce(
            (acc: any, current: string) => {
                 const InitializerComponent = plugins[current].initializer;

                if (InitializerComponent) {
                    const key: string = plugins[current].pluginId;

                    acc.push(
                        <InitializerComponent key={key} setPlugin={setPlugin.current}/>
                    );
                }

                return acc;
            }, []);
    }

    return <Admin/>;
};

export default PluginsInitializer;
