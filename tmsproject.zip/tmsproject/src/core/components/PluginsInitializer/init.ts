import { Plugins } from "@/types/pluginsTypes";

const init = (plugins: Plugins) => {
  return {
    plugins: Object.keys(plugins).reduce((acc, current) => {
      acc[current] = { ...plugins[current] };

      return acc;
    }, {} as Plugins),
  };
};

export default init;
