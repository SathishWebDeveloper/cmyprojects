import {Plugins} from "@/types/pluginsTypes";
import {PayloadAction, createSlice, Draft} from "@reduxjs/toolkit";

export interface pluginInitializerState {
    plugins: Plugins;
}

export const initialState: pluginInitializerState = {
    plugins: {} as Plugins,
};

export const pluginInitializerSlice = createSlice({
    name: "pluginInitializer",
    initialState,
    reducers: {
        setPluginReady: (state: Draft<pluginInitializerState>, action: PayloadAction<string>) => {
            state.plugins[action.payload] = {
                ...state.plugins[action.payload],
                isReady: true,
            };
        },
    },
});

// Action creators are generated for each case reducer function
export const {setPluginReady} = pluginInitializerSlice.actions;

export default pluginInitializerSlice.reducer;
export type AppReducer = typeof pluginInitializerSlice.reducer;