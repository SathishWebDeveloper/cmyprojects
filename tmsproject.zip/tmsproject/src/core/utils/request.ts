import "whatwg-fetch";
import { auth } from "@/core/utils"
import _ from "lodash";

export type ResponseType = {
    status: number;
    statusText: string;
    json?: () => Promise<any>;
}

function parseJSON(response: ResponseType) {
    return response.json ? response.json() : Promise.resolve(response);
}

function checkStatus(
    response: ResponseType,
    checkToken = true
) {
    if (
        (response.status >= 200 && response.status < 300) ||
        response.status === 0
    ) {
        return response;
    }

    if (response.status === 401 && auth.getToken() && checkToken) {
        return checkTokenValidity(response);
    }

    return parseJSON(response)
        .then((responseFormatted: any) => {
            const error: any = new Error(response.statusText);
            error.response = response;
            error.response.payload = responseFormatted;
            throw error;
        });
}

function checkTokenValidity(response: ResponseType): any {
    const options = {
        method: "GET",
        headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${auth.getToken()}`,
        },
    };

    if (auth.getToken()) {
        return fetch(`${import.meta.env.VITE_ADMIN_BACKEND_URL}/user/me`, options).then(
            () => {
                if (response.status === 401) {
                    auth.clearAppStorage();
                }

                return checkStatus(response, false);
            }
        );
    }
}

/**
 * Format query params
 *
 * @param params
 * @returns {string}
 */
function formatQueryParams(params: { [x: string]: string | number | boolean }) {
    return Object.keys(params)
        .map((k) => `${encodeURIComponent(k)}=${encodeURIComponent(params[k])}`)
        .join("&");
}

/**
 * Requests a URL, returning a promise
 *
 *
 * @return {object}           The response data
 * @param args
 */

interface RequestOptions {
    url: string;
    headers?: Record<string, string>;
    method?: string;
    body?: { [key: string]: any } | string;
    params?: Record<string, any>;
    noAuth?: boolean;
    data?: { [key: string]: string } | string;
    upload?: boolean;
}

export default function request(options: RequestOptions) {
    const noAuth = options.noAuth ?? false,
        stringify = true,
        upload = options.upload ?? false;

    let url = options.url;

    // Set headers
    if (!options.headers) {
        if (!upload) {
            options.headers = Object.assign(
                {
                    "Content-Type": "application/json",
                    "x-device": "web",
                    "Accept":"application/json"
                },
                options.headers,
                {
                    "X-Forwarded-Host": "TMS",
                }
            );
        }
    }

    const token = auth.getToken();



    if (token && !noAuth) {
        options.headers = Object.assign(
            {
                Authorization: `Bearer ${token}`,
            },
            options.headers
        );
    }

    // Add parameters to url
    url = _.startsWith(url, "/")
        ? `${import.meta.env.VITE_ADMIN_BACKEND_URL}${url}`
        : url;

    if (options && options.params) {
        const params = formatQueryParams(options.params);
        url = `${url}?${params}`;
    }

    // Stringify body object
    if (options && options.body && stringify) {
        options.body = JSON.stringify(options.body);
    }

    if (options && options.body && upload) {
        options.data = options.body;
    }

    // noinspection TypeScriptValidateTypes
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-ignore
    return fetch(url, options)
        .then(checkStatus)
        .then(parseJSON)
        .then((response) => {
            return response;
        })
        .catch((error) => {
            return error?.response?.payload
        })
}
