export const log = console.log
export const error = console.error
