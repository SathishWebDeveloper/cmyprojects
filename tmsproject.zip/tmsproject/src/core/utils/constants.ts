export const basename = import.meta.env.VITE_ADMIN_BACKEND_URL.replace(window.location.origin, '');

export const languageKey = 'admin-language';

// API URL
export const apiBaseUrl = import.meta.env.VITE_APP_API_BASE_URL;




