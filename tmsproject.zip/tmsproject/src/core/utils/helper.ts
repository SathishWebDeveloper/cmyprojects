export function prefixPluginTranslations(data: any, pluginId:string) {
  //  return Object.keys(data).reduce((r, o) => (r[`${pluginId}.${o}`] = data[o], r), {})

    return Object.keys(data).reduce((acc:any, current) => {
        acc[`${pluginId}.${current}`] = data[current];
        return acc;
    }, {});

}

