import React, {useEffect, useState} from 'react';
import PropTypes from 'prop-types';
import {Route} from 'react-router-dom';
import LoadingIndicator from "@/core/components/LoadingIndicator";

const LazyCompo:React.FC<any> = ({loadComponent}) => {
    const [Compo, setCompo] : any = useState(null);

    useEffect(() => {
        const loadCompo = async () => {
            try {
                const loadedCompo = await loadComponent();

                setCompo(() => loadedCompo.default);
            } catch (err) {
                // TODO return the error component
                console.log('unused',err);
            }
        };

        loadCompo();
    }, [loadComponent]);

    if (Compo) {
        return <Compo/>;
    }

    return <LoadingIndicator/>;
};

const createRoute = (Component : React.Component, to: string) => {
    return (
        <Route
            element={<LazyCompo loadComponent={Component}/>}
            path={to}
            key={to}
        />
    );
};

LazyCompo.propTypes = {
    loadComponent: PropTypes.func.isRequired,
};

export default createRoute;
