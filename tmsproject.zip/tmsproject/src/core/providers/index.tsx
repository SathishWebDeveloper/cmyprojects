import React from "react";
import PropTypes from "prop-types";
import { Provider } from "react-redux";
import LanguageProvider from "@/core/contexts/LanguageProvider";
import AppProvider from "@/core/contexts/AppProvider";
import Snackbarprovider from "@/core/contexts/SnackBarProvider";

const Providers: React.FC<any & { children: React.ReactNode }> = ({
  children,
  store,
  menu,
  plugins,
  messages,
  localeNames,
}: any) => {
  console.log("??localeNames??", localeNames);
  console.log("??messages??", messages);
  return (
    <>
      <Provider store={store}>
        <Snackbarprovider>
          <AppProvider
            plugins={plugins}
            getPlugin={() => {}}
            menu={menu}
            settings={{}}
          >
            <LanguageProvider messages={messages} localeNames={localeNames}>
              {children}
            </LanguageProvider>
          </AppProvider>
        </Snackbarprovider>
      </Provider>
    </>
  );
};
Providers.propTypes = {
  children: PropTypes.element.isRequired,
  store: PropTypes.object.isRequired,
  plugins: PropTypes.object.isRequired,
  messages: PropTypes.object.isRequired,
  localeNames: PropTypes.objectOf(PropTypes.string).isRequired,
  menu: PropTypes.arrayOf(
    PropTypes.shape({
      to: PropTypes.string.isRequired,
      icon: PropTypes.func.isRequired,
      intlLabel: PropTypes.shape({
        id: PropTypes.string.isRequired,
        defaultMessage: PropTypes.string.isRequired,
      }).isRequired,
      permissions: PropTypes.array,
      Component: PropTypes.func,
    })
  ).isRequired,
};

export default Providers;
