import React from "react";
import { Outlet } from "react-router-dom";

const DefaultLayout: React.FC = () => {
  return (
    <>
      <div id="detail">
        {/* Default layout */}
        <br />
        <Outlet />
      </div>
    </>
  );
};

export default DefaultLayout;
