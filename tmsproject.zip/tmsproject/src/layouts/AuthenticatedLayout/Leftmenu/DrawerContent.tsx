import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Collapse, List, ListItemButton, ListItemIcon, ListItemText, } from '@mui/material';
import {
  ExpandLess, StarBorder, ExpandMore, PersonAddAltOutlined, PersonOutlineOutlined,
  SettingsOutlined, BoltOutlined, HomeOutlined, GroupOutlined, LayersOutlined, CalendarMonthOutlined,
  CodeOutlined, LogoutOutlined
} from '@mui/icons-material';
import SettingsOutlinedIcon from '@mui/icons-material/SettingsOutlined';
import { DrawerContentStyled } from './DrawerContentStyled';
import { useIntl } from "react-intl";
import FeedIcon from '@mui/icons-material/Feed';

export default function DrawerContent() {
  let currentURL = window?.location?.href?.split("/")[6]
  const [open, setOpen] = React.useState(true);
  const [openSetting, setopenSetting] = React.useState(false);
  const [activeItem, setActiveItem] = React.useState(currentURL);
  const navigate = useNavigate();
  const { formatMessage } = useIntl();

  const handleClick = (type: any) => {
    if (type === "settings") setopenSetting(!openSetting)
    else setOpen(!open);

  }




  const drawerItem = [{
    title: formatMessage({ id: "Drawer.dynamicfield" }),
    navigation: 'dynamic-field',
    icon: <SettingsOutlinedIcon />
  },
  {
    title: formatMessage({ id: "Drawer.masterform" }),
    navigation: 'master-form',
    icon: <FeedIcon/>

  },
  ];

  const handleItemClick = (item: string) => {
    setActiveItem(item);
  };



  return (
    <DrawerContentStyled>
      <List
        sx={{ width: '100%', maxWidth: 360, bgcolor: 'background.paper', paddingTop: 0, }}
        component="nav"
        aria-labelledby="nested-list-subheader">

        {/* single menu */}
        <ListItemButton onClick={handleClick} className='leftMenuPrimary'>
          <ListItemText primary="Set Up" className='leftMenuType' />
          {open ? <ExpandLess /> : <ExpandMore />}
        </ListItemButton>
        {/* collapse menu */}
        <Collapse in={open} timeout="auto" unmountOnExit>
          <List component="div" disablePadding>
            {/* single menu */}
            <ListItemButton sx={{ pl: 4 }} className='leftMenuSub'>
              <ListItemIcon className='leftMenuIcon'>
                <StarBorder />
              </ListItemIcon>
              <ListItemText primary="Starred" />
            </ListItemButton>
          </List>
        </Collapse>

        {/* single menu */}
        <ListItemButton onClick={handleClick} className='leftMenuPrimary'>
          <ListItemText primary="Data Entry Area" className='leftMenuType' />
          {open ? <ExpandLess /> : <ExpandMore />}
        </ListItemButton>
        {/* collapse menu */}
        <Collapse in={open} timeout="auto" unmountOnExit>
          <List component="div" disablePadding className='paddingAdd'>

            {/* single menu */}
            <ListItemButton sx={{ pl: 4 }} className='leftMenuSub'>
              <ListItemIcon className='leftMenuIcon'>
                <PersonOutlineOutlined />
              </ListItemIcon>
              <ListItemText primary="Dynamic  Field" />
            </ListItemButton>

            {/* single menu */}
            <ListItemButton sx={{ pl: 4 }} className='leftMenuSub'>
              <ListItemIcon className='leftMenuIcon'>
                <PersonOutlineOutlined />
              </ListItemIcon>
              <ListItemText primary="Leave Approvals" />
            </ListItemButton>
            {/* single menu */}
            <ListItemButton sx={{ pl: 4 }} className='leftMenuSub'>
              <ListItemIcon className='leftMenuIcon'>
                <SettingsOutlined />
              </ListItemIcon>
              <ListItemText primary="Teacher Substitution" />
            </ListItemButton>
            {/* single menu */}
            <ListItemButton sx={{ pl: 4 }} className='leftMenuSub'>
              <ListItemIcon className='leftMenuIcon'>
                <BoltOutlined />
              </ListItemIcon>
              <ListItemText primary="Student Daily Attendance" />
            </ListItemButton>
            {/* single menu */}
            <ListItemButton sx={{ pl: 4 }} className='leftMenuSub'>
              <ListItemIcon className='leftMenuIcon'>
                <HomeOutlined />
              </ListItemIcon>
              <ListItemText primary="Staff Attendance" />
            </ListItemButton>
            {/* single menu */}
            <ListItemButton sx={{ pl: 4 }} className='leftMenuSub'>
              <ListItemIcon className='leftMenuIcon'>
                <GroupOutlined />
              </ListItemIcon>
              <ListItemText primary="Student Leave Request" />
            </ListItemButton>
            {/* single menu */}
            <ListItemButton sx={{ pl: 4 }} className='leftMenuSub '>
              <ListItemIcon className='leftMenuIcon'>
                <PersonAddAltOutlined />
              </ListItemIcon>
              <ListItemText primary="Teacher Notes" />
            </ListItemButton>
            {/* single menu */}
            <ListItemButton sx={{ pl: 4 }} className='leftMenuSub'>
              <ListItemIcon className='leftMenuIcon'>
                <LayersOutlined />
              </ListItemIcon>
              <ListItemText primary="Circular" onClick={() => {
                navigate('2023')
              }} />
            </ListItemButton>
            {/* single menu */}
            <ListItemButton sx={{ pl: 4 }} className='leftMenuSub'>
              <ListItemIcon className='leftMenuIcon'>
                <StarBorder />
              </ListItemIcon>
              <ListItemText primary="Recognition" onClick={() => {
                navigate('2023/dashboard')
              }} />
            </ListItemButton>
            {/* single menu */}
            <ListItemButton sx={{ pl: 4 }} className='leftMenuSub'>
              <ListItemIcon className='leftMenuIcon'>
                <CalendarMonthOutlined />
              </ListItemIcon>
              <ListItemText primary="Academic Calendar" onClick={() => {
                navigate('2023/sample/sample-plugin')
              }} />
            </ListItemButton>
            {/* single menu */}
            <ListItemButton sx={{ pl: 4 }} className='leftMenuSub'>
              <ListItemIcon className='leftMenuIcon'>
                <CodeOutlined />
              </ListItemIcon>
              <ListItemText primary="Exam Schedule" />
            </ListItemButton>
            {/* single menu */}
            <ListItemButton sx={{ pl: 4 }} className='leftMenuSub'>
              <ListItemIcon className='leftMenuIcon'>
                <CodeOutlined />
              </ListItemIcon>
              <ListItemText primary="Holiday" />
            </ListItemButton>
            {/* single menu */}
            <ListItemButton sx={{ pl: 4 }} className='leftMenuSub'>
              <ListItemIcon className='leftMenuIcon'>
                <CodeOutlined />
              </ListItemIcon>
              <ListItemText primary="Lesson Planning" />
            </ListItemButton>
            {/* single menu */}
            <ListItemButton sx={{ pl: 4 }} className='leftMenuSub'>
              <ListItemIcon className='leftMenuIcon'>
                <CodeOutlined />
              </ListItemIcon>
              <ListItemText primary="Teacher Subjects" />
            </ListItemButton>
            {/* single menu */}
            <ListItemButton sx={{ pl: 4 }} className='leftMenuSub'>
              <ListItemIcon className='leftMenuIcon'>
                <CodeOutlined />
              </ListItemIcon>
              <ListItemText primary="Timetable" />
            </ListItemButton>
            {/* single menu */}
            <ListItemButton sx={{ pl: 4 }} className='leftMenuSub'>
              <ListItemIcon className='leftMenuIcon'>
                <CodeOutlined />
              </ListItemIcon>
              <ListItemText primary="Teacher Timetable" />
            </ListItemButton>
            {/* single menu */}
            <ListItemButton sx={{ pl: 4 }} className='leftMenuSub'>
              <ListItemIcon className='leftMenuIcon'>
                <CodeOutlined />
              </ListItemIcon>
              <ListItemText primary="Approval" />
            </ListItemButton>
            {/* single menu */}
            <ListItemButton sx={{ pl: 4 }} className='leftMenuSub'>
              <ListItemIcon className='leftMenuIcon'>
                <CodeOutlined />
              </ListItemIcon>
              <ListItemText primary="Library-T.Notes" />
            </ListItemButton>
            {/* single menu */}
            <ListItemButton sx={{ pl: 4 }} className='leftMenuSub'>
              <ListItemIcon className='leftMenuIcon'>
                <CodeOutlined />
              </ListItemIcon>
              <ListItemText primary="Chat Group" />
            </ListItemButton>
            {/* single menu */}
            <ListItemButton sx={{ pl: 4 }} className='leftMenuSub'>
              <ListItemIcon className='leftMenuIcon'>
                <CodeOutlined />
              </ListItemIcon>
              <ListItemText primary="Online Exam" />
            </ListItemButton>
            {/* single menu */}
            <ListItemButton sx={{ pl: 4 }} className='leftMenuSub'>
              <ListItemIcon className='leftMenuIcon'>
                <CodeOutlined />
              </ListItemIcon>
              <ListItemText primary="Video Tutorial" />
            </ListItemButton>
            {/* single menu */}
            <ListItemButton sx={{ pl: 4 }} className='leftMenuSub'>
              <ListItemIcon className='leftMenuIcon'>
                <CodeOutlined />
              </ListItemIcon>
              <ListItemText primary="T. Notes Academic Library" />
            </ListItemButton>
            {/* single menu */}
            <ListItemButton sx={{ pl: 4 }} className='leftMenuSub'>
              <ListItemIcon className='leftMenuIcon'>
                <CodeOutlined />
              </ListItemIcon>
              <ListItemText primary="Online Exam Answer" />
            </ListItemButton>
            {/* single menu */}
            <ListItemButton sx={{ pl: 4 }} className='leftMenuSub'>
              <ListItemIcon className='leftMenuIcon'>
                <CodeOutlined />
              </ListItemIcon>
              <ListItemText primary="Learning App" />
            </ListItemButton>
            {/* single menu */}
            <ListItemButton sx={{ pl: 4 }} className='leftMenuSub'>
              <ListItemIcon className='leftMenuIcon'>
                <CodeOutlined />
              </ListItemIcon>
              <ListItemText primary="Appointment" />
            </ListItemButton>
            {/* single menu */}
            <ListItemButton sx={{ pl: 4 }} className='leftMenuSub'>
              <ListItemIcon className='leftMenuIcon'>
                <LogoutOutlined />
              </ListItemIcon>
              <ListItemText primary="Log out" />
            </ListItemButton>
          </List>
        </Collapse>

        {/* Setting */}
        {/* single menu */}
        <ListItemButton onClick={() => handleClick("settings")} className='leftMenuPrimary'>
          <ListItemText primary="Setting" className='leftMenuType' />
          {openSetting ? <ExpandLess /> : <ExpandMore />}
        </ListItemButton>
        {/* collapse menu */}
        <Collapse in={openSetting} timeout="auto" unmountOnExit>
          <List component="div" disablePadding className='paddingAdd'>

            {drawerItem.map((item, index) => {
              return (
                <ListItemButton key={index} sx={{ pl: 4 }}
                  onClick={() => {
                    handleItemClick(item.navigation);
                    navigate(`/admin/2023/settings/${item.navigation}`)
                  }}
                  className={item.navigation === activeItem ? "leftMenuSub active" : "leftMenuSub"}>
                  <ListItemIcon className='leftMenuIcon'>
                    {item.icon}
                  </ListItemIcon>
                  {/* dynamic-field */}
                  <ListItemText primary={item.title} />
                </ListItemButton>
              )
            })}


          </List>
        </Collapse>
      </List >
    </DrawerContentStyled >
  )
}