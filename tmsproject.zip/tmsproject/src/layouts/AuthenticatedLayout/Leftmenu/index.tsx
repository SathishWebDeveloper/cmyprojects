import { Drawer } from "@mui/material";
import React from "react";

import DrawerContent from "./DrawerContent";
import { StyledLeftMenu } from "./components/StyledLeftMenu";

const Leftmenu: React.FC = (props: any) => {
  return (
    <StyledLeftMenu>
      <Drawer
        className="leftMenuCover"
        sx={{
          width: props.drawerWidth,
          flexShrink: 0,
          "& .MuiDrawer-paper": {
            width: props.drawerWidth,
            boxSizing: "border-box",
          },
        }}
        variant="permanent"
        anchor="left"
      >
        <DrawerContent />
      </Drawer>
    </StyledLeftMenu>
  );
};

export default Leftmenu;
