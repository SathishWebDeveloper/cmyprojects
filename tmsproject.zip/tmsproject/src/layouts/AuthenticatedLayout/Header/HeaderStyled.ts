import { styled } from "@mui/material/styles";
import { TextField, Breadcrumbs, Box } from "@mui/material";

const HeaderStyled = styled(Box)(({}) => ({
  width: "100%",
  boxSizing: "border-box",
  display: "flex",
  flexWrap: "wrap",
  alignItems: "center",
  justifyContent: "space-between",
  ".headerBarRightBox": {
    display: "flex",
    flexDirection: "column",
    gap: "2px",
    "& > h2": {
      color: "#0E0E0E",
      fontSize: 18,
      fontWeight: 700,
    },
  },
  ".headerBarLeftBox": {
    display: "flex",
    gap: "20px",
  },
  ".iconsBox": {
    color: "#5B6871",
    display: "flex",
    gap: "10px",
  },
}));

export const TextFieldStyled = styled(TextField)(({}) => ({
  ".MuiInputBase-root ": {
    paddingLeft: "5px",
    "&.Mui-focused fieldset": {
      borderColor: "#DDE2E4",
      borderWidth: "thin",
    },
    "&:hover fieldset": {
      borderColor: "#DDE2E4",
    },
  },
  input: {
    width: "200px",
    height: "30px",
    padding: "4px 4px",
  },
  fieldset: {
    border: "1px solid #DDE2E4",
    borderRadius: "6px",
  },
  ".MuiSvgIcon-root": {
    color: "#B0BABF",
    fontSize: 20,
    padding: 0,
  },
}));

export const BreadcrumbsStyled = styled(Breadcrumbs)(({}) => ({
  "& .selected": {
    color: "#0E0E0E",
    fontWeight: 500,
    fontSize: 12,
  },
  a: {
    color: "#6E7C87",
    fontWeight: 400,
    fontSize: 12,
  },
}));

export const accountMenuPaperStyles = {
  elevation: 0,
  overflow: "visible",
  filter: "drop-shadow(0px 2px 8px rgba(0,0,0,0.32))",
  mt: 1.5,
  "& .MuiAvatar-root": {
    width: 32,
    height: 32,
    ml: -0.5,
    mr: 1,
  },
  "&:before": {
    content: '""',
    display: "block",
    position: "absolute",
    top: 0,
    right: 14,
    width: 10,
    height: 10,
    bgcolor: "background.paper",
    transform: "translateY(-50%) rotate(45deg)",
    zIndex: 0,
  },
};

export default HeaderStyled;
