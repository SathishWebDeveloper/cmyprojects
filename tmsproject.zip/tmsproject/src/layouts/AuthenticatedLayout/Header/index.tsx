import * as React from "react";
import {
  Box,
  Typography,
  Link,
  Avatar,
  Menu,
  MenuItem,
  ListItemIcon,
  Divider,
  IconButton,
  Tooltip,
  InputAdornment,
} from "@mui/material";
import {
  NavigateNext,
  PersonAdd,
  Settings,
  Logout,
  Notifications,
  Help,
  Search,
} from "@mui/icons-material";

import HeaderStyled, {
  BreadcrumbsStyled,
  TextFieldStyled,
  accountMenuPaperStyles,
} from "./HeaderStyled";

const useMuiMenu = () => {
  const [anchorEl, setAnchorEl] = React.useState(null);
  const open = Boolean(anchorEl);

  const handleClick = (event: any) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  return { anchorEl, open, handleClick, handleClose };
};

export default function NewHeader() {
  const accountMenu = useMuiMenu();

  function handleClick(event: React.MouseEvent<HTMLDivElement, MouseEvent>) {
    event.preventDefault();
    console.info("You clicked a breadcrumb.");
  }

  return (
    <HeaderStyled>
      <Box className="headerBarRightBox">
        <Typography component="h2">Teacher Notes</Typography>
        <div role="presentation" onClick={handleClick}>
          <BreadcrumbsStyled
            aria-label="breadcrumb"
            separator={<NavigateNext fontSize="small" />}
          >
            <Link underline="hover" color="inherit" href="/">
              Dashboard
            </Link>
            <Link
              underline="hover"
              color="inherit"
              href="/material-ui/getting-started/installation/"
            >
              2021-2022
            </Link>
            <Typography className="selected">Teachers Notes</Typography>
          </BreadcrumbsStyled>
        </div>
      </Box>


      <Box className="headerBarLeftBox">
        <TextFieldStyled
          placeholder="Search"
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <Search />
              </InputAdornment>
            ),
          }}
        />
        <Box>
          <Box
            sx={{ display: "flex", alignItems: "center", textAlign: "center" }}
          >
            <Box className="iconsBox">
              <Notifications />
              <Help />
              <Settings />
            </Box>
            <Tooltip title="Account settings">
              <IconButton
                sx={{ ml: "10px" }}
                size="small"
                onClick={accountMenu.handleClick}
                aria-controls={accountMenu.open ? "account-menu" : undefined}
                aria-haspopup="true"
                aria-expanded={accountMenu.open ? "true" : undefined}
              >
                <Avatar sx={{ width: 32, height: 32 }}>M</Avatar>
              </IconButton>
            </Tooltip>
          </Box>
          <Menu
            anchorEl={accountMenu.anchorEl}
            id="account-menu"
            open={accountMenu.open}
            onClose={accountMenu.handleClose}
            onClick={accountMenu.handleClose}
            slotProps={{ paper: { sx: accountMenuPaperStyles } }}
            transformOrigin={{ horizontal: "right", vertical: "top" }}
            anchorOrigin={{ horizontal: "right", vertical: "bottom" }}
          >
            <MenuItem onClick={accountMenu.handleClose}>
              <Avatar /> Profile
            </MenuItem>
            <MenuItem onClick={accountMenu.handleClose}>
              <Avatar /> My account
            </MenuItem>
            <Divider />
            <MenuItem onClick={accountMenu.handleClose}>
              <ListItemIcon>
                <PersonAdd fontSize="small" />
              </ListItemIcon>
              Add another account
            </MenuItem>
            <MenuItem onClick={accountMenu.handleClose}>
              <ListItemIcon>
                <Settings fontSize="small" />
              </ListItemIcon>
              Settings
            </MenuItem>
            <MenuItem onClick={accountMenu.handleClose}>
              <ListItemIcon>
                <Logout fontSize="small" />
              </ListItemIcon>
              Logout
            </MenuItem>
          </Menu>
        </Box>
      </Box>
    </HeaderStyled>
  );
}
