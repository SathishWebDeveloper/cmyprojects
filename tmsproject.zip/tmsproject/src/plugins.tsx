import {PluginConfig} from "./types/pluginsTypes";
import settings from "./plugins/settings";
 import sample from "./plugins/sample";

const plugins: Record<string, PluginConfig> = {
    "settings": settings,
    "sample": sample,
};
export default plugins;
