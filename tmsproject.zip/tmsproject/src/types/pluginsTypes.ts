import {menuLinkType} from "./tms-app";
import {Plugin} from "../core/apis/index";
import type {Reducer} from "redux";

export interface LocaleData {
    data: Record<string, string>;
    locale: string;
}

export type Translations = (params: {
    locales: string[];
}) => Promise<LocaleData[]>;

export interface InitPluginProps {
    setPlugin: (pluginId: string) => void;
}


export type PluginInitializer = (app: InitPluginProps) => null;


export interface PluginConfig {
    register: (app: RegisterTypes) => void;
    bootstrap: (app: BootstrappedPlugin) => void;
    registerLanguages: Translations;
}

export interface BootstrappedPlugin {
    getPlugin: (pluginId: string) => Plugin;
}

export interface RegisterTypes {
    registerPlugin: (pluginConf: PluginRegisterTypes) => void;
    addReducers: (reducers: { [x: string]: Reducer }) => void;
    addMenuLink: (link: menuLinkType) => void;
    addMiddlewares: (middlewares: any[]) => void;
}

export type PluginRegisterTypes = {
    id: string;
    pluginId: string;
    initializer:  PluginInitializer;
    isReady: boolean;
    name: string;
};

export type Plugins = Record<string, PluginRegisterTypes>;
