export interface ILoginInitialValues {
  email: string;
  password: string;
}

export interface IForgotPasswordValues {
  email: string;
  reference_type?: string;
  app_type?: string;
  otp_type?: string;
}

export interface IOtpValues {
  otp_type: string;
  otp: string;
  app_type: string;
  reference_type: string;
  email: string;
}

export interface IResendOtpValues {
  otp_type: string;
  token: any;
  app_type: string;
  reference_type: string;
  email: string;
}

export interface INewPasswordValues {
  password: string;
  confirm_password: string;
  remember_token?: string;
  id?: number
}