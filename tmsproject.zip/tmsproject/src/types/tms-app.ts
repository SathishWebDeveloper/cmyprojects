import { MiddlewaresType, ReducersType } from "@/core/apis";
import React from "react";
import { PluginConfig } from "./pluginsTypes";

export interface menuLinkType {
  to: string;
  icon: object;
  intlLabel: {
    id: string;
    defaultMessage: string;
  };
  Component: () => Promise<{ default: React.ComponentType<any> }>;
  permissions?: Array<{
    action: string;
    subject: null | string;
  }>;
}


export interface TmsAppProps {
  adminConfig?: Record<string, any>;
  appPlugins: Record<string, PluginConfig>;
  middlewares: MiddlewaresType;
  reducers: ReducersType;
}