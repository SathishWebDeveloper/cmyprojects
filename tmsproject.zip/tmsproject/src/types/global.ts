
// Common types
export interface IAPIMethods {
  [key: string]: string;
}