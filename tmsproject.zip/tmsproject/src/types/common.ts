import { IAPIMethods } from "@/types/global"

export interface IAPIRoutes {
  endPoint: string;
  method: string;
}
export interface IAPIEndpoints {
  [key: string]: IAPIRoutes
}

export const API_METHODS: IAPIMethods = {
  GET: 'GET',
  POST: 'POST',
  PUT: 'PUT',
  PATCH: 'PATCH',
  DELETE: 'DELETE'
}

export default interface IMasterFormList {
  handleAddFormDisplay: () => void;
  isChecked: boolean;
  handleCheckboxStatus: () => void;
  showAddForm: boolean;
  showDataForm: any;
  GetAllReligionForm: () => void;
  isTableFetchLoader: boolean;
  isEditForm: boolean;
  handleSubmit: (values: any, type: string) => void;
  editAttributesData: any;
  isSubmit: boolean;
  toggleValues: { status: boolean };
  setToggleValues: (data: any) => void;
  responseErr: any;
  setresponseErr: any;
  selectedItemData: string;
  setShowDataForm:any;
  showFormContainer:any;
  sortingData:Array<string>;
}