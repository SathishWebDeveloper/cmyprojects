import languageReducer from "@/core/contexts/LanguageProvider/reducer";

const reducers = {
    "language": languageReducer
};

export default reducers;