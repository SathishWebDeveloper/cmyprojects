import invariant from "invariant";
import { Helmet } from "react-helmet";
import Providers from "@/core/providers";
import favicon from "@/assets/images/tmslogo-2.png";
import Logo from "@/assets/react.svg";
import { languageKey } from "@/core/utils";
import createStore from "@/core/store";
import { menuLinkType, TmsAppProps } from "@/types/tms-app";
import {
  PluginConfig,
  PluginRegisterTypes,
  RegisterTypes,
} from "@/types/pluginsTypes";
import { log } from "@/core/utils/log";
import type { Reducer } from "redux";
import { MiddlewaresType, Plugin, ReducersType } from "@/core/apis";
import App from "@/core/pages/App";
import pick from "lodash/pick";
import languageNativeNames from "@/core/languages/languageNativeNames";

class TmsApp {
  public customConfigurations: any;
  public appPlugins: Record<string, PluginConfig>;
  public middlewares: MiddlewaresType;
  public reducers: ReducersType;
  public configurations: {
    head: { favicon: string };
    themes: { light: string; dark: string };
    locales: string[];
    menuLogo: string;
    tutorials: boolean;
    translations: object;
    authLogo: string;
    notifications: { releases: boolean };
  };
  public menu: menuLinkType[];
  public plugins: Record<string, Plugin>;

  constructor(
    adminConfig: object,
    appPlugins: Record<string, PluginConfig>,
    middlewares: MiddlewaresType,
    reducers: ReducersType
  ) {
    this.customConfigurations = adminConfig;
    this.appPlugins = appPlugins;
    this.middlewares = middlewares;
    this.reducers = reducers;
    this.menu = [];
    this.plugins = {};

    this.configurations = {
      authLogo: Logo,
      head: { favicon },
      locales: ["en"],
      menuLogo: Logo,
      notifications: { releases: true },
      themes: { light: "lightTheme", dark: "darkTheme" },
      translations: {},
      tutorials: true,
    };
  }

  registerPlugin = (pluginConf: PluginRegisterTypes) => {
    const plugin = new Plugin(pluginConf);

    this.plugins[plugin.pluginId] = new Plugin(pluginConf);
  };

  addMenuLink = (link: menuLinkType) => {
    const stringifiedLink = JSON.stringify(link);

    invariant(link.to, `link.to should be defined for ${stringifiedLink}`);
    invariant(
      typeof link.to === "string",
      `Expected link.to to be a string instead received ${typeof link.to}`
    );
    invariant(
      link.intlLabel?.id && link.intlLabel?.defaultMessage,
      `link.intlLabel.id & link.intlLabel.defaultMessage for ${stringifiedLink}`
    );
    invariant(
      link.Component && typeof link.Component === "function",
      `link.Component should be a valid React Component`
    );
    invariant(
      link.icon && typeof link.icon === "function",
      `link.Icon should be a valid React Component`
    );

    this.menu.push(link);
  };

  addMiddlewares = (middlewares: any[]) => {
    middlewares.forEach((middleware) => {
      this.middlewares.add(middleware);
    });
  };

  addReducers = (reducers: { [x: string]: Reducer }) => {
    Object.keys(reducers).forEach((reducerName) => {
      this.reducers.add(reducerName, reducers[reducerName]);
    });
  };

  getPlugin = (pluginId: string | number): Plugin => {
    return this.plugins[pluginId];
  };

  async loadDefaultLanguages() {
    const arrayOfPromises = this.configurations.locales.map((locale) => {
      return import(`./core/languages/${locale}.json`)
        .then(({ default: data }) => {
          return { data, locale };
        })
        .catch((error) => {
          console.error(error);
          return { data: null, locale };
        });
    });
    const adminLocales = await Promise.all(arrayOfPromises);

    return adminLocales.reduce((acc: any, current) => {
      if (current.data) {
        acc[current.locale] = current.data;
      }

      return acc;
    }, {});
  }

  async registerLanguages() {
    const adminTranslations: any = await this.loadDefaultLanguages();

    const arrayOfPromises = Object.keys(this.appPlugins)
      .map((plugin) => {
        const registerLanguages = this.appPlugins[plugin].registerLanguages;

        if (registerLanguages) {
          return registerLanguages({ locales: this.configurations.locales });
        }

        return null;
      })
      .filter((a) => a);
    const pluginsTrads = await Promise.all(arrayOfPromises);

    const mergedTrads = pluginsTrads.reduce((acc: any, currentPluginTrads) => {
      const pluginTrads: any = currentPluginTrads?.reduce(
        (acc1: any, current) => {
          acc1[current.locale] = current.data;

          return acc1;
        },
        {}
      );

      Object.keys(pluginTrads).forEach((locale) => {
        acc[locale] = { ...acc[locale], ...pluginTrads[locale] };
      });

      return acc;
    }, {});

    const translations = this.configurations.locales.reduce(
      (acc: any, current: string) => {
        acc[current] = {
          ...adminTranslations[current],
          ...(mergedTrads[current] || {}),
          ...this.customConfigurations?.translations?.[current],
        };

        return acc;
      },
      {}
    );

    this.configurations.translations = translations;
  }

  async initialize() {
    Object.keys(this.appPlugins).forEach((plugin) => {
      log(`Registering plugin ${plugin}...  `);
      const payload: RegisterTypes = {
        registerPlugin: this.registerPlugin,
        addMenuLink: this.addMenuLink,
        addReducers: this.addReducers,
        addMiddlewares: this.addMiddlewares,
      };
      this.appPlugins[plugin].register(payload);
    });
  }

  async bootstrap() {
    Object.keys(this.appPlugins).forEach((plugin) => {
      const bootstrap = this.appPlugins[plugin].bootstrap;

      if (bootstrap) {
        bootstrap({
          getPlugin: this.getPlugin.bind(this),
        });
      }
    });
  }

  render() {
    const store = createStore(this.middlewares, this.reducers);
    //import.meta.env.VITE_ADMIN_BACKEND_URL.replace(window.location.origin, '');
    const localeNames = pick(
      languageNativeNames,
      this.configurations.locales || []
    );

    return (
      <Providers
        store={store}
        plugins={this.plugins}
        menu={this.menu}
        localeNames={localeNames}
        messages={this.configurations.translations}
      >
        <>
          <Helmet
            link={[
              {
                rel: "icon",
                type: "image/png",
                href: this.configurations.head.favicon,
              },
            ]}
            htmlAttributes={{ lang: localStorage.getItem(languageKey) || "en" }}
          />
          <App />
        </>
      </Providers>
    );
  }
}

export default ({
  adminConfig = {},
  appPlugins,
  middlewares,
  reducers,
}: TmsAppProps) => new TmsApp(adminConfig, appPlugins, middlewares, reducers);
